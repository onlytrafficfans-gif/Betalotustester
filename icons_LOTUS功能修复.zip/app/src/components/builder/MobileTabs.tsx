// MobileTabs — Tab navigation for mobile/tablet layouts
// Chat, Preview, Projects, Settings tabs

import React from 'react';
import { useBuilderStore } from '@/state/builderStore';
import type { MobileTab } from '@/state/builderStore';
import {
  MessageSquare,
  Smartphone,
  Wand2,
  FolderOpen,
  Settings,
} from 'lucide-react';

export function MobileTabs() {
  const { mobileTab, setMobileTab, schema } = useBuilderStore();

  const tabs: { id: MobileTab; icon: React.ReactNode; label: string; badge?: number }[] = [
    { id: 'chat', icon: <MessageSquare size={20} />, label: 'Chat' },
    { id: 'preview', icon: <Smartphone size={20} />, label: 'Preview' },
    { id: 'skills', icon: <Wand2 size={20} />, label: 'Skills' },
    { id: 'projects', icon: <FolderOpen size={20} />, label: 'Projects' },
    { id: 'settings', icon: <Settings size={20} />, label: 'Settings' },
  ];

  return (
    <nav className="lg:hidden shrink-0 h-16 bg-[#0a0a0a] border-t border-white/5 z-30 lotus-touch-target">
      <div className="flex items-center justify-around h-full px-2">
        {tabs.map((tab) => {
          const isActive = mobileTab === tab.id;

          return (
            <button
              key={tab.id}
              onClick={() => setMobileTab(tab.id)}
              className={`
                flex flex-col items-center justify-center gap-0.5 w-16 h-12 rounded-xl transition-all
                ${isActive
                  ? 'text-lotus-400'
                  : 'text-white/25 hover:text-white/40'
                }
              `}
            >
              <div className="relative">
                {tab.icon}
                {tab.id === 'preview' && schema && (
                  <span className="absolute -top-0.5 -right-1.5 w-1.5 h-1.5 rounded-full bg-lotus-400" />
                )}
              </div>
              <span className={`text-[10px] font-medium ${isActive ? 'text-lotus-400' : ''}`}>
                {tab.label}
              </span>
              {isActive && (
                <div className="absolute bottom-1 w-6 h-0.5 rounded-full bg-lotus-400/60" />
              )}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
