// PhoneShell — True-to-size device frames
// Exact dimensions: iPhone 14 Pro (393×852 pts), iPad (820×1180), Desktop browser

import type { PreviewDevice } from '@/state/builderStore';

interface PhoneShellProps {
  device: PreviewDevice;
  children: React.ReactNode;
}

// Device specs (CSS pixels at 1x, standard web scaling)
const DEVICES = {
  phone: {
    width: 393,   // iPhone 14 Pro logical width
    height: 852,  // iPhone 14 Pro logical height
    scale: 0.82,  // Scale to fit in preview area
    radius: 47,
    bezel: 12,
    notchW: 126,
    notchH: 34,
    indicatorW: 134,
    statusH: 54,
    homeIndicatorH: 34,
    label: 'iPhone 14 Pro',
  },
  tablet: {
    width: 820,   // iPad Air logical width (portrait-ish)
    height: 1080,
    scale: 0.48,
    radius: 24,
    bezel: 14,
    notchW: 0,
    notchH: 0,
    indicatorW: 160,
    statusH: 24,
    homeIndicatorH: 28,
    label: 'iPad Air',
  },
  desktop: {
    width: 1280,
    height: 832,
    scale: 0.31,
    radius: 0,
    bezel: 0,
    notchW: 0,
    notchH: 0,
    indicatorW: 0,
    statusH: 0,
    homeIndicatorH: 0,
    label: 'Desktop',
  },
};

export function PhoneShell({ device, children }: PhoneShellProps) {
  const d = DEVICES[device];

  if (device === 'desktop') {
    return (
      <div className="flex flex-col items-center">
        <span className="text-[10px] text-white/20 font-medium tracking-widest uppercase mb-3">{d.label}</span>
        <div
          className="overflow-hidden rounded-lg border border-white/10 bg-[#111]"
          style={{
            width: d.width * d.scale,
            boxShadow: '0 20px 60px -10px rgba(0,0,0,0.6)',
          }}
        >
          {/* Browser chrome */}
          <div className="flex items-center gap-2 px-3 py-2 bg-[#1a1a1a] border-b border-white/5">
            <div className="flex items-center gap-1.5">
              <div className="w-2 h-2 rounded-full bg-red-500/60" />
              <div className="w-2 h-2 rounded-full bg-yellow-500/60" />
              <div className="w-2 h-2 rounded-full bg-green-500/60" />
            </div>
            <div className="flex-1 mx-3">
              <div className="flex items-center gap-2 px-3 py-1 rounded-md bg-white/5 text-[10px] text-white/30 justify-center font-mono">
                localhost:3000
              </div>
            </div>
          </div>
          <div style={{ height: d.height * d.scale, overflow: 'auto' }}>
            {children}
          </div>
        </div>
      </div>
    );
  }

  if (device === 'tablet') {
    return (
      <div className="flex flex-col items-center">
        <span className="text-[10px] text-white/20 font-medium tracking-widest uppercase mb-3">{d.label}</span>
        <div
          className="relative overflow-hidden bg-black"
          style={{
            width: d.width * d.scale,
            borderRadius: d.radius,
            border: `${d.bezel}px solid #1a1a1a`,
            boxShadow: '0 25px 80px -10px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.04)',
          }}
        >
          {/* Camera */}
          <div className="flex justify-center py-1" style={{ background: '#1a1a1a' }}>
            <div className="w-2 h-2 rounded-full bg-[#333]" />
          </div>
          {/* Screen */}
          <div style={{ height: d.height * d.scale, overflow: 'auto' }}>
            {children}
          </div>
          {/* Home indicator */}
          <div className="flex justify-center py-1.5" style={{ background: '#1a1a1a' }}>
            <div className="w-32 h-1 rounded-full bg-white/20" />
          </div>
        </div>
      </div>
    );
  }

  // Phone — iPhone 14 Pro exact dimensions
  return (
    <div className="flex flex-col items-center">
      <span className="text-[10px] text-white/20 font-medium tracking-widest uppercase mb-3">{d.label}</span>
      <div
        className="relative overflow-hidden bg-black"
        style={{
          width: d.width * d.scale,
          borderRadius: d.radius,
          border: `${d.bezel}px solid #1c1c1e`,
          boxShadow: '0 30px 90px -10px rgba(0,0,0,0.7), 0 0 0 1px rgba(255,255,255,0.04)',
        }}
      >
        {/* Dynamic Island */}
        <div className="relative flex justify-center" style={{ height: d.notchH }}>
          <div
            className="absolute top-2 flex items-center justify-center gap-2 z-20"
            style={{
              width: d.notchW,
              height: d.notchH - 12,
              background: '#0a0a0a',
              borderRadius: (d.notchH - 12) / 2,
            }}
          >
            <div className="w-1 h-1 rounded-full bg-[#1a1a1a]" />
            <div className="w-1 h-1 rounded-full bg-[#0f6b3a] opacity-40" />
          </div>
        </div>

        {/* Status bar */}
        <div
          className="flex items-center justify-between px-5 text-[9px] font-medium text-white/60"
          style={{ height: d.statusH - d.notchH }}
        >
          <span>9:41</span>
          <div className="flex items-center gap-1">
            <svg width="12" height="8" viewBox="0 0 12 8" fill="currentColor" className="opacity-60"><rect x="0" y="5" width="2" height="3" rx="0.5" /><rect x="3" y="3" width="2" height="5" rx="0.5" /><rect x="6" y="1" width="2" height="7" rx="0.5" /><rect x="9" y="0" width="2" height="8" rx="0.5" /></svg>
            <svg width="14" height="7" viewBox="0 0 14 7" fill="none" className="opacity-60"><rect x="0.5" y="0.5" width="12" height="6" rx="1.5" stroke="currentColor" strokeWidth="0.8" /><rect x="2" y="2" width="8" height="3" rx="0.8" fill="currentColor" /></svg>
          </div>
        </div>

        {/* Screen content */}
        <div style={{ height: (d.height - d.statusH - d.homeIndicatorH) * d.scale, overflow: 'auto' }}>
          {children}
        </div>

        {/* Home indicator */}
        <div className="flex justify-center py-1.5">
          <div
            className="h-1 rounded-full bg-white/20"
            style={{ width: d.indicatorW }}
          />
        </div>
      </div>
    </div>
  );
}
