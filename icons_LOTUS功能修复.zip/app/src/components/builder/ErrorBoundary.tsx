// Error Boundary — Phase 6
// Prevents broken schemas from black-screening the entire app

import { Component, type ReactNode } from 'react';
import { AlertTriangle, RotateCcw } from 'lucide-react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('LOTUS ErrorBoundary caught:', error, info);
  }

  handleReset = () => {
    this.setState({ hasError: false, error: undefined });
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-screen w-screen flex items-center justify-center bg-[#050505] text-[#e5e5e5]">
          <div className="text-center max-w-sm px-6">
            <div className="w-16 h-16 rounded-2xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-5">
              <AlertTriangle size={28} className="text-red-400/60" />
            </div>
            <h3 className="text-lg font-semibold text-white/80 mb-2">Something went wrong</h3>
            <p className="text-sm text-white/40 mb-2">
              The app encountered an error. This usually means the schema contains invalid data.
            </p>
            {this.state.error && (
              <pre className="text-xs text-red-400/60 bg-red-500/5 rounded-lg p-3 mb-5 overflow-auto text-left">
                {this.state.error.message}
              </pre>
            )}
            <button
              onClick={this.handleReset}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-lotus-400/10 border border-lotus-400/20 text-lotus-400 text-sm font-medium hover:bg-lotus-400/15 transition-all"
            >
              <RotateCcw size={14} />
              Reload App
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
