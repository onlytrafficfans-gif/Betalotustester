// ChatInput — Text input + provider selector only. Tools (Image/File/Skills/Connect) are in ToolsBar.

import { useState, useRef, useCallback } from 'react';
import { useBuilderStore } from '@/state/builderStore';
import { Send, ChevronDown, Wand2, AlertCircle } from 'lucide-react';

export function ChatInput() {
  const { sendMessage, isLoading, switchProvider, providerId, getAvailableProviders } = useBuilderStore();
  const [input, setInput] = useState('');
  const [showModelPicker, setShowModelPicker] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const providers = getAvailableProviders();
  const currentProvider = providers.find(p => p.id === providerId);
  const noProviders = providers.length === 0;

  const handleSend = useCallback(async () => {
    const trimmed = input.trim();
    if (!trimmed || isLoading) return;
    setInput('');
    await sendMessage(trimmed);
  }, [input, isLoading, sendMessage]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }, [handleSend]);

  const handleInput = useCallback(() => {
    const textarea = textareaRef.current;
    if (textarea) {
      textarea.style.height = 'auto';
      textarea.style.height = `${Math.min(textarea.scrollHeight, 120)}px`;
    }
  }, []);

  return (
    <div className="shrink-0 px-3 py-3 border-t border-white/5 bg-[#0a0a0a] relative">
      {/* No providers warning */}
      {noProviders && (
        <div className="mb-2 px-1 flex items-center gap-1.5">
          <AlertCircle size={10} className="text-amber-400/60 shrink-0" />
          <p className="text-[10px] text-amber-400/60">
            No AI provider configured. Add an API key in Settings to start building.
          </p>
        </div>
      )}

      {/* Provider picker dropdown */}
      {showModelPicker && (
        <div className="absolute bottom-full left-3 mb-2 w-56 rounded-xl bg-[#1a1a1a] border border-white/10 shadow-xl z-50 overflow-hidden">
          <div className="px-3 py-2 border-b border-white/5">
            <p className="text-[10px] font-medium text-white/30 uppercase tracking-wider">AI Provider</p>
          </div>
          {providers.map(p => (
            <button
              key={p.id}
              onClick={() => { switchProvider(p.id); setShowModelPicker(false); }}
              className={`w-full flex items-center gap-2 px-3 py-2.5 text-xs transition-all ${providerId === p.id ? 'bg-lotus-400/10 text-lotus-400' : 'text-white/50 hover:bg-white/5 hover:text-white/70'}`}
            >
              <Wand2 size={12} />
              <span className="font-medium">{p.name}</span>
              <span className="ml-auto opacity-40">{p.model}</span>
            </button>
          ))}
          {providers.length === 0 && (
            <div className="px-3 py-3 text-[10px] text-white/30">
              Add an API key in Settings to enable AI generation.
            </div>
          )}
        </div>
      )}

      {/* Provider selector + input row */}
      <div className="flex items-end gap-2">
        {/* Provider pill */}
        <button
          onClick={() => setShowModelPicker(!showModelPicker)}
          className="shrink-0 flex items-center gap-1 px-2 py-1 rounded-lg text-[10px] text-white/30 hover:text-white/50 hover:bg-white/5 transition-all mb-1"
        >
          <Wand2 size={10} />
          <span className="hidden sm:inline">{currentProvider?.name || 'Provider'}</span>
          <ChevronDown size={10} />
        </button>

        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={(e) => { setInput(e.target.value); handleInput(); }}
            onKeyDown={handleKeyDown}
            placeholder={noProviders ? 'Add an API key in Settings...' : 'Describe the app you want to build...'}
            disabled={isLoading || noProviders}
            rows={1}
            className="w-full bg-white/5 border border-white/5 rounded-xl px-4 py-3 pr-10 text-sm text-white/90 placeholder:text-white/20 resize-none focus:outline-none focus:border-lotus-400/30 focus:ring-1 focus:ring-lotus-400/10 transition-all disabled:opacity-50"
            style={{ minHeight: '44px', maxHeight: '120px' }}
          />
          {input.length > 0 && <span className="absolute right-3 bottom-3 text-[10px] text-white/10">{input.length}</span>}
        </div>
        <button
          onClick={handleSend}
          disabled={!input.trim() || isLoading || noProviders}
          className={`shrink-0 w-10 h-10 rounded-xl flex items-center justify-center transition-all ${input.trim() && !isLoading && !noProviders ? 'bg-lotus-600 hover:bg-lotus-400 text-white shadow-lg shadow-lotus-400/20' : 'bg-white/5 text-white/20 cursor-not-allowed'}`}
        >
          <Send size={16} />
        </button>
      </div>
    </div>
  );
}
