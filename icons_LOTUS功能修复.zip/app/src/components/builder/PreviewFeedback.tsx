// PreviewFeedback — Toast notifications inside the preview area
// Shows when a button action (submit, toggle, modal) is triggered

import { useState, useCallback, createContext, useContext } from 'react';

interface FeedbackState {
  message: string;
  visible: boolean;
}

interface FeedbackContextValue {
  showFeedback: (message: string) => void;
  feedback: FeedbackState;
}

const FeedbackContext = createContext<FeedbackContextValue>({
  showFeedback: () => {},
  feedback: { message: '', visible: false },
});

export function usePreviewFeedback() {
  return useContext(FeedbackContext);
}

export function PreviewFeedbackProvider({ children }: { children: React.ReactNode }) {
  const [feedback, setFeedback] = useState<FeedbackState>({ message: '', visible: false });

  const showFeedback = useCallback((message: string) => {
    setFeedback({ message, visible: true });
    setTimeout(() => setFeedback({ message: '', visible: false }), 2000);
  }, []);

  return (
    <FeedbackContext.Provider value={{ showFeedback, feedback }}>
      {children}
      {feedback.visible && (
        <div className="absolute bottom-16 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg bg-[#1a1a1a] border border-white/10 text-[10px] text-white/50 shadow-lg z-50 whitespace-nowrap pointer-events-none">
          {feedback.message}
        </div>
      )}
    </FeedbackContext.Provider>
  );
}
