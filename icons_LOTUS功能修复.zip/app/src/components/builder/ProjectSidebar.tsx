// ProjectSidebar — Project management panel
// Lists all projects, allows opening, renaming, deleting

import { useState } from 'react';
import { useBuilderStore } from '@/state/builderStore';
import {
  Plus,
  FolderOpen,
  Trash2,
  Edit3,
  Check,
  X,
  Clock,
  MessageSquare,
  Layout,
  Trash,
} from 'lucide-react';

export function ProjectSidebar() {
  const {
    projects,
    project: currentProject,
    createNewProject,
    openProject,
    deleteProjectById,
    renameProjectById,
  } = useBuilderStore();

  const [editingId, setEditingId] = useState<string | null>(null);
  const [editName, setEditName] = useState('');
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  const handleRename = async (id: string) => {
    if (editName.trim()) {
      await renameProjectById(id, editName.trim());
    }
    setEditingId(null);
    setEditName('');
  };

  const startRename = (proj: { id: string; name: string }) => {
    setEditingId(proj.id);
    setEditName(proj.name);
  };

  const handleDelete = async (id: string) => {
    if (confirmDelete === id) {
      await deleteProjectById(id);
      setConfirmDelete(null);
    } else {
      setConfirmDelete(id);
      setTimeout(() => setConfirmDelete(null), 3000);
    }
  };

  const formatDate = (timestamp: number) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="flex flex-col h-full">
      {/* New Project Button */}
      <div className="p-3">
        <button
          onClick={() => { createNewProject(); }}
          className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-lotus-400/10 border border-lotus-400/20 text-lotus-400 text-sm font-medium hover:bg-lotus-400/15 transition-all"
        >
          <Plus size={16} />
          New Project
        </button>
      </div>

      {/* Projects List */}
      <div className="flex-1 overflow-y-auto px-3 pb-4 space-y-1.5">
        {projects.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <FolderOpen size={32} className="text-white/10 mb-3" />
            <p className="text-sm text-white/30 mb-1">No projects yet</p>
            <p className="text-xs text-white/15">Create your first project to get started</p>
          </div>
        )}

        {projects.map((proj) => {
          const isActive = proj.id === currentProject?.id;
          const isEditing = editingId === proj.id;
          const isConfirmingDelete = confirmDelete === proj.id;

          return (
            <div
              key={proj.id}
              className={`
                group relative rounded-xl border transition-all
                ${isActive
                  ? 'bg-lotus-400/5 border-lotus-400/20'
                  : 'bg-white/[0.02] border-white/5 hover:border-white/10 hover:bg-white/[0.04]'
                }
              `}
            >
              {isEditing ? (
                <div className="p-3">
                  <div className="flex items-center gap-2">
                    <input
                      type="text"
                      value={editName}
                      onChange={(e) => setEditName(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleRename(proj.id);
                        if (e.key === 'Escape') { setEditingId(null); setEditName(''); }
                      }}
                      autoFocus
                      className="flex-1 bg-white/5 border border-white/10 rounded-lg px-2.5 py-1.5 text-sm text-white/80 focus:outline-none focus:border-lotus-400/30"
                    />
                    <button
                      onClick={() => handleRename(proj.id)}
                      className="p-1.5 rounded-lg bg-lotus-400/10 text-lotus-400 hover:bg-lotus-400/20 transition-colors"
                    >
                      <Check size={14} />
                    </button>
                    <button
                      onClick={() => { setEditingId(null); setEditName(''); }}
                      className="p-1.5 rounded-lg bg-white/5 text-white/40 hover:bg-white/10 transition-colors"
                    >
                      <X size={14} />
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={() => { openProject(proj.id); }}
                  className="w-full text-left p-3"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <Layout size={14} className={isActive ? 'text-lotus-400' : 'text-white/20'} />
                        <span className={`text-sm font-medium truncate ${isActive ? 'text-lotus-400' : 'text-white/70'}`}>
                          {proj.name}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 ml-5">
                        <span className="flex items-center gap-1 text-[10px] text-white/20">
                          <Clock size={10} />
                          {formatDate(proj.updatedAt)}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] text-white/20">
                          <MessageSquare size={10} />
                          {proj.messages.length}
                        </span>
                        <span className="flex items-center gap-1 text-[10px] text-white/20">
                          <Layout size={10} />
                          {proj.schema.screens.length}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex items-center gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button
                        onClick={(e) => { e.stopPropagation(); startRename(proj); }}
                        className="p-1.5 rounded-lg hover:bg-white/5 text-white/30 hover:text-white/60 transition-colors"
                        title="Rename"
                      >
                        <Edit3 size={12} />
                      </button>
                      <button
                        onClick={(e) => { e.stopPropagation(); handleDelete(proj.id); }}
                        className={`p-1.5 rounded-lg transition-colors ${
                          isConfirmingDelete
                            ? 'bg-red-500/10 text-red-400 hover:bg-red-500/20'
                            : 'hover:bg-white/5 text-white/30 hover:text-red-400'
                        }`}
                        title={isConfirmingDelete ? 'Click again to confirm' : 'Delete'}
                      >
                        {isConfirmingDelete ? <Trash size={12} /> : <Trash2 size={12} />}
                      </button>
                    </div>
                  </div>
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
