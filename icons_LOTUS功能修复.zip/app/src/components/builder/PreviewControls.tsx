// PreviewControls — Device switcher, Undo/Redo, Export, QR Preview, Deploy

import { useState } from 'react';
import { useBuilderStore } from '@/state/builderStore';
import type { PreviewDevice } from '@/state/builderStore';
import { generateExport, downloadExport } from '@/lib/builder/exportGenerator';
import { QRPreview } from './QRPreview';
import { DeployPanel } from './DeployPanel';
import {
  Smartphone, Tablet, Monitor,
  Code, Download, Undo2, Redo2, QrCode, Rocket,
} from 'lucide-react';

export function PreviewControls() {
  const {
    previewDevice, setPreviewDevice, schema,
    undo, redo, historyIndex, schemaHistory,
  } = useBuilderStore();
  const [isExporting, setIsExporting] = useState(false);
  const [showQR, setShowQR] = useState(false);
  const [showDeploy, setShowDeploy] = useState(false);

  const canUndo = historyIndex > 0;
  const canRedo = historyIndex < schemaHistory.length - 1;

  const handleExport = async () => {
    if (!schema) return;
    setIsExporting(true);
    try {
      const blob = await generateExport(schema);
      const filename = `${schema.name.replace(/\s+/g, '-').toLowerCase()}-export.zip`;
      downloadExport(blob, filename);
    } catch { /* silent */ }
    setIsExporting(false);
  };

  const devices: { id: PreviewDevice; icon: React.ReactNode; label: string }[] = [
    { id: 'phone', icon: <Smartphone size={14} />, label: 'Phone' },
    { id: 'tablet', icon: <Tablet size={14} />, label: 'Tablet' },
    { id: 'desktop', icon: <Monitor size={14} />, label: 'Desktop' },
  ];

  return (
    <>
      {showQR && <QRPreview onClose={() => setShowQR(false)} />}
      {showDeploy && <DeployPanel onClose={() => setShowDeploy(false)} />}

      <div className="flex items-center gap-1">
        {/* Device switcher */}
        <div className="flex items-center bg-white/5 rounded-lg p-0.5 mr-2">
          {devices.map((d) => (
            <button
              key={d.id}
              onClick={() => setPreviewDevice(d.id)}
              className={`flex items-center gap-1 px-2.5 py-1.5 rounded-md text-xs font-medium transition-all ${previewDevice === d.id ? 'bg-lotus-400/15 text-lotus-400' : 'text-white/30 hover:text-white/50 hover:bg-white/5'}`}
              title={d.label}
            >
              {d.icon}
            </button>
          ))}
        </div>

        <div className="w-px h-5 bg-white/5 mx-1" />

        {/* Undo/Redo */}
        <CB icon={<Undo2 size={13} />} label="Undo" onClick={undo} disabled={!canUndo} />
        <CB icon={<Redo2 size={13} />} label="Redo" onClick={redo} disabled={!canRedo} />

        <div className="w-px h-5 bg-white/5 mx-1" />

        <CB
          icon={isExporting ? <Download size={13} className="text-lotus-400" /> : <Code size={13} />}
          label="Export Code"
          onClick={handleExport}
        />

        <div className="w-px h-5 bg-white/5 mx-1" />

        {/* QR Preview */}
        <CB icon={<QrCode size={13} />} label="Preview on Phone" onClick={() => setShowQR(true)} />

        {/* Deploy */}
        <CB icon={<Rocket size={13} />} label="Deploy to Stores" onClick={() => setShowDeploy(true)} />
      </div>
    </>
  );
}

function CB({ icon, label, onClick, disabled }: { icon: React.ReactNode; label: string; onClick: () => void; disabled?: boolean }) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`flex items-center gap-1 px-2 py-1.5 rounded-md text-xs transition-all ${
        disabled ? 'text-white/10 cursor-not-allowed' : 'text-white/30 hover:text-white/60 hover:bg-white/5'
      }`}
      title={label}
    >
      {icon}
    </button>
  );
}
