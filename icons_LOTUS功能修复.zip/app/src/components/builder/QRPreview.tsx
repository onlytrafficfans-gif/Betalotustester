// QRPreview — Real-time mobile preview via QR code
// Generates QR that links to the web preview URL

import { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useBuilderStore } from '@/state/builderStore';
import { generateExpoFiles } from '@/lib/builder/expoExport';
import { X, Smartphone, Wifi, Copy, Check, ExternalLink } from 'lucide-react';

interface QRPreviewProps {
  onClose: () => void;
}

export function QRPreview({ onClose }: QRPreviewProps) {
  const { schema } = useBuilderStore();
  const [copied, setCopied] = useState(false);
  const [showExpo, setShowExpo] = useState(false);

  // The web preview URL (current deployment)
  const previewUrl = window.location.origin;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportExpo = () => {
    if (!schema) return;
    const files = generateExpoFiles(schema);
    // Create a zip-like download (simplified: download as JSON manifest)
    const manifest = {
      name: schema.name,
      slug: schema.name.toLowerCase().replace(/\s+/g, '-'),
      files: files.map(f => ({ path: f.path, size: f.content.length })),
    };
    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${manifest.slug}-expo-manifest.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-sm rounded-2xl bg-[#111] border border-white/10 shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Smartphone size={14} className="text-lotus-400" />
            <span className="text-xs font-semibold text-white/70">Preview on Mobile</span>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/5 text-white/30">
            <X size={14} />
          </button>
        </div>

        <div className="p-4 space-y-4">
          {/* Tabs */}
          <div className="flex rounded-lg bg-white/5 p-0.5">
            <button
              onClick={() => setShowExpo(false)}
              className={`flex-1 py-1.5 rounded-md text-[10px] font-medium transition-all ${!showExpo ? 'bg-lotus-400/15 text-lotus-400' : 'text-white/30 hover:text-white/50'}`}
            >
              Web Preview
            </button>
            <button
              onClick={() => setShowExpo(true)}
              className={`flex-1 py-1.5 rounded-md text-[10px] font-medium transition-all ${showExpo ? 'bg-lotus-400/15 text-lotus-400' : 'text-white/30 hover:text-white/50'}`}
            >
              Expo Export
            </button>
          </div>

          {!showExpo ? (
            <>
              {/* QR Code */}
              <div className="flex justify-center">
                <div className="p-3 rounded-xl bg-white">
                  <QRCodeSVG
                    value={previewUrl}
                    size={180}
                    level="M"
                    includeMargin={false}
                  />
                </div>
              </div>

              <p className="text-xs text-white/40 text-center">
                Scan with your phone camera to open the preview
              </p>

              {/* URL */}
              <div className="flex items-center gap-2 px-3 py-2 rounded-lg bg-white/5 border border-white/5">
                <Wifi size={12} className="text-white/20 shrink-0" />
                <span className="flex-1 text-[10px] text-white/40 font-mono truncate">{previewUrl}</span>
                <button
                  onClick={() => handleCopy(previewUrl)}
                  className="p-1 rounded hover:bg-white/5 text-white/30 hover:text-white/50 transition-all"
                >
                  {copied ? <Check size={12} className="text-lotus-400" /> : <Copy size={12} />}
                </button>
              </div>

              <a
                href={previewUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-center gap-2 py-2 rounded-lg text-xs text-lotus-400 hover:bg-lotus-400/10 transition-all"
              >
                <ExternalLink size={12} />
                Open Preview
              </a>
            </>
          ) : (
            <>
              <p className="text-xs text-white/40 text-center leading-relaxed">
                Export as an Expo project and preview with the Expo Go app
              </p>

              {/* Steps */}
              <div className="space-y-2">
                {[
                  'Export the Expo project ZIP',
                  'Install Expo Go on your phone',
                  'Run "npx expo start" in the project',
                  'Scan the QR code from the terminal',
                ].map((step, i) => (
                  <div key={i} className="flex items-start gap-2 px-3 py-2 rounded-lg bg-white/[0.02]">
                    <span className="text-[10px] text-lotus-400/60 font-mono shrink-0">{i + 1}.</span>
                    <span className="text-[11px] text-white/40">{step}</span>
                  </div>
                ))}
              </div>

              <button
                onClick={handleExportExpo}
                disabled={!schema}
                className="w-full py-2.5 rounded-xl text-xs font-medium bg-lotus-600 text-white hover:bg-lotus-400 transition-all disabled:opacity-30 flex items-center justify-center gap-2"
              >
                <Smartphone size={14} />
                Export Expo Project
              </button>

              <p className="text-[10px] text-white/20 text-center">
                Also includes: App Store + Google Play config
              </p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
