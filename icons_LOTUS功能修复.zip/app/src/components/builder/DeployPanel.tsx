// DeployPanel — App Store & Google Play deployment preparation
// Shows what you need + generates store-ready config

import { useState } from 'react';
import { useBuilderStore } from '@/state/builderStore';
import { generateExpoFiles } from '@/lib/builder/expoExport';
import {
  X, Apple, Play, Store, CheckCircle2, Circle, Download,
  AlertTriangle,
} from 'lucide-react';

interface DeployPanelProps {
  onClose: () => void;
}

interface ChecklistItem {
  id: string;
  label: string;
  required: boolean;
  done: boolean;
}

export function DeployPanel({ onClose }: DeployPanelProps) {
  const { schema } = useBuilderStore();
  const [activeTab, setActiveTab] = useState<'ios' | 'android'>('ios');
  const [exporting, setExporting] = useState(false);

  const appName = schema?.name || 'MyApp';

  const iosChecks: ChecklistItem[] = [
    { id: 'icon', label: 'App Icon (1024x1024 PNG)', required: true, done: false },
    { id: 'splash', label: 'Splash Screen (1242x2438 PNG)', required: true, done: false },
    { id: 'screenshots', label: '5 App Store Screenshots', required: true, done: false },
    { id: 'bundle', label: 'Bundle ID configured', required: true, done: true },
    { id: 'signing', label: 'Apple Developer Account ($99/yr)', required: true, done: false },
    { id: 'privacy', label: 'Privacy Policy URL', required: true, done: false },
    { id: 'description', label: 'App Store Description', required: true, done: !!schema?.name },
  ];

  const androidChecks: ChecklistItem[] = [
    { id: 'icon', label: 'Adaptive Icon (foreground + background)', required: true, done: false },
    { id: 'splash', label: 'Splash Screen', required: true, done: false },
    { id: 'screenshots', label: '8 Play Store Screenshots', required: true, done: false },
    { id: 'bundle', label: 'Package name configured', required: true, done: true },
    { id: 'signing', label: 'Google Play Developer ($25 one-time)', required: true, done: false },
    { id: 'privacy', label: 'Privacy Policy URL', required: true, done: false },
    { id: 'description', label: 'Play Store Description', required: true, done: !!schema?.name },
  ];

  const checks = activeTab === 'ios' ? iosChecks : androidChecks;
  const doneCount = checks.filter(c => c.done).length;
  const requiredTotal = checks.filter(c => c.required).length;

  const handleExport = () => {
    if (!schema) return;
    setExporting(true);
    const files = generateExpoFiles(schema);

    // For now, export as a JSON manifest that can be used with expo
    const manifest = {
      name: schema.name,
      slug: schema.name.toLowerCase().replace(/\s+/g, '-'),
      platform: activeTab,
      storeConfig: activeTab === 'ios' ? {
        bundleIdentifier: `com.lotus.${schema.name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`,
        buildNumber: '1',
      } : {
        package: `com.lotus.${schema.name.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')}`,
        versionCode: 1,
      },
      files: files.map(f => ({ path: f.path, size: f.content.length })),
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${manifest.slug}-${activeTab}-store.json`;
    a.click();
    URL.revokeObjectURL(url);
    setExporting(false);
  };

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-md rounded-2xl bg-[#111] border border-white/10 shadow-2xl overflow-hidden max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="shrink-0 flex items-center justify-between px-4 py-3 border-b border-white/5">
          <div className="flex items-center gap-2">
            <Store size={14} className="text-lotus-400" />
            <span className="text-xs font-semibold text-white/70">Deploy to Stores</span>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-white/5 text-white/30">
            <X size={14} />
          </button>
        </div>

        {/* Tabs */}
        <div className="shrink-0 flex gap-0.5 p-3 pb-0">
          <button
            onClick={() => setActiveTab('ios')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all ${activeTab === 'ios' ? 'bg-white/5 text-white/80' : 'text-white/30 hover:text-white/50'}`}
          >
            <Apple size={14} />
            App Store
          </button>
          <button
            onClick={() => setActiveTab('android')}
            className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-xs font-medium transition-all ${activeTab === 'android' ? 'bg-white/5 text-white/80' : 'text-white/30 hover:text-white/50'}`}
          >
            <Play size={14} />
            Play Store
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {/* Progress */}
          <div className="flex items-center gap-3 px-3 py-2 rounded-lg bg-white/[0.02] border border-white/5">
            <div className="flex-1">
              <div className="flex items-center justify-between mb-1">
                <span className="text-[10px] text-white/40">Store readiness</span>
                <span className="text-[10px] text-lotus-400">{doneCount}/{requiredTotal}</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-white/5 overflow-hidden">
                <div
                  className="h-full rounded-full bg-lotus-400 transition-all"
                  style={{ width: `${(doneCount / requiredTotal) * 100}%` }}
                />
              </div>
            </div>
          </div>

          {/* Checklist */}
          <div className="space-y-1">
            {checks.map(check => (
              <div
                key={check.id}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all ${
                  check.done ? 'bg-lotus-400/[0.03]' : 'bg-white/[0.02]'
                }`}
              >
                {check.done ? (
                  <CheckCircle2 size={14} className="text-lotus-400 shrink-0" />
                ) : (
                  <Circle size={14} className="text-white/15 shrink-0" />
                )}
                <span className={`text-xs ${check.done ? 'text-lotus-400/70' : 'text-white/40'}`}>
                  {check.label}
                </span>
                {check.required && !check.done && (
                  <span className="ml-auto text-[9px] text-amber-400/50 px-1 rounded bg-amber-500/5">Required</span>
                )}
              </div>
            ))}
          </div>

          {/* Tips */}
          <div className="flex items-start gap-2 px-3 py-2 rounded-lg bg-amber-500/[0.03] border border-amber-500/10">
            <AlertTriangle size={12} className="text-amber-400/50 shrink-0 mt-0.5" />
            <p className="text-[10px] text-amber-400/50 leading-relaxed">
              Store submission typically takes 1-2 days for review. Make sure all required assets are ready before submitting.
            </p>
          </div>

          {/* Generated config */}
          <div className="space-y-2">
            <label className="text-[10px] text-white/30 uppercase tracking-wider font-medium">Generated Config</label>
            <div className="px-3 py-2 rounded-lg bg-white/[0.02] border border-white/5 font-mono text-[10px] text-white/30 space-y-1">
              <div>Name: {appName}</div>
              <div>
                {activeTab === 'ios' ? 'Bundle ID' : 'Package'}:{` `}
                {activeTab === 'ios'
                  ? `com.lotus.${appName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '')}`
                  : `com.lotus.${appName.toLowerCase().replace(/\s+/g, '_').replace(/[^a-z0-9_]/g, '')}`
                }
              </div>
              <div>Version: 1.0.0</div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="shrink-0 p-4 border-t border-white/5 space-y-2">
          <button
            onClick={handleExport}
            disabled={exporting || !schema}
            className="w-full py-2.5 rounded-xl text-xs font-medium bg-lotus-600 text-white hover:bg-lotus-400 transition-all disabled:opacity-30 flex items-center justify-center gap-2"
          >
            {exporting ? (
              <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <Download size={14} />
                Export {activeTab === 'ios' ? 'iOS' : 'Android'} Project
              </>
            )}
          </button>
          <p className="text-[10px] text-white/15 text-center">
            Uses Expo EAS Build for store submission
          </p>
        </div>
      </div>
    </div>
  );
}
