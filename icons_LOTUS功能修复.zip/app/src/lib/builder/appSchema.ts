// App Schema Types — The foundation of the live preview system
// Every app is defined by this schema, and the renderer turns it into UI

export interface AppTheme {
  background: string;
  primary: string;
  accent: string;
  text: string;
  surface: string;
  border: string;
}

export interface AppComponent {
  id: string;
  type: 'header' | 'text' | 'button' | 'input' | 'card' | 'list' | 'image' | 'avatar' | 'chart' | 'grid' | 'search' | 'tabs' | 'progress' | 'badge' | 'divider' | 'spacer';
  props: Record<string, unknown>;
  children?: AppComponent[];
}

export interface AppScreen {
  id: string;
  name: string;
  type: 'home' | 'dashboard' | 'profile' | 'settings' | 'login' | 'signup' | 'list' | 'detail' | 'form' | 'chat' | 'search' | 'onboarding' | 'custom';
  components: AppComponent[];
}

export interface NavigationItem {
  id: string;
  label: string;
  icon: string;
  screenId: string;
}

export interface AppNavigation {
  type: 'bottom-tabs' | 'sidebar' | 'top-tabs' | 'drawer' | 'none';
  items: NavigationItem[];
}

export interface AppSchema {
  id: string;
  name: string;
  description: string;
  theme: AppTheme;
  screens: AppScreen[];
  navigation: AppNavigation;
  activeScreenId: string;
  imageAssets: Record<string, string>; // id -> base64 data URL
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

export interface Project {
  id: string;
  name: string;
  createdAt: number;
  updatedAt: number;
  messages: ChatMessage[];
  schema: AppSchema;
}

// ─── Structured AI Response (Phase 2) ───────────────────────────────────────

export interface SchemaPatch {
  op:
    | 'addScreen'
    | 'removeScreen'
    | 'updateTheme'
    | 'addComponent'
    | 'updateComponent'
    | 'removeComponent'
    | 'reorderComponents'
    | 'setNavigation'
    | 'setActiveScreen'
    | 'fullRebuild';
  path?: string;
  screenId?: string;
  componentId?: string;
  value?: unknown;
  from?: number;
  to?: number;
}

export interface StructuredAIResponse {
  assistantMessage: string;
  schemaPatch?: SchemaPatch[];
  fullUpdatedSchema?: AppSchema;
  changedFiles?: string[];
  warnings?: string[];
}

// Legacy AIResponse interface (kept for backward compat)
export interface AIResponse {
  message: string;
  schema: AppSchema;
  changes: string[];
}

// ─── Default theme ────────────────────────────────────────────────────────────

export const defaultTheme: AppTheme = {
  background: '#0a0a0a',
  primary: '#059669',
  accent: '#10b981',
  text: '#f5f5f5',
  surface: '#171717',
  border: '#262626',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

export const generateId = (): string => {
  return Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
};

// Create a default empty app schema
export const createDefaultSchema = (): AppSchema => ({
  id: generateId(),
  name: 'My App',
  description: 'A new app',
  theme: { ...defaultTheme },
  screens: [
    {
      id: 'home',
      name: 'Home',
      type: 'home',
      components: [
        {
          id: generateId(),
          type: 'header',
          props: { title: 'Welcome', subtitle: 'Start building your app' },
        },
        {
          id: generateId(),
          type: 'text',
          props: { content: 'Type in the chat to build your app. Try "Build me a fitness app"', align: 'center', size: 'md' },
        },
        {
          id: generateId(),
          type: 'spacer',
          props: { size: 'lg' },
        },
        {
          id: generateId(),
          type: 'button',
          props: { label: 'Get Started', variant: 'primary', fullWidth: true },
        },
      ],
    },
  ],
  navigation: {
    type: 'none',
    items: [],
  },
  activeScreenId: 'home',
  imageAssets: {},
});

// ─── Schema diffing helpers (Phase 3) ────────────────────────────────────────

export function applySchemaPatch(schema: AppSchema, patch: SchemaPatch): { schema: AppSchema; change: string } {
  const s = deepClone(schema);

  switch (patch.op) {
    case 'addScreen': {
      const screen = patch.value as AppScreen;
      if (screen) {
        s.screens.push(screen);
        return { schema: s, change: `Added screen "${screen.name}"` };
      }
      return { schema: s, change: 'Added screen' };
    }

    case 'removeScreen': {
      const idx = s.screens.findIndex(sc => sc.id === patch.screenId);
      if (idx >= 0) {
        const name = s.screens[idx].name;
        s.screens.splice(idx, 1);
        // Remove from navigation too
        s.navigation.items = s.navigation.items.filter(n => n.screenId !== patch.screenId);
        // Reset active screen if needed
        if (s.activeScreenId === patch.screenId) {
          s.activeScreenId = s.screens[0]?.id || 'home';
        }
        return { schema: s, change: `Removed screen "${name}"` };
      }
      return { schema: s, change: 'Removed screen' };
    }

    case 'updateTheme': {
      const theme = patch.value as Partial<AppTheme>;
      if (theme) {
        s.theme = { ...s.theme, ...theme };
        return { schema: s, change: 'Updated theme colors' };
      }
      return { schema: s, change: 'Updated theme' };
    }

    case 'addComponent': {
      const screen = s.screens.find(sc => sc.id === patch.screenId);
      if (screen && patch.value) {
        const comp = patch.value as AppComponent;
        screen.components.push(comp);
        return { schema: s, change: `Added ${comp.type} to "${screen.name}"` };
      }
      return { schema: s, change: 'Added component' };
    }

    case 'updateComponent': {
      const screen = s.screens.find(sc => sc.id === patch.screenId);
      if (screen && patch.componentId) {
        const compIdx = screen.components.findIndex(c => c.id === patch.componentId);
        if (compIdx >= 0 && patch.value) {
          const updates = patch.value as Partial<AppComponent>;
          screen.components[compIdx] = { ...screen.components[compIdx], ...updates };
          return { schema: s, change: `Updated component in "${screen.name}"` };
        }
      }
      return { schema: s, change: 'Updated component' };
    }

    case 'removeComponent': {
      const screen = s.screens.find(sc => sc.id === patch.screenId);
      if (screen && patch.componentId) {
        const compIdx = screen.components.findIndex(c => c.id === patch.componentId);
        if (compIdx >= 0) {
          screen.components.splice(compIdx, 1);
          return { schema: s, change: `Removed component from "${screen.name}"` };
        }
      }
      return { schema: s, change: 'Removed component' };
    }

    case 'reorderComponents': {
      const screen = s.screens.find(sc => sc.id === patch.screenId);
      if (screen && typeof patch.from === 'number' && typeof patch.to === 'number') {
        const [moved] = screen.components.splice(patch.from, 1);
        screen.components.splice(patch.to, 0, moved);
        return { schema: s, change: `Reordered components in "${screen.name}"` };
      }
      return { schema: s, change: 'Reordered components' };
    }

    case 'setNavigation': {
      const nav = patch.value as AppNavigation;
      if (nav) {
        s.navigation = nav;
        return { schema: s, change: `Set navigation to ${nav.type}` };
      }
      return { schema: s, change: 'Updated navigation' };
    }

    case 'setActiveScreen': {
      if (patch.screenId && s.screens.some(sc => sc.id === patch.screenId)) {
        s.activeScreenId = patch.screenId;
        return { schema: s, change: 'Switched active screen' };
      }
      return { schema: s, change: 'Set active screen' };
    }

    case 'fullRebuild': {
      const fullSchema = patch.value as AppSchema;
      if (fullSchema) {
        return { schema: fullSchema, change: 'Rebuilt entire app' };
      }
      return { schema: s, change: 'Full rebuild requested' };
    }

    default:
      return { schema: s, change: `Unknown patch: ${(patch as unknown as Record<string, string>).op}` };
  }
}

export function applySchemaPatches(schema: AppSchema, patches: SchemaPatch[]): { schema: AppSchema; changes: string[] } {
  let current = schema;
  const changes: string[] = [];

  for (const patch of patches) {
    const result = applySchemaPatch(current, patch);
    current = result.schema;
    changes.push(result.change);
  }

  return { schema: current, changes };
}

// ─── Color Validation (Task 3) ──────────────────────────────────────────────

export function isValidHexColor(color: string): boolean {
  return /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(color);
}

export function validateAppTheme(theme: AppTheme): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  const fields: Array<keyof AppTheme> = ['background', 'primary', 'accent', 'text', 'surface', 'border'];

  for (const field of fields) {
    const value = theme[field];
    if (typeof value !== 'string' || !isValidHexColor(value)) {
      errors.push(`${field}: "${value}" is not a valid hex color (use #FFF or #FFFFFF)`);
    }
  }

  return { valid: errors.length === 0, errors };
}

function deepClone<T>(obj: T): T {
  return JSON.parse(JSON.stringify(obj));
}
