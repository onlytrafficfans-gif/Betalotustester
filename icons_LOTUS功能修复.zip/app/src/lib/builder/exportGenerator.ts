// Export Generator — Generates a buildable React + Vite + Tailwind project
// The exported zip must pass: npm install && npm run build

import JSZip from 'jszip';
import type { AppSchema, AppComponent } from './appSchema';
import { validateAppTheme } from './appSchema';

function toPascalCase(s: string): string {
  return s.replace(/(?:^|[^a-zA-Z0-9])([a-zA-Z])/g, (_, c: string) => c.toUpperCase());
}

function esc(s: string): string {
  if (!s) return '';
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─── Indentation helper ───────────────────────────────────────────────────────

function ind(depth: number): string {
  return ' '.repeat(depth);
}

// ─── Render a single component to TSX code ───────────────────────────────────

function renderComponentCode(c: AppComponent, _schema: AppSchema, d = 6): string {
  const i = ind(d);
  const p = c.props;
  const T = 'theme'; // reference to imported theme object

  switch (c.type) {
    case 'header': {
      const subtitle = p.subtitle ? `\n${i}      <p className="text-sm mt-0.5 opacity-60" style={{ color: ${T}.text }}>${esc(p.subtitle as string)}</p>` : '';
      return `${i}<div className="mb-2">\n${i}  <div className="flex items-center justify-between px-4 pt-4 pb-2">\n${i}    <div className="flex-1">\n${i}      <h1 className="text-xl font-bold" style={{ color: ${T}.text }}>${esc(p.title as string)}</h1>${subtitle}\n${i}    </div>\n${i}  </div>\n${i}</div>`;
    }
    case 'text': {
      const align = (p.align as string) || 'left';
      const cls = align === 'center' ? 'text-center' : align === 'right' ? 'text-right' : '';
      return `${i}<p className="px-4 py-2 text-sm ${cls}" style={{ color: ${T}.text, opacity: 0.8 }}>${esc(p.content as string)}</p>`;
    }
    case 'button': {
      const isPrimary = (p.variant as string) !== 'outline';
      const bg = isPrimary ? `${T}.primary` : "'transparent'";
      const col = isPrimary ? "'white'" : `${T}.text`;
      const bdr = isPrimary ? "'none'" : `\`1px solid \${${T}.border}\``;
      return `${i}<div className="px-4 py-1.5">\n${i}  <button className="w-full py-3 rounded-xl font-medium text-sm${isPrimary ? ' text-white' : ''}" style={{ backgroundColor: ${bg}, color: ${col}, border: ${bdr} }}>\n${i}    ${esc(p.label as string)}\n${i}  </button>\n${i}</div>`;
    }
    case 'input': {
      const t = p.type === 'password' ? 'password' : 'text';
      return `${i}<div className="px-4 py-1.5">\n${i}  <input type="${t}" placeholder="${esc(p.placeholder as string)}" className="w-full px-3 py-3 rounded-xl text-sm outline-none" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\`, color: ${T}.text }} />\n${i}</div>`;
    }
    case 'card': {
      const sub = p.subtitle ? `\n${i}    <p className="text-xs mt-0.5 opacity-50" style={{ color: ${T}.text }}>${esc(p.subtitle as string)}</p>` : '';
      return `${i}<div className="px-4 py-1.5">\n${i}  <div className="p-4 rounded-xl" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\` }}>\n${i}    <h3 className="text-sm font-semibold" style={{ color: ${T}.text }}>${esc(p.title as string)}</h3>${sub}\n${i}  </div>\n${i}</div>`;
    }
    case 'list': {
      const items = (p.items as Array<Record<string, string>>) || [];
      const itemCode = items.map((item, idx) => {
        const borderBottom = idx < items.length - 1 ? `\`1px solid \${${T}.border\`` : "'none'";
        const meta = item.duration || item.level || item.value;
        const metaLine = meta ? `\n${ind(d + 6)}<p className="text-xs opacity-50" style={{ color: ${T}.text }}>${esc(meta)}</p>` : '';
        return `${ind(d + 2)}<div key={${idx}} className="flex items-center justify-between px-4 py-3" style={{ borderBottom: ${borderBottom} }}>\n${ind(d + 4)}<div>\n${ind(d + 4)}<p className="text-sm font-medium" style={{ color: ${T}.text }}>${esc(item.title)}</p>${metaLine}\n${ind(d + 4)}</div>\n${ind(d + 4)}<span style={{ color: ${T}.text, opacity: 0.3 }}>&rsaquo;</span>\n${ind(d + 2)}</div>`;
      }).join('\n');
      return `${i}<div className="px-4 py-1.5">\n${i}  <div className="rounded-xl overflow-hidden" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\` }}>\n${itemCode}\n${i}  </div>\n${i}</div>`;
    }
    case 'grid': {
      const items = (p.items as Array<Record<string, string>>) || [];
      const cols = (p.columns as number) || 2;
      const itemCode = items.map(item => {
        return `${ind(d + 2)}<div className="p-3 rounded-xl text-center" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\` }}>\n${ind(d + 2)}  <p className="text-base font-bold" style={{ color: ${T}.text }}>${esc(item.value)}</p>\n${ind(d + 2)}  <p className="text-xs opacity-50 mt-0.5" style={{ color: ${T}.text }}>${esc(item.label)}</p>\n${ind(d + 2)}</div>`;
      }).join('\n');
      return `${i}<div className="px-4 py-2">\n${i}  <div className="grid grid-cols-${cols} gap-2">\n${itemCode}\n${i}  </div>\n${i}</div>`;
    }
    case 'avatar': {
      const name = (p.name as string) || 'User';
      const initials = name.split(' ').map(n => n[0]).join('').substring(0, 2);
      const sub = p.subtitle ? `\n${i}  <p className="text-xs opacity-50" style={{ color: ${T}.text }}>${esc(p.subtitle as string)}</p>` : '';
      return `${i}<div className="flex flex-col items-center py-4">\n${i}  <div className="w-16 h-16 rounded-full flex items-center justify-center text-xl font-bold mb-2" style={{ backgroundColor: ${T}.primary + '25', color: ${T}.primary }}>${esc(initials)}</div>\n${i}  <h3 className="text-base font-semibold" style={{ color: ${T}.text }}>${esc(name)}</h3>${sub}\n${i}</div>`;
    }
    case 'progress': {
      const val = (p.value as number) || 0;
      const color = (p.color as string) || `${T}.primary`;
      return `${i}<div className="px-4 py-2">\n${i}  <div className="flex items-center justify-between mb-1.5">\n${i}    <span className="text-xs font-medium" style={{ color: ${T}.text, opacity: 0.7 }}>${esc(p.label as string)}</span>\n${i}    <span className="text-xs font-bold" style={{ color: '${color}' }}>${val}%</span>\n${i}  </div>\n${i}  <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: ${T}.border }}>\n${i}    <div className="h-full rounded-full" style={{ width: '${val}%', backgroundColor: '${color}' }} />\n${i}  </div>\n${i}</div>`;
    }
    case 'tabs': {
      const items = (p.items as string[]) || [];
      const btns = items.map(item => `${ind(d + 2)}<button key="${item}" className="flex-1 py-2 rounded-lg text-xs font-medium" style={{ backgroundColor: ${T}.primary, color: 'white' }}>${esc(item)}</button>`).join('\n');
      return `${i}<div className="px-4 py-2">\n${i}  <div className="flex gap-1 p-1 rounded-xl" style={{ backgroundColor: ${T}.surface }}>\n${btns}\n${i}  </div>\n${i}</div>`;
    }
    case 'divider': {
      const lbl = p.label ? `\n${i}  <span className="text-xs opacity-40" style={{ color: ${T}.text }}>${esc(p.label as string)}</span>` : '';
      return `${i}<div className="px-4 py-3 flex items-center gap-3">\n${i}  <div className="flex-1 h-px" style={{ backgroundColor: ${T}.border }} />${lbl}\n${i}  <div className="flex-1 h-px" style={{ backgroundColor: ${T}.border }} />\n${i}</div>`;
    }
    case 'spacer': {
      const sizes: Record<string, string> = { sm: 'h-2', md: 'h-4', lg: 'h-8', xl: 'h-12' };
      return `${i}<div className="${sizes[p.size as string] || 'h-4'}" />`;
    }
    case 'chart': {
      return `${i}<div className="px-4 py-2">\n${i}  <p className="text-xs font-medium mb-3 opacity-60" style={{ color: ${T}.text }}>${esc(p.label as string)}</p>\n${i}  <div className="flex items-end gap-2 h-24">\n${i}    {[65,40,80,55,90,70].map((h,i) => <div key={i} className="flex-1 rounded-t-md" style={{ height: h+'%', backgroundColor: i===4 ? ${T}.primary : ${T}.primary + '50' }} />)}\n${i}  </div>\n${i}</div>`;
    }
    case 'search': {
      return `${i}<div className="px-4 py-2">\n${i}  <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\` }}>\n${i}    <span className="text-sm opacity-40" style={{ color: ${T}.text }}>Search...</span>\n${i}  </div>\n${i}</div>`;
    }
    case 'image': {
      const assetId = (p.assetId as string) || '';
      const url = (p.url as string) || '';
      if (assetId) {
        return `${i}<div className="px-4 py-1.5">\n${i}  <img src={IMAGE_ASSETS['${assetId}'] || ''} alt="${esc(p.alt as string) || 'Image'}" className="w-full h-32 rounded-xl object-cover" />\n${i}</div>`;
      }
      if (url) {
        return `${i}<div className="px-4 py-1.5">\n${i}  <img src="${esc(url)}" alt="${esc(p.alt as string) || 'Image'}" className="w-full h-32 rounded-xl object-cover" />\n${i}</div>`;
      }
      return `${i}<div className="px-4 py-1.5">\n${i}  <div className="w-full h-32 rounded-xl flex items-center justify-center" style={{ backgroundColor: ${T}.surface, border: \`1px solid \${${T}.border}\` }}>\n${i}    <span className="text-xs opacity-30" style={{ color: ${T}.text }}>Image</span>\n${i}  </div>\n${i}</div>`;
    }
    default:
      return `${i}{/* ${c.type} */}`;
  }
}

// ─── Generate screen component file ───────────────────────────────────────────

function generateScreenFile(screen: AppSchema['screens'][0], schema: AppSchema): string {
  const name = toPascalCase(screen.name);
  const components = screen.components.map(c => renderComponentCode(c, schema)).join('\n');

  return `import { theme } from '../theme'
import { IMAGE_ASSETS } from '../assets'

export function ${name}() {
  return (
    <div className="min-h-full space-y-1">
${components}
    </div>
  );
}
`;
}

// ─── File list generator (for GitHub export) ──────────────────────────────────

export interface ExportFile {
  path: string;
  content: string;
}

export function generateExportFiles(schema: AppSchema): ExportFile[] {
  const t = schema.theme;
  const files: ExportFile[] = [];

  // 1. package.json
  files.push({
    path: 'package.json',
    content: JSON.stringify({
      name: schema.name.toLowerCase().replace(/\s+/g, '-'),
      private: true,
      version: '0.1.0',
      type: 'module',
      scripts: {
        dev: 'vite',
        build: 'tsc && vite build',
        preview: 'vite preview',
      },
      dependencies: {
        react: '^18.2.0',
        'react-dom': '^18.2.0',
      },
      devDependencies: {
        '@types/react': '^18.2.0',
        '@types/react-dom': '^18.2.0',
        '@vitejs/plugin-react': '^4.0.0',
        typescript: '^5.0.0',
        vite: '^5.0.0',
        tailwindcss: '^3.4.0',
        autoprefixer: '^10.4.0',
        postcss: '^8.4.0',
      },
    }, null, 2),
  });

  // 2. index.html
  files.push({
    path: 'index.html',
    content: `<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>${esc(schema.name)}</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
`,
  });

  // 3. vite.config.ts
  files.push({
    path: 'vite.config.ts',
    content: `import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
})
`,
  });

  // 4. tsconfig.json
  files.push({
    path: 'tsconfig.json',
    content: JSON.stringify({
      compilerOptions: {
        target: 'ES2020',
        useDefineForClassFields: true,
        lib: ['ES2020', 'DOM', 'DOM.Iterable'],
        module: 'ESNext',
        skipLibCheck: true,
        moduleResolution: 'bundler',
        allowImportingTsExtensions: true,
        resolveJsonModule: true,
        isolatedModules: true,
        noEmit: true,
        jsx: 'react-jsx',
        strict: true,
        noUnusedLocals: false,
        noUnusedParameters: false,
        noFallthroughCasesInSwitch: true,
      },
      include: ['src'],
      references: [{ path: './tsconfig.node.json' }],
    }, null, 2),
  });

  // 4b. tsconfig.node.json
  files.push({
    path: 'tsconfig.node.json',
    content: JSON.stringify({
      compilerOptions: {
        composite: true,
        skipLibCheck: true,
        module: 'ESNext',
        moduleResolution: 'bundler',
        allowSyntheticDefaultImports: true,
      },
      include: ['vite.config.ts'],
    }, null, 2),
  });

  // 5. tailwind.config.cjs
  files.push({
    path: 'tailwind.config.cjs',
    content: `/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: { extend: {} },
  plugins: [],
}
`,
  });

  // 6. postcss.config.cjs
  files.push({
    path: 'postcss.config.cjs',
    content: `module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
`,
  });

  // 7. src/theme.ts
  files.push({
    path: 'src/theme.ts',
    content: `export const theme = {
  background: '${t.background}',
  primary: '${t.primary}',
  accent: '${t.accent}',
  text: '${t.text}',
  surface: '${t.surface}',
  border: '${t.border}',
} as const
`,
  });

  // 8. src/assets.ts
  const assetEntries = Object.entries(schema.imageAssets || {});
  if (assetEntries.length > 0) {
    const lines = assetEntries.map(([id, data]) => `  '${id}': '${data}',`).join('\n');
    files.push({ path: 'src/assets.ts', content: `export const IMAGE_ASSETS: Record<string, string> = {\n${lines}\n}\n` });
  } else {
    files.push({ path: 'src/assets.ts', content: `export const IMAGE_ASSETS: Record<string, string> = {}\n` });
  }

  // 9. src/index.css
  files.push({
    path: 'src/index.css',
    content: `@tailwind base;
@tailwind components;
@tailwind utilities;

body {
  margin: 0;
  background-color: ${t.background};
  color: ${t.text};
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
}

#root {
  min-height: 100vh;
}
`,
  });

  // 10. src/main.tsx
  files.push({
    path: 'src/main.tsx',
    content: `import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App'
import './index.css'

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
`,
  });

  // 11. src/App.tsx
  const hasNav = schema.navigation.type === 'bottom-tabs' && schema.navigation.items.length > 0;
  let appCode = `import { useState } from 'react'
import { theme } from './theme'
`;
  for (const screen of schema.screens) {
    appCode += `import { ${toPascalCase(screen.name)} } from './screens/${toPascalCase(screen.name)}'\n`;
  }
  appCode += `
const SCREENS: Record<string, React.FC> = {
${schema.screens.map(s => `  '${s.id}': ${toPascalCase(s.name)},`).join('\n')}
}

export default function App() {
  const [activeScreen, setActiveScreen] = useState('${schema.activeScreenId}')

  const Screen = SCREENS[activeScreen] || SCREENS['${schema.screens[0]?.id}']

  return (
    <div className="min-h-screen flex flex-col" style={{ backgroundColor: theme.background }}>
      <main className="flex-1 overflow-y-auto">
        <Screen />
      </main>
${hasNav ? generateNavCode(schema) : ''}
    </div>
  )
}
`;
  files.push({ path: 'src/App.tsx', content: appCode });

  // 12. src/screens/*.tsx
  for (const screen of schema.screens) {
    files.push({ path: `src/screens/${toPascalCase(screen.name)}.tsx`, content: generateScreenFile(screen, schema) });
  }

  // 13. README.md
  files.push({
    path: 'README.md',
    content: `# ${esc(schema.name)}

Generated by LOTUS App Builder.

## Getting Started

\`\`\`bash
npm install
npm run dev
\`\`\`

## Build

\`\`\`bash
npm run build
\`\`\`
`,
  });

  return files;
}

// ─── ZIP export (uses generateExportFiles) ────────────────────────────────────

export async function generateExport(schema: AppSchema): Promise<Blob> {
  const colorValidation = validateAppTheme(schema.theme);
  if (!colorValidation.valid) {
    throw new Error(`Cannot export: invalid theme colors:\n${colorValidation.errors.join('\n')}`);
  }

  const zip = new JSZip();
  const files = generateExportFiles(schema);

  for (const file of files) {
    zip.file(file.path, file.content);
  }

  return zip.generateAsync({ type: 'blob' });
}

function generateNavCode(schema: AppSchema): string {
  const items = schema.navigation.items;
  return `      <nav className="shrink-0 flex justify-around py-2" style={{ backgroundColor: 'theme.surface + \'ee\'', borderTop: '1px solid ' + theme.border }}>
${items.map(item => `        <button
          key="${item.id}"
          onClick={() => setActiveScreen('${item.screenId}')}
          className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg text-[10px] font-medium transition-colors"
          style={{ color: activeScreen === '${item.screenId}' ? theme.primary : theme.text + '60' }}
        >
          ${esc(item.label)}
        </button>`).join('\n')}
      </nav>`;
}

export function downloadExport(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}
