// Expo Export Generator — Creates Expo-compatible project files
// Output: ZIP with app.json, package.json, App.tsx, screens, assets

import type { AppSchema } from './appSchema';

export interface ExpoFile {
  path: string;
  content: string;
}

export function generateExpoFiles(schema: AppSchema): ExpoFile[] {
  const t = schema.theme;
  const files: ExpoFile[] = [];
  const appName = schema.name || 'MyApp';
  const slug = appName.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

  // 1. app.json
  files.push({
    path: 'app.json',
    content: JSON.stringify({
      expo: {
        name: appName,
        slug,
        version: '1.0.0',
        orientation: 'portrait',
        icon: './assets/icon.png',
        userInterfaceStyle: t.background === '#0a0a0a' || t.background === '#000000' ? 'dark' : 'light',
        splash: {
          image: './assets/splash.png',
          resizeMode: 'contain',
          backgroundColor: t.background,
        },
        assetBundlePatterns: ['**/*'],
        ios: {
          supportsTablet: true,
          bundleIdentifier: `com.lotus.${slug}`,
        },
        android: {
          adaptiveIcon: {
            foregroundImage: './assets/adaptive-icon.png',
            backgroundColor: t.background,
          },
          package: `com.lotus.${slug.replace(/-/g, '_')}`,
        },
        web: {
          favicon: './assets/favicon.png',
          bundler: 'metro',
        },
        plugins: ['expo-router'],
      },
    }, null, 2),
  });

  // 2. package.json
  files.push({
    path: 'package.json',
    content: JSON.stringify({
      name: slug,
      version: '1.0.0',
      main: 'expo/AppEntry',
      scripts: {
        start: 'expo start',
        android: 'expo start --android',
        ios: 'expo start --ios',
        web: 'expo start --web',
      },
      dependencies: {
        expo: '~50.0.0',
        'expo-status-bar': '~1.11.0',
        'expo-router': '~3.4.0',
        react: '18.2.0',
        'react-native': '0.73.0',
        'react-native-safe-area-context': '4.8.0',
        'react-native-screens': '~3.29.0',
        'react-native-gesture-handler': '~2.14.0',
        'react-native-reanimated': '~3.6.0',
        '@react-navigation/native': '^6.1.0',
        '@react-navigation/bottom-tabs': '^6.5.0',
        'lucide-react-native': '^0.300.0',
      },
      devDependencies: {
        '@babel/core': '^7.20.0',
        '@types/react': '~18.2.0',
        typescript: '^5.3.0',
      },
    }, null, 2),
  });

  // 3. babel.config.js
  files.push({
    path: 'babel.config.js',
    content: `module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'],
  };
};
`,
  });

  // 4. metro.config.js
  files.push({
    path: 'metro.config.js',
    content: `const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);
config.resolver.sourceExts.push('cjs');

module.exports = config;
`,
  });

  // 5. tsconfig.json
  files.push({
    path: 'tsconfig.json',
    content: JSON.stringify({ extends: 'expo/tsconfig/base' }, null, 2),
  });

  // 6. expo/AppEntry.js
  files.push({
    path: 'expo/AppEntry.js',
    content: `import registerRootComponent from 'expo/build/launch/registerRootComponent';
import App from '../src/App';

registerRootComponent(App);
`,
  });

  // 7. src/theme.ts
  files.push({
    path: 'src/theme.ts',
    content: `export const theme = {
  background: '${t.background}',
  primary: '${t.primary}',
  accent: '${t.accent}',
  text: '${t.text}',
  surface: '${t.surface}',
  border: '${t.border}',
} as const;
`,
  });

  // 8. src/assets.ts
  const assetEntries = Object.entries(schema.imageAssets || {});
  if (assetEntries.length > 0) {
    const lines = assetEntries.map(([id, data]) => `  '${id}': '${data}',`).join('\n');
    files.push({ path: 'src/assets.ts', content: `export const IMAGE_ASSETS: Record<string, string> = {\n${lines}\n};\n` });
  } else {
    files.push({ path: 'src/assets.ts', content: `export const IMAGE_ASSETS: Record<string, string> = {};\n` });
  }

  // 9. src/App.tsx
  const hasNav = schema.navigation.type === 'bottom-tabs' && schema.navigation.items.length > 0;
  let appCode = `import { StatusBar } from 'expo-status-bar';
import { View } from 'react-native';
import { useState } from 'react';
import { theme } from './theme';
`;
  for (const screen of schema.screens) {
    appCode += `import { ${toPascal(screen.name)}Screen } from './screens/${toPascal(screen.name)}Screen';\n`;
  }

  appCode += `
const SCREENS: Record<string, React.FC> = {
${schema.screens.map(s => `  '${s.id}': ${toPascal(s.name)}Screen,`).join('\n')}
};

export default function App() {
  const [activeScreen, setActiveScreen] = useState('${schema.activeScreenId}');
  const Screen = SCREENS[activeScreen] || SCREENS['${schema.screens[0]?.id}'];

  return (
    <View style={{ flex: 1, backgroundColor: theme.background }}>
      <View style={{ flex: 1 }}>
        <Screen />
      </View>
${hasNav ? generateExpoNav(schema) : '      <StatusBar style="' + (t.background === '#0a0a0a' || t.background === '#000000' ? 'light' : 'dark') + '" />'}
    </View>
  );
}
`;
  files.push({ path: 'src/App.tsx', content: appCode });

  // 10. Screen files
  for (const screen of schema.screens) {
    files.push({
      path: `src/screens/${toPascal(screen.name)}Screen.tsx`,
      content: generateExpoScreenFile(screen, schema),
    });
  }

  return files;
}

function generateExpoScreenFile(screen: AppSchema['screens'][0], schema: AppSchema): string {
  const t = schema.theme;
  let code = `import { View, Text, ScrollView, TouchableOpacity, TextInput, Image } from 'react-native';
import { useState } from 'react';
import { theme } from '../theme';
${Object.keys(schema.imageAssets || {}).length > 0 ? "import { IMAGE_ASSETS } from '../assets';" : ''}

export function ${toPascal(screen.name)}Screen() {
  return (
    <ScrollView style={{ flex: 1, backgroundColor: theme.background }} contentContainerStyle={{ paddingBottom: 40 }}>
${screen.components.map(c => renderExpoComponent(c, t, schema)).join('\n')}
    </ScrollView>
  );
}
`;
  return code;
}

function renderExpoComponent(component: AppSchema['screens'][0]['components'][0], theme: AppSchema['theme'], schema: AppSchema): string {
  const p = component.props || {};
  switch (component.type) {
    case 'header':
      return `      <View style={{ paddingHorizontal: 20, paddingTop: 60, paddingBottom: 16 }}>
        <Text style={{ fontSize: 28, fontWeight: '700', color: theme.text }}>${esc(p.title as string || 'Title')}</Text>
        ${p.subtitle ? `<Text style={{ fontSize: 15, color: '${theme.text}', opacity: 0.5, marginTop: 4 }}>${esc(p.subtitle as string)}</Text>` : ''}
      </View>`;
    case 'text':
      return `      <Text style={{ fontSize: ${p.size === 'large' ? 18 : p.size === 'small' ? 13 : 15}, color: theme.text, opacity: 0.7, paddingHorizontal: 20, paddingVertical: 8 }}>${esc(p.content as string || '')}</Text>`;
    case 'button':
      return `      <TouchableOpacity style={{ backgroundColor: '${p.variant === 'secondary' ? theme.surface : theme.primary}', marginHorizontal: 20, paddingVertical: 14, paddingHorizontal: 20, borderRadius: 12, marginVertical: 8, alignItems: 'center' }}>
        <Text style={{ color: '${p.variant === 'secondary' ? theme.text : '#ffffff'}', fontSize: 15, fontWeight: '600' }}>${esc(p.label as string || 'Button')}</Text>
      </TouchableOpacity>`;
    case 'input':
      return `      <TextInput placeholder="${esc(p.placeholder as string || 'Enter...')}" style={{ backgroundColor: theme.surface, color: theme.text, marginHorizontal: 20, paddingHorizontal: 16, paddingVertical: 14, borderRadius: 12, fontSize: 15, marginVertical: 8, borderWidth: 1, borderColor: theme.border }} placeholderTextColor="${theme.text}40" />`;
    case 'card':
      return `      <View style={{ backgroundColor: theme.surface, marginHorizontal: 20, padding: 20, borderRadius: 16, marginVertical: 8 }}>
        <Text style={{ fontSize: 16, fontWeight: '600', color: theme.text, marginBottom: 8 }}>${esc(p.title as string || 'Card')}</Text>
        <Text style={{ fontSize: 14, color: theme.text, opacity: 0.6 }}>${esc(p.content as string || '')}</Text>
      </View>`;
    case 'image':
      const imgId = p.assetId as string;
      const imgUrl = p.url as string;
      if (imgId && schema.imageAssets?.[imgId]) {
        return `      <Image source={{ uri: IMAGE_ASSETS['${imgId}'] }} style={{ width: '100%', height: 200, marginHorizontal: 20, borderRadius: 12, marginVertical: 8 }} resizeMode="cover" />`;
      }
      if (imgUrl) {
        return `      <Image source={{ uri: '${imgUrl}' }} style={{ width: '100%', height: 200, marginHorizontal: 20, borderRadius: 12, marginVertical: 8 }} resizeMode="cover" />`;
      }
      return `      <View style={{ backgroundColor: theme.surface, marginHorizontal: 20, height: 200, borderRadius: 12, marginVertical: 8, justifyContent: 'center', alignItems: 'center' }}>
        <Text style={{ color: theme.text, opacity: 0.3 }}>Image</Text>
      </View>`;
    case 'list':
      return `      <View style={{ marginVertical: 8 }}>
        ${(p.items as string[] || ['Item 1', 'Item 2', 'Item 3']).map(item =>
          `<View key="${item}" style={{ flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: theme.border + '20' }}>
          <Text style={{ flex: 1, fontSize: 15, color: theme.text }}>${esc(item)}</Text>
          <Text style={{ color: theme.text, opacity: 0.3 }}>{'>'}</Text>
        </View>`).join('\n        ')}
      </View>`;
    default:
      return `      <View style={{ padding: 20 }}><Text style={{ color: theme.text }}>${esc(component.type)}</Text></View>`;
  }
}

function generateExpoNav(schema: AppSchema): string {
  return `      <View style={{ flexDirection: 'row', backgroundColor: '${schema.theme.surface}', paddingBottom: 20, paddingTop: 12, borderTopWidth: 1, borderTopColor: '${schema.theme.border}30' }}>
${schema.navigation.items.map(item =>
  `        <TouchableOpacity key="${item.screenId}" onPress={() => setActiveScreen('${item.screenId}')} style={{ flex: 1, alignItems: 'center' }}>
          <Text style={{ fontSize: 12, color: '${item.screenId === schema.activeScreenId ? schema.theme.primary : schema.theme.text}', opacity: ${item.screenId === schema.activeScreenId ? 1 : 0.5} }}>${esc(item.label)}</Text>
        </TouchableOpacity>`).join('\n')}
      </View>
      <StatusBar style="${schema.theme.background === '#0a0a0a' || schema.theme.background === '#000000' ? 'light' : 'dark'}" />`;
}

function toPascal(str: string): string {
  return str.replace(/(?:^|[-_\s])(\w)/g, (_, c) => (c ? c.toUpperCase() : ''));
}

function esc(str: string): string {
  return (str || '').replace(/[\\']/g, '\\$&');
}
