// App Renderer — Schema-driven preview renderer
// Phase 5: real inputs, desktop layout, actions, navigation

import { type ReactNode, useState, useCallback } from 'react';
import type { AppSchema, AppComponent } from './appSchema';
import {
  Home, User, Settings, Dumbbell, Sparkles, Heart, LayoutDashboard,
  BarChart3, Search, Footprints, Flame, Trophy, DollarSign, Users,
  ShoppingBag, TrendingUp, Bell, Shield, Palette, Mail, Lock,
  Bookmark, Activity, Briefcase, CircleDot, ChevronRight, Circle,
  type LucideIcon,
} from 'lucide-react';

const iconMap: Record<string, LucideIcon> = {
  home: Home, user: User, settings: Settings, dumbbell: Dumbbell,
  sparkles: Sparkles, heart: Heart, 'layout-dashboard': LayoutDashboard,
  'bar-chart-3': BarChart3, search: Search, footprints: Footprints,
  flame: Flame, trophy: Trophy, 'dollar-sign': DollarSign, users: Users,
  'shopping-bag': ShoppingBag, 'trending-up': TrendingUp, bell: Bell,
  shield: Shield, palette: Palette, mail: Mail, lock: Lock,
  bookmark: Bookmark, activity: Activity, briefcase: Briefcase,
  'circle-dot': CircleDot, 'chevron-right': ChevronRight, circle: Circle,
};

function getIcon(name: string): LucideIcon {
  return iconMap[name] || Circle;
}

function str(props: Record<string, unknown>, key: string, fallback = ''): string {
  return (props[key] as string) || fallback;
}

function bool(props: Record<string, unknown>, key: string): boolean {
  return !!props[key];
}

interface RenderProps {
  schema: AppSchema;
  onNavigate: (screenId: string) => void;
  isDesktop?: boolean;
}

// ─── Component Renderers ──────────────────────────────────────────────────────

function HeaderComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const title = str(props, 'title');
  const subtitle = str(props, 'subtitle');
  return (
    <div className="px-4 pt-6 pb-4" style={{ background: `linear-gradient(135deg, ${theme.primary}22, transparent)` }}>
      <div className="flex items-center justify-between">
        <div className="flex-1">
          <h1 className="text-xl font-bold" style={{ color: theme.text }}>{title}</h1>
          {subtitle ? <p className="text-sm mt-0.5 opacity-60" style={{ color: theme.text }}>{subtitle}</p> : null}
        </div>
        {bool(props, 'showAvatar') ? (
          <div className="w-9 h-9 rounded-full flex items-center justify-center text-sm font-semibold" style={{ backgroundColor: `${theme.primary}33`, color: theme.primary }}>
            {title[0] || 'U'}
          </div>
        ) : null}
      </div>
      {bool(props, 'showSearch') ? (
        <div className="mt-3 px-3 py-2 rounded-lg text-sm opacity-50 flex items-center gap-2" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}`, color: theme.text }}>
          <Search size={14} /><span>Search...</span>
        </div>
      ) : null}
    </div>
  );
}

function TextComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const align = str(props, 'align', 'left');
  const size = str(props, 'size', 'md');
  const color = str(props, 'color', theme.text);
  const content = str(props, 'content');
  const sizeClasses: Record<string, string> = { sm: 'text-xs', md: 'text-sm', lg: 'text-base', xl: 'text-lg' };
  return (
    <p className={`px-4 py-2 ${sizeClasses[size] || 'text-sm'}`} style={{ textAlign: align as 'left' | 'center' | 'right', color: color === 'primary' ? theme.primary : theme.text, opacity: color === 'primary' ? 1 : 0.8 }}>
      {content}
    </p>
  );
}

// Preview toast — shows feedback for demo button actions
let toastTimer: ReturnType<typeof setTimeout> | null = null;
function showPreviewToast(message: string) {
  const existing = document.getElementById('preview-toast');
  if (existing) existing.remove();
  if (toastTimer) clearTimeout(toastTimer);

  const toast = document.createElement('div');
  toast.id = 'preview-toast';
  toast.className = 'absolute bottom-16 left-1/2 -translate-x-1/2 px-3 py-1.5 rounded-lg bg-[#1a1a1a] border border-white/10 text-[10px] text-white/50 shadow-lg whitespace-nowrap z-50';
  toast.textContent = message;
  document.querySelector('[data-preview-root]')?.appendChild(toast) || document.body.appendChild(toast);

  toastTimer = setTimeout(() => toast.remove(), 2000);
}

function ButtonComponent({ props, theme, onNavigate }: { props: Record<string, unknown>; theme: AppSchema['theme']; onNavigate?: (target: string) => void }): ReactNode {
  const variant = str(props, 'variant', 'primary');
  const isPrimary = variant === 'primary';
  const label = str(props, 'label');
  const actionLabel = str(props, 'action');
  const navigateTo = str(props, 'navigateTo');
  const actionType = str(props, 'actionType');

  const handleClick = () => {
    if (navigateTo && onNavigate) {
      onNavigate(navigateTo);
      return;
    }
    const type = actionType || str(props, 'type');
    switch (type) {
      case 'navigate':
        if (str(props, 'targetScreen') && onNavigate) onNavigate(str(props, 'targetScreen'));
        break;
      case 'submit':
        showPreviewToast('Submitted (demo)');
        break;
      case 'toggle':
        showPreviewToast('Toggled (demo)');
        break;
      case 'openModal':
        showPreviewToast('Modal opened (demo)');
        break;
      default:
        break;
    }
  };

  return (
    <div className={`px-4 py-1.5 ${bool(props, 'fullWidth') ? 'w-full' : ''}`}>
      <button
        onClick={handleClick}
        className="w-full py-3 rounded-xl font-medium text-sm transition-all active:scale-[0.98]"
        style={{ backgroundColor: isPrimary ? theme.primary : 'transparent', color: isPrimary ? '#ffffff' : theme.text, border: variant === 'outline' ? `1px solid ${theme.border}` : 'none' }}
      >
        {label}
        {actionLabel ? <span className="ml-2 opacity-60">{actionLabel}</span> : null}
      </button>
    </div>
  );
}

function InputComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const [value, setValue] = useState(str(props, 'value'));
  const iconName = str(props, 'icon');
  const IconComponent = iconName ? getIcon(iconName) : null;
  const placeholder = str(props, 'placeholder');
  const type = str(props, 'type', 'text');

  return (
    <div className="px-4 py-1.5">
      <div className="flex items-center gap-2 px-3 py-3 rounded-xl" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}` }}>
        {IconComponent ? <IconComponent size={16} style={{ color: theme.text, opacity: 0.4 }} /> : null}
        <input
          type={type === 'password' ? 'password' : 'text'}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          placeholder={placeholder}
          className="flex-1 bg-transparent text-sm outline-none"
          style={{ color: theme.text }}
        />
      </div>
    </div>
  );
}

function CardComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const isHighlight = bool(props, 'highlight');
  return (
    <div className="px-4 py-1.5">
      <div className="p-4 rounded-xl" style={{ backgroundColor: isHighlight ? `${theme.primary}15` : theme.surface, border: `1px solid ${isHighlight ? `${theme.primary}30` : theme.border}` }}>
        <div className="flex items-center justify-between">
          <div className="flex-1">
            <h3 className="text-sm font-semibold" style={{ color: theme.text }}>{str(props, 'title')}</h3>
            {props.subtitle ? <p className="text-xs mt-0.5 opacity-50" style={{ color: theme.text }}>{str(props, 'subtitle')}</p> : null}
          </div>
          {props.icon ? (
            <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${theme.primary}22` }}>
              <IconEl name={str(props, 'icon')} size={14} color={theme.primary} />
            </div>
          ) : null}
          {props.action ? (
            <span className="text-xs font-medium px-3 py-1 rounded-lg" style={{ backgroundColor: theme.primary, color: '#fff' }}>{str(props, 'action')}</span>
          ) : null}
          {!props.icon && !props.action ? <ChevronRight size={16} style={{ color: theme.text, opacity: 0.3 }} /> : null}
        </div>
      </div>
    </div>
  );
}

function IconEl({ name, size, color }: { name: string; size: number; color: string }): ReactNode {
  const Icon = getIcon(name);
  return <Icon size={size} color={color} />;
}

function ListComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const items = (props.items as Array<Record<string, string>>) || [];
  return (
    <div className="px-4 py-1.5">
      <div className="rounded-xl overflow-hidden" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}` }}>
        {items.map((item, index) => (
          <div key={index} className="flex items-center justify-between px-4 py-3" style={{ borderBottom: index < items.length - 1 ? `1px solid ${theme.border}` : 'none' }}>
            <div className="flex items-center gap-3">
              {item.icon ? (
                <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ backgroundColor: `${theme.primary}18` }}>
                  <IconEl name={item.icon} size={14} color={theme.primary} />
                </div>
              ) : null}
              <div>
                <p className="text-sm font-medium" style={{ color: theme.text }}>{item.title}</p>
                {(item.duration || item.level || item.value) ? <p className="text-xs opacity-50" style={{ color: theme.text }}>{item.duration || item.level || item.value}</p> : null}
              </div>
            </div>
            <ChevronRight size={14} style={{ color: theme.text, opacity: 0.3 }} />
          </div>
        ))}
      </div>
    </div>
  );
}

function GridComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const items = (props.items as Array<Record<string, string>>) || [];
  const columns = (props.columns as number) || 2;
  return (
    <div className="px-4 py-2">
      <div className={`grid gap-2 ${columns === 3 ? 'grid-cols-3' : columns === 4 ? 'grid-cols-4' : 'grid-cols-2'}`}>
        {items.map((item, index) => (
          <div key={index} className="p-3 rounded-xl text-center" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}` }}>
            {item.icon ? <div className="flex justify-center mb-1.5"><IconEl name={item.icon} size={18} color={theme.primary} /></div> : null}
            <p className="text-base font-bold" style={{ color: theme.text }}>{item.value}</p>
            <p className="text-xs opacity-50 mt-0.5" style={{ color: theme.text }}>{item.label}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function AvatarComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const size = str(props, 'size');
  const name = str(props, 'name');
  const subtitle = str(props, 'subtitle');
  const sizeClasses = size === 'lg' ? 'w-20 h-20 text-2xl' : size === 'sm' ? 'w-10 h-10 text-xs' : 'w-14 h-14 text-lg';
  return (
    <div className="px-4 py-4 flex flex-col items-center">
      <div className={`${sizeClasses} rounded-full flex items-center justify-center font-bold mb-2`} style={{ backgroundColor: `${theme.primary}25`, color: theme.primary, border: `2px solid ${theme.primary}40` }}>
        {name.split(' ').map(n => n[0]).join('').substring(0, 2) || 'U'}
      </div>
      <h3 className="text-base font-semibold" style={{ color: theme.text }}>{name}</h3>
      {subtitle ? <p className="text-xs opacity-50" style={{ color: theme.text }}>{subtitle}</p> : null}
    </div>
  );
}

function ProgressComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const value = (props.value as number) || 0;
  const color = str(props, 'color', theme.primary);
  return (
    <div className="px-4 py-2">
      <div className="flex items-center justify-between mb-1.5">
        <span className="text-xs font-medium" style={{ color: theme.text, opacity: 0.7 }}>{str(props, 'label')}</span>
        <span className="text-xs font-bold" style={{ color }}>{value}%</span>
      </div>
      <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: theme.border }}>
        <div className="h-full rounded-full transition-all duration-500" style={{ width: `${value}%`, backgroundColor: color }} />
      </div>
    </div>
  );
}

function TabsComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const [active, setActive] = useState(str(props, 'activeTab') || ((props.items as string[])?.[0] || ''));
  const items = (props.items as string[]) || [];
  return (
    <div className="px-4 py-2">
      <div className="flex gap-1 p-1 rounded-xl" style={{ backgroundColor: theme.surface }}>
        {items.map((item) => (
          <button key={item} onClick={() => setActive(item)} className="flex-1 py-2 rounded-lg text-xs font-medium transition-all" style={{ backgroundColor: item === active ? theme.primary : 'transparent', color: item === active ? '#ffffff' : theme.text, opacity: item === active ? 1 : 0.5 }}>
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}

function DividerComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const label = str(props, 'label');
  return (
    <div className="px-4 py-3 flex items-center gap-3">
      <div className="flex-1 h-px" style={{ backgroundColor: theme.border }} />
      {label ? <span className="text-xs opacity-40" style={{ color: theme.text }}>{label}</span> : null}
      <div className="flex-1 h-px" style={{ backgroundColor: theme.border }} />
    </div>
  );
}

function SpacerComponent({ props }: { props: Record<string, unknown> }): ReactNode {
  const size = str(props, 'size');
  const heights: Record<string, string> = { sm: 'h-2', md: 'h-4', lg: 'h-8', xl: 'h-12' };
  return <div className={heights[size] || 'h-4'} />;
}

function ChartComponent({ props, theme }: { props: Record<string, unknown>; theme: AppSchema['theme'] }): ReactNode {
  const chartType = str(props, 'type', 'bar');
  const label = str(props, 'label');
  if (chartType === 'bar') {
    const bars = [65, 40, 80, 55, 90, 70];
    return (
      <div className="px-4 py-2">
        <p className="text-xs font-medium mb-3 opacity-60" style={{ color: theme.text }}>{label}</p>
        <div className="flex items-end gap-2 h-24">
          {bars.map((height, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-1">
              <div className="w-full rounded-t-md transition-all duration-500" style={{ height: `${height}%`, backgroundColor: i === 4 ? theme.primary : `${theme.primary}50` }} />
            </div>
          ))}
        </div>
      </div>
    );
  }
  return (
    <div className="px-4 py-2">
      <p className="text-xs font-medium mb-3 opacity-60" style={{ color: theme.text }}>{label}</p>
      <div className="h-24 flex items-end gap-1">
        {[40, 55, 45, 70, 60, 85, 75].map((h, i) => (
          <div key={i} className="flex-1 flex flex-col items-center">
            <div className="w-full rounded-t-sm" style={{ height: `${h}%`, backgroundColor: `${theme.primary}${i === 5 ? '' : '60'}` }} />
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Single Component Renderer ────────────────────────────────────────────────

function RenderComponent({ component, theme, schema, onNavigate }: { component: AppComponent; theme: AppSchema['theme']; schema: AppSchema; onNavigate?: (screenId: string) => void }): ReactNode {
  switch (component.type) {
    case 'header': return <HeaderComponent props={component.props} theme={theme} />;
    case 'text': return <TextComponent props={component.props} theme={theme} />;
    case 'button': return <ButtonComponent props={component.props} theme={theme} onNavigate={onNavigate} />;
    case 'input': return <InputComponent props={component.props} theme={theme} />;
    case 'card': return <CardComponent props={component.props} theme={theme} />;
    case 'list': return <ListComponent props={component.props} theme={theme} />;
    case 'grid': return <GridComponent props={component.props} theme={theme} />;
    case 'avatar': return <AvatarComponent props={component.props} theme={theme} />;
    case 'progress': return <ProgressComponent props={component.props} theme={theme} />;
    case 'tabs': return <TabsComponent props={component.props} theme={theme} />;
    case 'divider': return <DividerComponent props={component.props} theme={theme} />;
    case 'spacer': return <SpacerComponent props={component.props} />;
    case 'chart': return <ChartComponent props={component.props} theme={theme} />;
    case 'image': {
      const imgId = str(component.props, 'assetId');
      const imgSrc = imgId ? schema.imageAssets?.[imgId] : null;
      const imgUrl = str(component.props, 'url');
      return (
        <div className="px-4 py-1.5">
          {imgSrc || imgUrl ? (
            <img src={imgSrc || imgUrl} alt={str(component.props, 'alt', 'Image')} className="w-full h-32 rounded-xl object-cover" />
          ) : (
            <div className="w-full h-32 rounded-xl flex items-center justify-center" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}` }}>
              <span className="text-xs opacity-30" style={{ color: theme.text }}>Image</span>
            </div>
          )}
        </div>
      );
    }
    case 'badge':
      return <div className="px-4 py-1"><span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium" style={{ backgroundColor: `${theme.primary}20`, color: theme.primary }}>{str(component.props, 'label')}</span></div>;
    case 'search':
      return <div className="px-4 py-2"><div className="flex items-center gap-2 px-3 py-2.5 rounded-xl" style={{ backgroundColor: theme.surface, border: `1px solid ${theme.border}` }}><Search size={16} style={{ color: theme.text, opacity: 0.4 }} /><span className="text-sm opacity-40" style={{ color: theme.text }}>Search...</span></div></div>;
    default: return null;
  }
}

// ─── Screen Renderer ──────────────────────────────────────────────────────────

function RenderScreen({ screen, theme, schema, onNavigate }: { screen: AppSchema['screens'][0]; theme: AppSchema['theme']; schema: AppSchema; onNavigate?: (screenId: string) => void }): ReactNode {
  return (
    <div className="flex-1 overflow-y-auto pb-4">
      {screen.components.map((component) => (
        <RenderComponent key={component.id} component={component} theme={theme} schema={schema} onNavigate={onNavigate} />
      ))}
    </div>
  );
}

// ─── Bottom Navigation ────────────────────────────────────────────────────────

function BottomNav({ navigation, activeScreenId, theme, onNavigate }: {
  navigation: AppSchema['navigation'];
  activeScreenId: string;
  theme: AppSchema['theme'];
  onNavigate: (screenId: string) => void;
}): ReactNode {
  if (navigation.type !== 'bottom-tabs' || navigation.items.length === 0) return null;

  return (
    <div className="flex items-center justify-around px-2 py-2 shrink-0" style={{ backgroundColor: `${theme.surface}ee`, borderTop: `1px solid ${theme.border}`, backdropFilter: 'blur(12px)' }}>
      {navigation.items.map((item) => {
        const isActive = item.screenId === activeScreenId;
        const Icon = getIcon(item.icon);
        return (
          <button key={item.id} className="flex flex-col items-center gap-0.5 py-1 px-3 rounded-lg transition-all" onClick={() => onNavigate(item.screenId)} style={{ color: isActive ? theme.primary : `${theme.text}60` }}>
            <Icon size={20} strokeWidth={isActive ? 2.5 : 1.5} />
            <span className="text-[10px] font-medium">{item.label}</span>
          </button>
        );
      })}
    </div>
  );
}

// ─── Desktop Layout Renderer ──────────────────────────────────────────────────

function DesktopLayout({ schema, onNavigate }: { schema: AppSchema; onNavigate: (screenId: string) => void }): ReactNode {
  const t = schema.theme;
  const activeScreen = schema.screens.find(s => s.id === schema.activeScreenId) || schema.screens[0];

  return (
    <div className="flex flex-col h-full" style={{ backgroundColor: t.background, color: t.text }}>
      {/* Desktop top nav */}
      <div className="flex items-center justify-between px-6 py-3 shrink-0" style={{ borderBottom: `1px solid ${t.border}` }}>
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md flex items-center justify-center text-xs font-bold" style={{ backgroundColor: `${t.primary}33`, color: t.primary }}>
            {schema.name[0] || 'A'}
          </div>
          <span className="text-sm font-semibold">{schema.name}</span>
        </div>
        <div className="flex items-center gap-1">
          {schema.screens.map(screen => (
            <button
              key={screen.id}
              onClick={() => onNavigate(screen.id)}
              className="px-3 py-1.5 rounded-lg text-xs font-medium transition-all"
              style={{
                backgroundColor: screen.id === schema.activeScreenId ? `${t.primary}20` : 'transparent',
                color: screen.id === schema.activeScreenId ? t.primary : `${t.text}60`,
              }}
            >
              {screen.name}
            </button>
          ))}
        </div>
      </div>
      {/* Content */}
      <div className="flex-1 overflow-y-auto p-6">
        {activeScreen ? <RenderScreen screen={activeScreen} theme={t} schema={schema} onNavigate={onNavigate} /> : null}
      </div>
    </div>
  );
}

// ─── Main App Renderer ────────────────────────────────────────────────────────

export function AppRenderer({ schema, onNavigate, isDesktop }: RenderProps): ReactNode {
  const activeScreen = schema.screens.find(s => s.id === schema.activeScreenId) || schema.screens[0];

  const handleNavigate = useCallback((screenId: string) => {
    onNavigate(screenId);
  }, [onNavigate]);

  // Desktop layout
  if (isDesktop) {
    return <DesktopLayout schema={schema} onNavigate={handleNavigate} />;
  }

  // Mobile/tablet layout
  return (
    <div className="flex flex-col h-full w-full overflow-hidden" style={{ backgroundColor: schema.theme.background }}>
      {activeScreen ? <RenderScreen screen={activeScreen} theme={schema.theme} schema={schema} onNavigate={handleNavigate} /> : null}
      <BottomNav navigation={schema.navigation} activeScreenId={schema.activeScreenId} theme={schema.theme} onNavigate={handleNavigate} />
    </div>
  );
}

export default AppRenderer;
