// GitHub Token Storage — Supabase-backed (replaces localStorage)
// Stores GitHub PAT in user_profiles.github_token column
// Session cache for synchronous access during active use

import { supabase } from '@/lib/supabase/client';

export interface GitHubUser {
  login: string;
  avatar_url: string;
  name?: string;
}

// ─── Session Cache ────────────────────────────────────────────────────────────
// In-memory cache for the current session — cleared on logout

const _tokenCache = new Map<string, string>();
const _userCache = new Map<string, GitHubUser>();

// ─── Supabase-backed Operations ───────────────────────────────────────────────

async function getTokenFromDb(userId: string): Promise<string | null> {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('github_token')
    .eq('id', userId)
    .single();

  if (error || !data?.github_token) return null;
  return data.github_token as string;
}

async function setTokenInDb(userId: string, token: string | null): Promise<void> {
  const { error } = await supabase
    .from('user_profiles')
    .update({ github_token: token, updated_at: new Date().toISOString() })
    .eq('id', userId);

  if (error) console.error('setToken error:', error);
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function loadGitHubToken(userId: string): Promise<string | null> {
  if (!userId) return null;
  // Check cache first
  const cached = _tokenCache.get(userId);
  if (cached) return cached;
  // Fall back to DB
  const token = await getTokenFromDb(userId);
  if (token) _tokenCache.set(userId, token);
  return token;
}

// Synchronous version for githubClient (uses session cache)
export function getCachedGitHubToken(): string | null {
  // Return the first cached token (single-user session)
  for (const [, token] of _tokenCache) {
    return token;
  }
  return null;
}

export async function saveGitHubToken(userId: string, token: string): Promise<void> {
  if (!userId) return;
  _tokenCache.set(userId, token);
  await setTokenInDb(userId, token);
}

export async function clearGitHubToken(userId: string): Promise<void> {
  if (!userId) return;
  _tokenCache.delete(userId);
  _userCache.delete(userId);
  await setTokenInDb(userId, null);
}

export function saveGitHubUser(userId: string, user: GitHubUser): void {
  _userCache.set(userId, user);
}

export function loadGitHubUser(userId: string): GitHubUser | null {
  return _userCache.get(userId) || null;
}

export async function hasGitHubToken(userId: string): Promise<boolean> {
  if (!userId) return false;
  const cached = _tokenCache.get(userId);
  if (cached && cached.length > 10) return true;
  const token = await getTokenFromDb(userId);
  return !!token && token.length > 10;
}

export function maskToken(token: string): string {
  if (token.length <= 12) return '****';
  return `${token.slice(0, 6)}...${token.slice(-4)}`;
}
