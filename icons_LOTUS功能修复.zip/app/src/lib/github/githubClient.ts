// GitHub API Client — Browser-side, uses user's Personal Access Token
// All calls go directly to api.github.com from the browser.

import { getCachedGitHubToken } from './githubStorage';

const API_BASE = 'https://api.github.com';

function getHeaders(): Record<string, string> {
  const token = getCachedGitHubToken();
  return {
    'Accept': 'application/vnd.github+json',
    'Authorization': `Bearer ${token || ''}`,
    'X-GitHub-Api-Version': '2022-11-28',
    'Content-Type': 'application/json',
  };
}

function handleResponse(response: Response): Promise<unknown> {
  if (!response.ok) {
    return response.json().then((data: Record<string, unknown>) => {
      throw new Error((data.message as string) || `GitHub API error: ${response.status}`);
    }).catch(() => {
      throw new Error(`GitHub API error: ${response.status}`);
    });
  }
  return response.json();
}

// ─── Auth ─────────────────────────────────────────────────────────────────────

export async function verifyToken(): Promise<{ login: string; avatar_url: string; name?: string }> {
  const response = await fetch(`${API_BASE}/user`, { headers: getHeaders() });
  return handleResponse(response) as Promise<{ login: string; avatar_url: string; name?: string }>;
}

// ─── Repos ────────────────────────────────────────────────────────────────────

export interface GitHubRepo {
  id: number;
  name: string;
  full_name: string;
  description: string | null;
  html_url: string;
  default_branch: string;
  private: boolean;
  updated_at: string;
}

export async function listRepos(): Promise<GitHubRepo[]> {
  const response = await fetch(`${API_BASE}/user/repos?sort=updated&per_page=100`, { headers: getHeaders() });
  return handleResponse(response) as Promise<GitHubRepo[]>;
}

export async function createRepo(name: string, description?: string, isPrivate = false): Promise<GitHubRepo> {
  const response = await fetch(`${API_BASE}/user/repos`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({
      name,
      description: description || `App built with LOTUS App Builder`,
      private: isPrivate,
      auto_init: true,
    }),
  });
  return handleResponse(response) as Promise<GitHubRepo>;
}

export async function getRepo(owner: string, repo: string): Promise<GitHubRepo> {
  const response = await fetch(`${API_BASE}/repos/${owner}/${repo}`, { headers: getHeaders() });
  return handleResponse(response) as Promise<GitHubRepo>;
}

// ─── Contents ─────────────────────────────────────────────────────────────────

export interface RepoContent {
  name: string;
  path: string;
  type: 'file' | 'dir';
  sha: string;
  size: number;
  content?: string;
  encoding?: string;
  html_url?: string;
}

export async function getContents(owner: string, repo: string, path = '', ref?: string): Promise<RepoContent[]> {
  const url = new URL(`${API_BASE}/repos/${owner}/${repo}/contents/${path}`);
  if (ref) url.searchParams.set('ref', ref);
  const response = await fetch(url.toString(), { headers: getHeaders() });
  const data = await handleResponse(response);
  return Array.isArray(data) ? (data as RepoContent[]) : [(data as RepoContent)];
}

export async function getFileContent(owner: string, repo: string, path: string, ref?: string): Promise<string> {
  const url = new URL(`${API_BASE}/repos/${owner}/${repo}/contents/${path}`);
  if (ref) url.searchParams.set('ref', ref);
  const response = await fetch(url.toString(), { headers: getHeaders() });
  const data = await handleResponse(response) as { content: string; encoding: string };
  if (data.encoding === 'base64') {
    return atob(data.content.replace(/\n/g, ''));
  }
  return data.content;
}

// ─── Git Operations (create/update files) ─────────────────────────────────────

export async function createOrUpdateFile(
  owner: string,
  repo: string,
  path: string,
  content: string,
  message: string,
  sha?: string
): Promise<{ content: { html_url: string } }> {
  const body: Record<string, string> = {
    message,
    content: btoa(content),
  };
  if (sha) body.sha = sha;

  const response = await fetch(`${API_BASE}/repos/${owner}/${repo}/contents/${path}`, {
    method: 'PUT',
    headers: getHeaders(),
    body: JSON.stringify(body),
  });
  return handleResponse(response) as Promise<{ content: { html_url: string } }>;
}

// ─── Bulk Export ──────────────────────────────────────────────────────────────

export interface ExportFile {
  path: string;
  content: string;
}

export async function exportToRepo(
  owner: string,
  repo: string,
  files: ExportFile[],
  branch = 'main'
): Promise<{ url: string; filesPushed: number }> {
  // Get the current ref to find the latest commit SHA
  const refResponse = await fetch(`${API_BASE}/repos/${owner}/${repo}/git/ref/heads/${branch}`, {
    headers: getHeaders(),
  });
  const refData = await handleResponse(refResponse) as { object: { sha: string } };
  const latestCommitSha = refData.object.sha;

  // Get the current tree
  const commitResponse = await fetch(`${API_BASE}/repos/${owner}/${repo}/git/commits/${latestCommitSha}`, {
    headers: getHeaders(),
  });
  const commitData = await commitResponse.json() as { tree: { sha: string } };
  const baseTreeSha = commitData.tree.sha;

  // Create a new tree with all files
  const treeItems = files.map(f => ({
    path: f.path,
    mode: '100644' as const,
    type: 'blob' as const,
    content: f.content,
  }));

  const treeResponse = await fetch(`${API_BASE}/repos/${owner}/${repo}/git/trees`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({
      base_tree: baseTreeSha,
      tree: treeItems,
    }),
  });
  const treeData = await treeResponse.json() as { sha: string };

  // Create a new commit
  const newCommitResponse = await fetch(`${API_BASE}/repos/${owner}/${repo}/git/commits`, {
    method: 'POST',
    headers: getHeaders(),
    body: JSON.stringify({
      message: 'Update from LOTUS App Builder',
      tree: treeData.sha,
      parents: [latestCommitSha],
    }),
  });
  const newCommitData = await newCommitResponse.json() as { sha: string };

  // Update the branch reference
  await fetch(`${API_BASE}/repos/${owner}/${repo}/git/refs/heads/${branch}`, {
    method: 'PATCH',
    headers: getHeaders(),
    body: JSON.stringify({ sha: newCommitData.sha }),
  });

  return {
    url: `https://github.com/${owner}/${repo}`,
    filesPushed: files.length,
  };
}

// ─── Import ───────────────────────────────────────────────────────────────────

export async function importFromRepo(owner: string, repo: string, branch = 'main'): Promise<ExportFile[]> {
  const files: ExportFile[] = [];

  async function walkDir(path: string) {
    const contents = await getContents(owner, repo, path, branch);
    for (const item of contents) {
      if (item.type === 'dir') {
        await walkDir(item.path);
      } else if (item.type === 'file' && item.size < 500000) { // Skip files > 500KB
        try {
          const content = await getFileContent(owner, repo, item.path, branch);
          files.push({ path: item.path, content });
        } catch {
          // Skip files we can't read
        }
      }
    }
  }

  await walkDir('');
  return files;
}
