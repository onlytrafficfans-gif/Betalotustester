// Skills & Agents — Pre-installed library
// Skills are single actions. Agents are multi-step workflows.
// Format: { id, name, type: 'skill'|'agent', category, icon, description, prompt }
// STORAGE: Use src/lib/supabase/skillsStorage.ts for user-imported skills (NOT localStorage)

export type SkillType = 'skill' | 'agent';
export type SkillCategory = 'ui' | 'agent' | 'workflow' | 'integration' | 'theme';

export interface Skill {
  id: string;
  name: string;
  type: SkillType;
  category: SkillCategory;
  description: string;
  prompt: string;
  icon: string; // lucide icon name
  tags: string[];
  isDefault: boolean; // Pre-installed, cannot be deleted
}

// ─── Pre-installed Skills ─────────────────────────────────────────────────────

export const DEFAULT_SKILLS: Skill[] = [
  // ─── Agent Skills ──────────────────────────────────────────────────────────
  {
    id: 'build-agent',
    name: 'Build me an agent',
    type: 'agent',
    category: 'agent',
    description: 'Create a full AI agent app with chat, avatar, and personality',
    prompt: 'Build me an AI agent app with a chat interface. Include: a welcome screen with the agent avatar and greeting, a chat screen with message bubbles (user right, agent left), a typing indicator, suggested prompts at the start of the conversation, and a clean input area at the bottom. Make it feel alive and conversational.',
    icon: 'Sparkles',
    tags: ['agent', 'chat', 'ai'],
    isDefault: true,
  },
  {
    id: 'add-chat-interface',
    name: 'Add chat interface',
    type: 'skill',
    category: 'ui',
    description: 'Add a messaging screen with bubbles and input',
    prompt: 'Add a chat screen with message bubbles, a text input at the bottom with a send button, and timestamps. Style it like a modern messaging app with smooth scrolling.',
    icon: 'Bot',
    tags: ['chat', 'messaging', 'ui'],
    isDefault: true,
  },
  {
    id: 'add-ai-assistant',
    name: 'Add AI assistant',
    type: 'skill',
    category: 'agent',
    description: 'Add a bot avatar with welcome and suggested prompts',
    prompt: 'Add an AI assistant screen with a bot avatar at the top, a welcome message like "Hi! How can I help you today?", 3-4 suggested prompt buttons (e.g., "Help me plan", "Write something", "Explain"), and a chat input area at the bottom.',
    icon: 'MessageSquare',
    tags: ['assistant', 'bot', 'ai'],
    isDefault: true,
  },
  {
    id: 'add-typing-indicator',
    name: 'Add typing indicator',
    type: 'skill',
    category: 'ui',
    description: 'Animated dots showing the agent is thinking',
    prompt: 'Add a typing indicator component with 3 animated dots that bounce up and down. Show it when the agent is "thinking". Use a subtle pulse animation.',
    icon: 'Activity',
    tags: ['animation', 'chat', 'ui'],
    isDefault: true,
  },

  // ─── UI Skills ─────────────────────────────────────────────────────────────
  {
    id: 'add-login',
    name: 'Add login screen',
    type: 'skill',
    category: 'ui',
    description: 'Email/password fields with validation',
    prompt: 'Add a login screen with email and password fields, a sign in button, and a "Forgot password?" link. Style it clean and modern.',
    icon: 'Lock',
    tags: ['auth', 'login', 'screen'],
    isDefault: true,
  },
  {
    id: 'add-profile',
    name: 'Add profile page',
    type: 'skill',
    category: 'ui',
    description: 'Avatar, name, bio, and settings',
    prompt: 'Add a profile page with a circular avatar, user name, bio text, and a list of settings options with icons.',
    icon: 'UserCircle',
    tags: ['profile', 'user', 'screen'],
    isDefault: true,
  },
  {
    id: 'add-bottom-nav',
    name: 'Add bottom navigation',
    type: 'skill',
    category: 'ui',
    description: 'Tab bar with icons and labels',
    prompt: 'Add bottom tab navigation with Home, Search, and Profile tabs. Each tab should have an icon and label, with the active tab highlighted.',
    icon: 'Navigation',
    tags: ['navigation', 'tabs', 'ui'],
    isDefault: true,
  },
  {
    id: 'add-onboarding',
    name: 'Add onboarding flow',
    type: 'agent',
    category: 'workflow',
    description: '3-step welcome screens with swipe',
    prompt: 'Add an onboarding flow with 3 welcome screens that users can swipe through. Each screen should have an illustration area, a title, description, and a "Next" button. The last screen has a "Get Started" button.',
    icon: 'Smartphone',
    tags: ['onboarding', 'flow', 'welcome'],
    isDefault: true,
  },
  {
    id: 'add-dashboard',
    name: 'Add dashboard',
    type: 'skill',
    category: 'ui',
    description: 'Stats cards and overview widgets',
    prompt: 'Add a dashboard screen with 4 stat cards at the top (showing metrics like users, revenue, orders, growth), followed by a recent activity list.',
    icon: 'LayoutGrid',
    tags: ['dashboard', 'stats', 'overview'],
    isDefault: true,
  },
  {
    id: 'add-chart',
    name: 'Add chart',
    type: 'skill',
    category: 'ui',
    description: 'Bar or line chart component',
    prompt: 'Add a bar chart component to the current screen using div-based bars with different heights and colors. Show labels below each bar.',
    icon: 'BarChart3',
    tags: ['chart', 'data', 'visualization'],
    isDefault: true,
  },
  {
    id: 'add-search',
    name: 'Add search screen',
    type: 'skill',
    category: 'ui',
    description: 'Search bar with results list',
    prompt: 'Add a search screen with a search bar at the top and a list of results below. Each result should have a title, subtitle, and icon.',
    icon: 'Type',
    tags: ['search', 'list', 'screen'],
    isDefault: true,
  },
  {
    id: 'add-settings',
    name: 'Add settings screen',
    type: 'skill',
    category: 'ui',
    description: 'Toggles, options, and preferences',
    prompt: 'Add a settings screen with toggle switches for notifications, dark mode, and privacy. Include section headers and dividers.',
    icon: 'Settings',
    tags: ['settings', 'preferences', 'screen'],
    isDefault: true,
  },
  {
    id: 'add-data-list',
    name: 'Add data list',
    type: 'skill',
    category: 'ui',
    description: 'Scrollable list of items',
    prompt: 'Add a screen with a scrollable list of items. Each item should have an icon, title, subtitle, and a chevron arrow on the right.',
    icon: 'Database',
    tags: ['list', 'data', 'screen'],
    isDefault: true,
  },

  // ─── Theme Skills ──────────────────────────────────────────────────────────
  {
    id: 'dark-theme',
    name: 'Dark theme',
    type: 'skill',
    category: 'theme',
    description: 'Deep blacks and subtle grays',
    prompt: 'Change the theme to dark mode with deep blacks (#0a0a0a), subtle gray surfaces (#1a1a1a), and white text. Update all screens.',
    icon: 'Moon',
    tags: ['theme', 'dark', 'style'],
    isDefault: true,
  },
  {
    id: 'light-theme',
    name: 'Light theme',
    type: 'skill',
    category: 'theme',
    description: 'Clean white backgrounds',
    prompt: 'Change the theme to light mode with white backgrounds, light gray surfaces, and dark text. Update all screens.',
    icon: 'Sun',
    tags: ['theme', 'light', 'style'],
    isDefault: true,
  },
  {
    id: 'emerald-theme',
    name: 'Emerald theme',
    type: 'skill',
    category: 'theme',
    description: 'Black and emerald green',
    prompt: 'Make the theme black and emerald green. Use #0a0a0a for background, #10b981 for primary actions, and #065f46 for accents.',
    icon: 'Palette',
    tags: ['theme', 'emerald', 'green'],
    isDefault: true,
  },

  // ─── Workflow Agents ───────────────────────────────────────────────────────
  {
    id: 'ecommerce-agent',
    name: 'E-commerce agent',
    type: 'agent',
    category: 'workflow',
    description: 'Full online store with products, cart, and checkout',
    prompt: 'Build me an e-commerce app with: a home screen showing featured products in a grid, a product detail screen with image gallery and add-to-cart button, a cart screen showing items with quantities and total, and a checkout screen. Include bottom navigation between Home, Cart, and Profile.',
    icon: 'ShoppingCart',
    tags: ['ecommerce', 'store', 'products'],
    isDefault: true,
  },
  {
    id: 'fitness-agent',
    name: 'Fitness agent',
    type: 'agent',
    category: 'workflow',
    description: 'Workout tracker with routines and progress',
    prompt: 'Build me a fitness app with: a dashboard showing weekly progress, a workouts screen with exercise cards, a timer for rest periods, and a profile screen with stats. Use energetic colors like orange and black.',
    icon: 'Dumbbell',
    tags: ['fitness', 'workout', 'health'],
    isDefault: true,
  },
  {
    id: 'social-agent',
    name: 'Social media agent',
    type: 'agent',
    category: 'workflow',
    description: 'Feed, posts, likes, and comments',
    prompt: 'Build me a social media app with: a feed screen showing posts with user avatars, images, like/comment buttons, a create post screen with text input and image upload, and a notifications screen.',
    icon: 'Heart',
    tags: ['social', 'feed', 'posts'],
    isDefault: true,
  },
];

// ─── Categories ───────────────────────────────────────────────────────────────

export const SKILL_CATEGORIES: { id: SkillCategory; label: string }[] = [
  { id: 'agent', label: 'Agents' },
  { id: 'ui', label: 'UI Components' },
  { id: 'workflow', label: 'Workflows' },
  { id: 'theme', label: 'Themes' },
  { id: 'integration', label: 'Integrations' },
];

// ─── Markdown Import ──────────────────────────────────────────────────────────

export function parseSkillMarkdown(content: string): Skill | null {
  try {
    const lines = content.split('\n');
    let name = '';
    let description = '';
    let prompt = '';
    let category: SkillCategory = 'ui';
    let type: SkillType = 'skill';
    let icon = 'Zap';
    let tags: string[] = [];

    let section = '';
    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('# ')) {
        name = trimmed.slice(2).trim();
      } else if (trimmed.startsWith('## ')) {
        section = trimmed.slice(3).trim().toLowerCase();
      } else if (trimmed && section === 'description') {
        description = trimmed;
        section = '';
      } else if (trimmed && section === 'prompt') {
        prompt = trimmed;
        section = '';
      } else if (trimmed && section === 'category') {
        const c = trimmed as SkillCategory;
        if (['ui', 'agent', 'workflow', 'theme', 'integration'].includes(c)) {
          category = c;
        }
        section = '';
      } else if (trimmed && section === 'type') {
        const t = trimmed as SkillType;
        if (['skill', 'agent'].includes(t)) {
          type = t;
        }
        section = '';
      } else if (trimmed && section === 'icon') {
        icon = trimmed;
        section = '';
      } else if (trimmed && section === 'tags') {
        tags = trimmed.split(',').map(t => t.trim());
        section = '';
      }
    }

    if (!name || !prompt) return null;

    return {
      id: `import_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      name,
      type,
      category,
      description: description || name,
      prompt,
      icon,
      tags: tags.length > 0 ? tags : [category],
      isDefault: false,
    };
  } catch {
    return null;
  }
}
