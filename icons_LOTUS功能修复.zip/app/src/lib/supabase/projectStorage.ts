// Supabase Project Storage — replaces localStorage with PostgreSQL
// Mirrors the API of the old localStorage-based projectStorage.ts

import { supabase } from './client';
import type { Project, AppSchema, ChatMessage } from '@/lib/builder/appSchema';
import { generateId, createDefaultSchema } from '@/lib/builder/appSchema';

const CURRENT_PROJECT_KEY = 'lotus_current_project_id'; // still localStorage for session tracking
const STORAGE_MODE_KEY = 'lotus_storage_mode';

// ─── Types ────────────────────────────────────────────────────────────────────

interface DbProject {
  id: string;
  name: string;
  schema: AppSchema;
  messages: ChatMessage[];
  created_at: string;
  updated_at: string;
}

// ─── DB <-> App mapping ───────────────────────────────────────────────────────

function dbToProject(row: DbProject): Project {
  return {
    id: row.id,
    name: row.name,
    createdAt: new Date(row.created_at).getTime(),
    updatedAt: new Date(row.updated_at).getTime(),
    messages: row.messages || [],
    schema: row.schema as AppSchema,
  };
}

function projectToDb(project: Project): Omit<DbProject, 'created_at' | 'updated_at'> {
  return {
    id: project.id,
    name: project.name,
    schema: project.schema,
    messages: project.messages,
  };
}

// ─── Error wrapper ────────────────────────────────────────────────────────────

function handleError(err: unknown, context: string): null {
  if (import.meta.env.DEV) {
    // eslint-disable-next-line no-console
    console.error(`[LOTUS Storage] ${context}:`, err);
  }
  return null;
}

// ─── Public API (mirrors old projectStorage.ts) ──────────────────────────────

export async function getAllProjects(): Promise<Project[]> {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .order('updated_at', { ascending: false });

  if (error) {
    handleError(error, 'getAllProjects');
    return [];
  }

  return (data as DbProject[]).map(dbToProject);
}

export async function getProject(id: string): Promise<Project | null> {
  const { data, error } = await supabase
    .from('projects')
    .select('*')
    .eq('id', id)
    .single();

  if (error) {
    handleError(error, 'getProject');
    return null;
  }

  return dbToProject(data as DbProject);
}

export async function saveProject(project: Project): Promise<void> {
  const dbData = projectToDb(project);

  const { error } = await supabase
    .from('projects')
    .upsert({
      ...dbData,
      updated_at: new Date(project.updatedAt).toISOString(),
    }, { onConflict: 'id' });

  if (error) {
    handleError(error, 'saveProject');
  }
}

export async function deleteProject(id: string): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .delete()
    .eq('id', id);

  if (error) {
    handleError(error, 'deleteProject');
  }

  // Clear current project if it was this one
  const current = localStorage.getItem(CURRENT_PROJECT_KEY);
  if (current === id) {
    localStorage.removeItem(CURRENT_PROJECT_KEY);
  }
}

export async function createProject(name?: string): Promise<Project> {
  // For Supabase, we let the DB generate the UUID
  const { data, error } = await supabase
    .from('projects')
    .insert({
      name: name || 'Untitled Project',
      schema: createDefaultSchema(),
      messages: [],
    })
    .select()
    .single();

  if (error || !data) {
    handleError(error, 'createProject');
    // Fallback: return a local project
    const fallback: Project = {
      id: generateId(),
      name: name || 'Untitled Project',
      createdAt: Date.now(),
      updatedAt: Date.now(),
      messages: [],
      schema: createDefaultSchema(),
    };
    return fallback;
  }

  const project = dbToProject(data as DbProject);
  setCurrentProject(project.id);
  return project;
}

export function setCurrentProject(id: string): void {
  localStorage.setItem(CURRENT_PROJECT_KEY, id);
}

export function getCurrentProjectId(): string | null {
  return localStorage.getItem(CURRENT_PROJECT_KEY);
}

export async function getOrCreateCurrentProject(): Promise<Project> {
  const currentId = getCurrentProjectId();
  if (currentId) {
    const project = await getProject(currentId);
    if (project) return project;
  }

  return createProject('My First Project');
}

export async function renameProject(id: string, newName: string): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .update({ name: newName })
    .eq('id', id);

  if (error) {
    handleError(error, 'renameProject');
  }
}

export async function updateProjectSchema(id: string, schema: AppSchema): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .update({ schema })
    .eq('id', id);

  if (error) {
    handleError(error, 'updateProjectSchema');
  }
}

export async function updateProjectMessages(id: string, messages: ChatMessage[]): Promise<void> {
  const { error } = await supabase
    .from('projects')
    .update({ messages })
    .eq('id', id);

  if (error) {
    handleError(error, 'updateProjectMessages');
  }
}

// Auto-save — debounced
let autoSaveTimeout: ReturnType<typeof setTimeout> | null = null;

export function autoSave(project: Project): void {
  if (autoSaveTimeout) {
    clearTimeout(autoSaveTimeout);
  }
  autoSaveTimeout = setTimeout(() => {
    saveProject(project);
    autoSaveTimeout = null;
  }, 500);
}

export function generateProjectName(messages: ChatMessage[]): string {
  const firstUserMessage = messages.find(m => m.role === 'user');
  if (!firstUserMessage) return 'Untitled Project';

  const content = firstUserMessage.content;
  const keywords = ['fitness', 'astrology', 'crypto', 'dashboard', 'social', 'music', 'ecommerce', 'premium', 'luxury'];
  const found = keywords.find(k => content.toLowerCase().includes(k));

  if (found) {
    return found.charAt(0).toUpperCase() + found.slice(1) + ' App';
  }

  const words = content.split(' ').slice(0, 3).join(' ');
  return words.charAt(0).toUpperCase() + words.slice(1);
}

export async function resetProject(id: string): Promise<Project> {
  const project = await getProject(id);
  if (project) {
    const reset = {
      ...project,
      schema: createDefaultSchema(),
      messages: [],
      updatedAt: Date.now(),
    };
    await saveProject(reset);
    return reset;
  }
  return createProject();
}

// ─── Migration helper: localStorage → Supabase ──────────────────────────────

export async function migrateLocalStorageToSupabase(): Promise<number> {
  try {
    const raw = localStorage.getItem('lotus_projects');
    if (!raw) return 0;

    const projects = JSON.parse(raw) as Project[];
    if (!projects.length) return 0;

    let migrated = 0;
    for (const p of projects) {
      // Insert with same ID if it's a valid UUID, otherwise let DB generate
      const isUuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(p.id);

      const { error } = await supabase.from('projects').upsert({
        id: isUuid ? p.id : undefined,
        name: p.name,
        schema: p.schema,
        messages: p.messages,
        created_at: new Date(p.createdAt).toISOString(),
        updated_at: new Date(p.updatedAt).toISOString(),
      }, { onConflict: 'id' });

      if (!error) migrated++;
    }

    // Clear localStorage after successful migration
    if (migrated > 0) {
      localStorage.removeItem('lotus_projects');
      localStorage.setItem(STORAGE_MODE_KEY, 'supabase');
    }

    return migrated;
  } catch {
    return 0;
  }
}
