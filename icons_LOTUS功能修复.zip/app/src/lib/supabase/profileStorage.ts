// User Profile Storage — Theme, name, avatar, preferences in Supabase
// Replaces localStorage for all user-specific settings

import { supabase } from './client';

export interface UserProfile {
  id: string;
  email: string;
  full_name: string | null;
  avatar_url: string | null;
  theme_mode: 'dark' | 'light';
  provider_favorites: string[];
  created_at: string;
  updated_at: string;
}

// ─── Profile CRUD ─────────────────────────────────────────────────────────────

export async function getProfile(userId: string): Promise<UserProfile | null> {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('id', userId)
    .single();

  if (error) {
    // Profile might not exist yet
    if (error.code === 'PGRST116') return null;
    console.error('getProfile error:', error);
    return null;
  }
  return data as UserProfile;
}

export async function createProfile(userId: string, email: string, name?: string, avatar?: string): Promise<UserProfile | null> {
  const { data, error } = await supabase
    .from('user_profiles')
    .insert({
      id: userId,
      email,
      full_name: name || email.split('@')[0],
      avatar_url: avatar || null,
      theme_mode: 'dark',
      provider_favorites: [],
    })
    .select()
    .single();

  if (error) {
    console.error('createProfile error:', error);
    return null;
  }
  return data as UserProfile;
}

export async function updateProfile(userId: string, updates: Partial<Omit<UserProfile, 'id' | 'created_at'>>): Promise<void> {
  const { error } = await supabase
    .from('user_profiles')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId);

  if (error) {
    console.error('updateProfile error:', error);
  }
}

// ─── Theme ────────────────────────────────────────────────────────────────────

export async function getThemeMode(userId: string): Promise<'dark' | 'light'> {
  const profile = await getProfile(userId);
  return profile?.theme_mode || 'dark';
}

export async function setThemeMode(userId: string, mode: 'dark' | 'light'): Promise<void> {
  const profile = await getProfile(userId);
  if (!profile) {
    // Try to get user info to create profile
    const { data: { user } } = await supabase.auth.getUser();
    if (user) {
      await createProfile(userId, user.email!, user.user_metadata?.full_name, user.user_metadata?.avatar_url);
    }
  }
  await updateProfile(userId, { theme_mode: mode });
}

// ─── Realtime sync ────────────────────────────────────────────────────────────

export function subscribeToProfile(userId: string, onChange: (profile: UserProfile) => void) {
  return supabase
    .channel(`profile_${userId}`)
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'user_profiles',
        filter: `id=eq.${userId}`,
      },
      (payload) => {
        onChange(payload.new as UserProfile);
      }
    )
    .subscribe();
}
