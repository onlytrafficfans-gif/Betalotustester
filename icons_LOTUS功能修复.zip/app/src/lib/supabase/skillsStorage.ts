// Skills Storage — Supabase-backed (replaces localStorage in skillsData.ts)
// User-imported skills stored in user_skills table

import { supabase } from './client';
import type { Skill, SkillType, SkillCategory } from '@/lib/skills/skillsData';

// ─── DB Types ─────────────────────────────────────────────────────────────────

interface DbUserSkill {
  id: string;
  user_id: string;
  name: string;
  type: string;
  category: string;
  description: string;
  prompt: string;
  icon: string;
  tags: string[];
  created_at: string;
}

function dbToSkill(row: DbUserSkill): Skill {
  return {
    id: row.id,
    name: row.name,
    type: row.type as SkillType,
    category: row.category as SkillCategory,
    description: row.description,
    prompt: row.prompt,
    icon: row.icon,
    tags: row.tags || [],
    isDefault: false,
  };
}

// ─── CRUD Operations ──────────────────────────────────────────────────────────

export async function loadUserSkills(userId: string): Promise<Skill[]> {
  if (!userId) return [];
  const { data, error } = await supabase
    .from('user_skills')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: true });

  if (error) {
    console.error('loadUserSkills error:', error);
    return [];
  }
  return (data || []).map(dbToSkill);
}

export async function saveUserSkill(userId: string, skill: Skill): Promise<Skill | null> {
  if (!userId) return null;

  const payload = {
    user_id: userId,
    name: skill.name,
    type: skill.type,
    category: skill.category,
    description: skill.description,
    prompt: skill.prompt,
    icon: skill.icon,
    tags: skill.tags || [],
  };

  // Check if skill with this ID already exists for this user
  const { data: existing } = await supabase
    .from('user_skills')
    .select('id')
    .eq('user_id', userId)
    .eq('id', skill.id)
    .single();

  if (existing) {
    // Update
    const { data, error } = await supabase
      .from('user_skills')
      .update(payload)
      .eq('id', skill.id)
      .eq('user_id', userId)
      .select()
      .single();

    if (error) {
      console.error('updateUserSkill error:', error);
      return null;
    }
    return dbToSkill(data as DbUserSkill);
  } else {
    // Insert (if skill.id starts with 'user_', use it; otherwise generate new)
    const newId = skill.id.startsWith('user_') || skill.id.startsWith('import_')
      ? skill.id
      : `import_${Date.now()}`;

    const { data, error } = await supabase
      .from('user_skills')
      .insert({ ...payload, id: newId })
      .select()
      .single();

    if (error) {
      console.error('insertUserSkill error:', error);
      return null;
    }
    return dbToSkill(data as DbUserSkill);
  }
}

export async function deleteUserSkill(userId: string, id: string): Promise<void> {
  if (!userId) return;
  const { error } = await supabase
    .from('user_skills')
    .delete()
    .eq('id', id)
    .eq('user_id', userId);

  if (error) console.error('deleteUserSkill error:', error);
}

// ─── Batch Import ─────────────────────────────────────────────────────────────

export async function importUserSkills(userId: string, skills: Skill[]): Promise<number> {
  if (!userId || skills.length === 0) return 0;

  const payloads = skills.map(skill => ({
    user_id: userId,
    id: `import_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    name: skill.name,
    type: skill.type,
    category: skill.category,
    description: skill.description,
    prompt: skill.prompt,
    icon: skill.icon,
    tags: skill.tags || [],
  }));

  const { error } = await supabase
    .from('user_skills')
    .insert(payloads);

  if (error) {
    console.error('importUserSkills error:', error);
    return 0;
  }
  return payloads.length;
}
