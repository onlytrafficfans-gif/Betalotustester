// AI Provider Interface
// Supports any OpenAI-compatible API. No mock provider — real keys only.

import type { AppSchema, StructuredAIResponse } from '@/lib/builder/appSchema';

export type { StructuredAIResponse };

export interface AIProvider {
  id: string;
  name: string;
  model: string;
  sendMessage: (prompt: string, currentSchema: AppSchema, history: { role: string; content: string }[]) => Promise<StructuredAIResponse>;
}

// Provider registry
const providers: Map<string, AIProvider> = new Map();

export function registerProvider(id: string, provider: AIProvider): void {
  providers.set(id, provider);
}

export function unregisterProvider(id: string): void {
  providers.delete(id);
}

export function getProvider(id: string): AIProvider | undefined {
  return providers.get(id);
}

export function listProviders(): { id: string; name: string; model: string }[] {
  return Array.from(providers.entries()).map(([id, p]) => ({
    id,
    name: p.name,
    model: p.model,
  }));
}

export function hasProviders(): boolean {
  return providers.size > 0;
}

// Get the first available provider ID
export function getDefaultProviderId(): string {
  const first = Array.from(providers.keys())[0];
  return first || '';
}

// System prompt for structured JSON output
export function buildSystemPrompt(currentSchema: AppSchema): string {
  return `You are LOTUS AI, an expert app builder. You design and build mobile apps by modifying a JSON schema.

Respond ONLY with valid JSON matching this structure:
{
  "assistantMessage": "A friendly response to the user describing what changed",
  "schemaPatch": [
    { "op": "addScreen", "value": { "id": "...", "name": "...", "type": "...", "components": [...] } },
    { "op": "removeScreen", "screenId": "..." },
    { "op": "updateTheme", "value": { "primary": "#hex", "background": "#hex" } },
    { "op": "addComponent", "screenId": "...", "value": { "id": "...", "type": "...", "props": {...} } },
    { "op": "updateComponent", "screenId": "...", "componentId": "...", "value": { "props": {...} } },
    { "op": "removeComponent", "screenId": "...", "componentId": "..." },
    { "op": "reorderComponents", "screenId": "...", "from": 0, "to": 1 },
    { "op": "setNavigation", "value": { "type": "bottom-tabs", "items": [...] } },
    { "op": "setActiveScreen", "screenId": "..." },
    { "op": "fullRebuild", "value": { /* complete AppSchema */ } }
  ],
  "warnings": []
}

Component types: header, text, button, input, card, list, image, avatar, chart, grid, search, tabs, progress, badge, divider, spacer.
Screen types: home, dashboard, profile, settings, login, signup, list, detail, form, chat, search, onboarding, custom.
Navigation types: bottom-tabs, sidebar, top-tabs, drawer, none.

Current app: ${currentSchema.name} (${currentSchema.screens.length} screens).
DO NOT include markdown code fences. Return only raw JSON.`;
}

// Validate structured response
export function validateStructuredResponse(data: unknown): { valid: boolean; error?: string; response?: StructuredAIResponse } {
  try {
    if (!data || typeof data !== 'object') {
      return { valid: false, error: 'Response is not an object' };
    }

    const obj = data as Record<string, unknown>;

    if (!obj.assistantMessage || typeof obj.assistantMessage !== 'string') {
      return { valid: false, error: 'Missing or invalid assistantMessage' };
    }

    if (obj.schemaPatch !== undefined) {
      if (!Array.isArray(obj.schemaPatch)) {
        return { valid: false, error: 'schemaPatch must be an array' };
      }
      for (let i = 0; i < obj.schemaPatch.length; i++) {
        const patch = obj.schemaPatch[i] as Record<string, unknown>;
        const validOps = ['addScreen', 'removeScreen', 'updateTheme', 'addComponent', 'updateComponent', 'removeComponent', 'reorderComponents', 'setNavigation', 'setActiveScreen', 'fullRebuild'];
        if (!patch.op || !validOps.includes(patch.op as string)) {
          return { valid: false, error: `Invalid patch operation at index ${i}: ${patch.op}` };
        }
      }
    }

    const response: StructuredAIResponse = {
      assistantMessage: obj.assistantMessage as string,
      schemaPatch: (obj.schemaPatch as StructuredAIResponse['schemaPatch']) || undefined,
      fullUpdatedSchema: obj.fullUpdatedSchema as AppSchema | undefined,
      changedFiles: (obj.changedFiles as string[] | undefined) || undefined,
      warnings: (obj.warnings as string[] | undefined) || undefined,
    };

    return { valid: true, response };
  } catch (e) {
    return { valid: false, error: `Validation error: ${e instanceof Error ? e.message : String(e)}` };
  }
}

// Parse AI response (handles JSON extraction from markdown)
export function parseAIResponse(text: string): { valid: boolean; error?: string; response?: StructuredAIResponse } {
  let jsonStr = text.trim();

  const codeFenceMatch = jsonStr.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (codeFenceMatch) {
    jsonStr = codeFenceMatch[1].trim();
  }

  try {
    const parsed = JSON.parse(jsonStr);
    return validateStructuredResponse(parsed);
  } catch {
    return {
      valid: true,
      response: {
        assistantMessage: text,
        warnings: ['AI did not return valid JSON. No schema changes were applied.'],
      },
    };
  }
}
