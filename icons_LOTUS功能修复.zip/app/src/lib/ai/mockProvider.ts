// Mock AI Provider — Dev/fallback mode
// Returns StructuredAIResponse with schema patches
// Upgraded to use schema diffing instead of full rebuilds

import type { AIProvider } from './provider';
import type { AppSchema, AppScreen, AppComponent, AppNavigation, SchemaPatch } from '@/lib/builder/appSchema';
import { generateId, defaultTheme } from '@/lib/builder/appSchema';

const cid = () => `comp_${generateId()}`;

function createComponent(type: AppComponent['type'], props: Record<string, unknown>): AppComponent {
  return { id: cid(), type, props };
}

function createScreen(id: string, name: string, screenType: AppScreen['type'], components: AppComponent[]): AppScreen {
  return { id, name, type: screenType, components };
}

function parseIntent(prompt: string): {
  action: 'create' | 'add' | 'modify' | 'style' | 'unknown';
  appType?: string;
  target?: string;
  properties: Record<string, string>;
} {
  const lower = prompt.toLowerCase();
  const properties: Record<string, string> = {};

  let appType: string | undefined;
  const appTypes = ['fitness', 'astrology', 'horoscope', 'crypto', 'finance', 'social', 'ecommerce', 'music', 'premium', 'luxury', 'dashboard'];
  for (const type of appTypes) {
    if (lower.includes(type)) { appType = type; break; }
  }

  if (lower.includes('black') && lower.includes('green')) properties.colorScheme = 'black-green';
  else if (lower.includes('black') && lower.includes('gold')) properties.colorScheme = 'black-gold';
  else if (lower.includes('dark')) properties.colorScheme = 'dark';
  else if (lower.includes('white') || lower.includes('light')) properties.colorScheme = 'light';

  let action: ReturnType<typeof parseIntent>['action'] = 'unknown';
  if (lower.includes('build') || lower.includes('create') || lower.includes('make') || lower.includes('new app')) action = 'create';
  else if (lower.includes('add') || lower.includes('include')) action = 'add';
  else if (lower.includes('change') || lower.includes('make it') || lower.includes('update') || lower.includes('set to')) action = 'modify';
  else if (lower.includes('color') || lower.includes('theme') || lower.includes('style')) action = 'style';

  let target: string | undefined;
  const targets = ['dashboard', 'login', 'profile', 'settings', 'signup', 'home', 'navigation', 'bottom nav', 'tab bar', 'screen', 'chart'];
  for (const t of targets) { if (lower.includes(t)) { target = t; break; } }

  return { action, appType, target, properties };
}

function buildFitnessPatches(_baseSchema: AppSchema): SchemaPatch[] {
  const dashId = `screen_${generateId()}`;
  const workId = `screen_${generateId()}`;
  const profId = `screen_${generateId()}`;

  return [
    { op: 'updateTheme', value: { background: '#0a0a0a', primary: '#059669', accent: '#34d399', text: '#f5f5f5', surface: '#171717', border: '#262626' } },
    { op: 'addScreen', value: createScreen(dashId, 'Dashboard', 'dashboard', [
      createComponent('header', { title: 'FitPro', subtitle: 'Your Fitness Journey', showAvatar: true }),
      createComponent('grid', { columns: 2, items: [
        { label: 'Steps', value: '8,432', icon: 'footprints' },
        { label: 'Calories', value: '2,150', icon: 'flame' },
        { label: 'Workouts', value: '12', icon: 'dumbbell' },
        { label: 'Streak', value: '5 days', icon: 'trophy' },
      ]}),
      createComponent('card', { title: "Today's Workout", subtitle: 'Upper Body Strength', action: 'Start' }),
      createComponent('progress', { label: 'Weekly Goal', value: 75, color: '#10b981' }),
    ])},
    { op: 'addScreen', value: createScreen(workId, 'Workouts', 'list', [
      createComponent('header', { title: 'Workouts', showSearch: true }),
      createComponent('list', { items: [
        { title: 'Morning Cardio', duration: '30 min', level: 'Beginner' },
        { title: 'HIIT Blast', duration: '20 min', level: 'Advanced' },
        { title: 'Yoga Flow', duration: '45 min', level: 'Intermediate' },
        { title: 'Strength Training', duration: '40 min', level: 'Advanced' },
      ]}),
    ])},
    { op: 'addScreen', value: createScreen(profId, 'Profile', 'profile', [
      createComponent('avatar', { name: 'Alex Johnson', subtitle: 'Fitness Enthusiast', size: 'lg' }),
      createComponent('grid', { columns: 3, items: [
        { label: 'Weight', value: '165 lbs' },
        { label: 'Height', value: "5'10\"" },
        { label: 'Age', value: '28' },
      ]}),
      createComponent('card', { title: 'Achievements', subtitle: 'View all badges' }),
      createComponent('button', { label: 'Edit Profile', variant: 'outline', fullWidth: true }),
    ])},
    { op: 'setNavigation', value: { type: 'bottom-tabs', items: [
      { id: generateId(), label: 'Home', icon: 'home', screenId: dashId },
      { id: generateId(), label: 'Workouts', icon: 'dumbbell', screenId: workId },
      { id: generateId(), label: 'Profile', icon: 'user', screenId: profId },
    ]} as AppNavigation },
    { op: 'setActiveScreen', screenId: dashId },
  ];
}

function buildLoginPatch(): SchemaPatch {
  const loginId = `screen_${generateId()}`;
  return {
    op: 'addScreen',
    value: createScreen(loginId, 'Login', 'login', [
      createComponent('header', { title: 'Welcome Back', subtitle: 'Sign in to continue' }),
      createComponent('spacer', { size: 'lg' }),
      createComponent('input', { placeholder: 'Email', type: 'email', icon: 'mail' }),
      createComponent('input', { placeholder: 'Password', type: 'password', icon: 'lock' }),
      createComponent('button', { label: 'Sign In', variant: 'primary', fullWidth: true }),
      createComponent('spacer', { size: 'md' }),
      createComponent('text', { content: 'Forgot Password?', align: 'center', size: 'sm', color: 'primary' }),
      createComponent('divider', { label: 'or' }),
      createComponent('button', { label: 'Continue with Google', variant: 'outline', fullWidth: true }),
    ]),
  };
}

function buildProfilePatch(): SchemaPatch {
  const profId = `screen_${generateId()}`;
  return {
    op: 'addScreen',
    value: createScreen(profId, 'Profile', 'profile', [
      createComponent('avatar', { name: 'User', subtitle: 'Member since 2024', size: 'lg' }),
      createComponent('grid', { columns: 3, items: [
        { label: 'Posts', value: '24' },
        { label: 'Followers', value: '1.2K' },
        { label: 'Following', value: '348' },
      ]}),
      createComponent('card', { title: 'Edit Profile', subtitle: 'Update your information' }),
      createComponent('list', { items: [
        { title: 'My Orders', icon: 'shopping-bag', action: 'chevron-right' },
        { title: 'Saved Items', icon: 'bookmark', action: 'chevron-right' },
        { title: 'Settings', icon: 'settings', action: 'chevron-right' },
      ]}),
    ]),
  };
}

function bottomNavPatch(schema: AppSchema): SchemaPatch[] {
  if (schema.navigation.type === 'bottom-tabs') return [];
  const navItems: AppNavigation['items'] = schema.screens.slice(0, 4).map(screen => ({
    id: generateId(), label: screen.name,
    icon: screen.type === 'home' ? 'home' : screen.type === 'profile' ? 'user' : screen.type === 'settings' ? 'settings' : 'circle',
    screenId: screen.id,
  }));
  return [{ op: 'setNavigation', value: { type: 'bottom-tabs', items: navItems.length > 0 ? navItems : [{ id: generateId(), label: 'Home', icon: 'home', screenId: schema.screens[0]?.id || 'home' }] } as AppNavigation }];
}

function themePatch(colorScheme: string): SchemaPatch {
  let theme: Partial<typeof defaultTheme>;
  switch (colorScheme) {
    case 'black-green': theme = { background: '#0a0a0a', primary: '#059669', accent: '#10b981', text: '#f5f5f5', surface: '#171717', border: '#262626' }; break;
    case 'black-gold': theme = { background: '#0a0a0a', primary: '#d97706', accent: '#f59e0b', text: '#fafaf9', surface: '#1c1917', border: '#292524' }; break;
    case 'light': theme = { background: '#fafafa', primary: '#059669', accent: '#10b981', text: '#171717', surface: '#ffffff', border: '#e5e5e5' }; break;
    default: theme = { ...defaultTheme }; break;
  }
  return { op: 'updateTheme', value: theme };
}

// The main mock provider
export const mockProvider: AIProvider = {
  id: 'mock',
  name: 'LOTUS AI (Mock)',
  model: 'mock',

  async sendMessage(prompt: string, currentSchema: AppSchema): Promise<import('./provider').StructuredAIResponse> {
    await new Promise(resolve => setTimeout(resolve, 600 + Math.random() * 800));

    const intent = parseIntent(prompt);
    const patches: SchemaPatch[] = [];
    const changes: string[] = [];

    // Create action
    if (intent.action === 'create') {
      if (intent.appType === 'fitness' || intent.appType === 'luxury') {
        const fitnessPatches = buildFitnessPatches(currentSchema);
        patches.push(...fitnessPatches);
        changes.push('Created fitness dashboard with workout tracking');
        changes.push('Added profile screen with stats');
        changes.push('Set emerald green premium theme');
      } else {
        const dashId = `screen_${generateId()}`;
        patches.push({ op: 'updateTheme', value: { background: '#0a0a0a', primary: '#059669', accent: '#10b981', text: '#f5f5f5', surface: '#171717', border: '#262626' } });
        patches.push({ op: 'addScreen', value: createScreen(dashId, 'Dashboard', 'dashboard', [
          createComponent('header', { title: 'Dashboard', subtitle: 'Overview', showAvatar: true }),
          createComponent('grid', { columns: 2, items: [
            { label: 'Revenue', value: '$12.4K', icon: 'dollar-sign' },
            { label: 'Users', value: '1,234', icon: 'users' },
            { label: 'Orders', value: '89', icon: 'shopping-bag' },
            { label: 'Growth', value: '+23%', icon: 'trending-up' },
          ]}),
          createComponent('card', { title: 'Recent Activity', subtitle: 'View all transactions' }),
          createComponent('chart', { type: 'bar', label: 'Weekly Performance' }),
        ])});
        patches.push({ op: 'setActiveScreen', screenId: dashId });
        changes.push(`Created ${intent.appType || 'a new'} app`);
        changes.push('Added dashboard with key metrics');
      }
    }

    // Add action
    if (intent.action === 'add') {
      if (intent.target?.includes('login') || intent.target?.includes('sign in')) {
        patches.push(buildLoginPatch());
        changes.push('Added login screen with email/password fields');
      } else if (intent.target?.includes('profile')) {
        patches.push(buildProfilePatch());
        changes.push('Added profile screen with user stats');
      } else if (intent.target?.includes('nav') || intent.target?.includes('bottom')) {
        patches.push(...bottomNavPatch(currentSchema));
        changes.push('Added bottom tab navigation');
      } else if (intent.target?.includes('dashboard')) {
        const did = `screen_${generateId()}`;
        patches.push({ op: 'addScreen', value: createScreen(did, 'Dashboard', 'dashboard', [
          createComponent('header', { title: 'Dashboard', showAvatar: true }),
          createComponent('grid', { columns: 2, items: [
            { label: 'Total', value: '1,234', icon: 'users' },
            { label: 'Revenue', value: '$12.4K', icon: 'dollar-sign' },
          ]}),
        ])});
        changes.push('Added dashboard screen with metrics');
      }
    }

    // Modify/style action
    if (intent.action === 'modify' || intent.action === 'style') {
      if (intent.properties.colorScheme) {
        patches.push(themePatch(intent.properties.colorScheme));
        changes.push(`Updated color scheme to ${intent.properties.colorScheme}`);
      }
      if (intent.target?.includes('nav') || prompt.toLowerCase().includes('bottom navigation')) {
        patches.push(...bottomNavPatch(currentSchema));
        changes.push('Added bottom navigation bar');
      }
      if (intent.appType === 'premium' || intent.appType === 'luxury') {
        patches.push(themePatch('black-green'));
        changes.push('Applied premium styling with emerald accents');
      }
    }

    // Fallback detections
    if (patches.length === 0) {
      if (prompt.toLowerCase().includes('bottom') && prompt.toLowerCase().includes('navigation')) {
        patches.push(...bottomNavPatch(currentSchema));
        changes.push('Added bottom tab navigation');
      }
      if (prompt.toLowerCase().includes('profile')) {
        patches.push(buildProfilePatch());
        changes.push('Added profile page');
      }
      if (prompt.toLowerCase().includes('login')) {
        patches.push(buildLoginPatch());
        changes.push('Added login screen');
      }
    }

    if (changes.length === 0) {
      changes.push('Updated app layout');
    }

    return {
      assistantMessage: `I've processed your request. Here's what changed:\n\n${changes.map(c => `- ${c}`).join('\n')}\n\nThe preview is updating now. Let me know if you'd like any adjustments!`,
      schemaPatch: patches,
      warnings: [],
    };
  },
};

// Note: mockProvider is registered in initProviders.ts, not here
// to avoid circular import issues
