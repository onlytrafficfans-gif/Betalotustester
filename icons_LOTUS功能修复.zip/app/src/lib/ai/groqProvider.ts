// Groq Provider — Real AI provider using Groq API
// Fast, cheap, good for structured JSON output

import type { AIProvider } from './provider';
import type { AppSchema } from '@/lib/builder/appSchema';
import { buildSystemPrompt, parseAIResponse } from './provider';

const GROQ_API_URL = 'https://api.groq.com/openai/v1/chat/completions';

export function createGroqProvider(apiKey: string, model: string): AIProvider {
  return {
    id: 'groq',
    name: 'Groq',
    model,

    async sendMessage(prompt: string, currentSchema: AppSchema, history: { role: string; content: string }[]) {
      const messages = [
        { role: 'system', content: buildSystemPrompt(currentSchema) },
        ...history.slice(-10).map(h => ({ role: h.role, content: h.content })),
        { role: 'user', content: prompt },
      ];

      const response = await fetch(GROQ_API_URL, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model,
          messages,
          temperature: 0.3,
          max_tokens: 4000,
          response_format: { type: 'json_object' },
        }),
      });

      if (!response.ok) {
        const error = await response.text();
        throw new Error(`Groq API error (${response.status}): ${error}`);
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      if (!content) {
        throw new Error('Empty response from Groq API');
      }

      const parsed = parseAIResponse(content);

      if (!parsed.valid || !parsed.response) {
        throw new Error(parsed.error || 'Failed to parse AI response');
      }

      return parsed.response;
    },
  };
}
