// Generic OpenAI-Compatible Provider
// Creates an AIProvider from any OpenAI-compatible API endpoint

import type { AIProvider } from './provider';
import type { AppSchema } from '@/lib/builder/appSchema';
import { buildSystemPrompt, parseAIResponse } from './provider';

export function createGenericProvider(
  id: string,
  name: string,
  apiKey: string,
  baseUrl: string,
  model: string
): AIProvider {
  const isAnthropic = baseUrl.includes('anthropic');

  return {
    id,
    name,
    model,

    async sendMessage(prompt: string, currentSchema: AppSchema, history: { role: string; content: string }[]) {
      if (isAnthropic) {
        return anthropicRequest(apiKey, baseUrl, model, prompt, currentSchema, history);
      }
      return openAICompatibleRequest(apiKey, baseUrl, model, prompt, currentSchema, history);
    },
  };
}

async function openAICompatibleRequest(
  apiKey: string,
  baseUrl: string,
  model: string,
  prompt: string,
  currentSchema: AppSchema,
  history: { role: string; content: string }[]
) {
  const messages = [
    { role: 'system', content: buildSystemPrompt(currentSchema) },
    ...history.slice(-10).map(h => ({ role: h.role, content: h.content })),
    { role: 'user', content: prompt },
  ];

  const response = await fetch(baseUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model,
      messages,
      temperature: 0.3,
      max_tokens: 4000,
      response_format: { type: 'json_object' },
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`${response.status}: ${error}`);
  }

  const data = await response.json();
  const content = data.choices?.[0]?.message?.content;

  if (!content) {
    throw new Error('Empty response from API');
  }

  const parsed = parseAIResponse(content);

  if (!parsed.valid || !parsed.response) {
    throw new Error(parsed.error || 'Failed to parse AI response');
  }

  return parsed.response;
}

async function anthropicRequest(
  apiKey: string,
  baseUrl: string,
  model: string,
  prompt: string,
  currentSchema: AppSchema,
  history: { role: string; content: string }[]
) {
  const systemPrompt = buildSystemPrompt(currentSchema);

  const messages = [
    ...history.slice(-10).map(h => ({ role: h.role, content: h.content })),
    { role: 'user', content: prompt },
  ];

  const response = await fetch(baseUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model,
      max_tokens: 4000,
      system: systemPrompt,
      messages,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`${response.status}: ${error}`);
  }

  const data = await response.json();
  const content = data.content?.[0]?.text;

  if (!content) {
    throw new Error('Empty response from Anthropic API');
  }

  const parsed = parseAIResponse(content);

  if (!parsed.valid || !parsed.response) {
    throw new Error(parsed.error || 'Failed to parse AI response');
  }

  return parsed.response;
}
