// API Key Storage — Dynamic provider and key management via Supabase
// Supports ANY OpenAI-compatible API endpoint. Users can add custom providers.
// REPLACES localStorage with Supabase user_profiles.api_keys column

import { supabase } from '@/lib/supabase/client';

export interface StoredProvider {
  id: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  model: string;
  models: string[];
}

export interface StoredApiKeys {
  providers: StoredProvider[];
}

// ─── Presets ─────────────────────────────────────────────────────────────────
// OpenRouter and Gemini free models are pre-configured so users can start
// immediately without entering any API keys.

export const PRESET_PROVIDERS: Omit<StoredProvider, 'apiKey'>[] = [
  {
    id: 'openrouter',
    name: 'OpenRouter (Free)',
    baseUrl: 'https://openrouter.ai/api/v1/chat/completions',
    model: 'google/gemini-2.0-flash-exp:free',
    models: [
      'google/gemini-2.0-flash-exp:free',
      'google/gemini-2.0-flash-thinking-exp:free',
      'google/gemini-flash-1.5',
      'meta-llama/llama-3.3-70b-instruct:free',
      'meta-llama/llama-3.1-8b-instruct:free',
      'deepseek/deepseek-chat:free',
      'deepseek/deepseek-r1:free',
      'nvidia/llama-3.1-nemotron-70b-instruct:free',
      'mistralai/mistral-7b-instruct:free',
      'qwen/qwen2.5-7b-instruct:free',
    ],
  },
  {
    id: 'gemini',
    name: 'Google Gemini',
    baseUrl: 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    model: 'gemini-2.0-flash',
    models: [
      'gemini-2.0-flash',
      'gemini-2.0-flash-lite',
      'gemini-1.5-flash',
      'gemini-1.5-flash-8b',
      'gemini-1.5-pro',
    ],
  },
  {
    id: 'groq',
    name: 'Groq',
    baseUrl: 'https://api.groq.com/openai/v1/chat/completions',
    model: 'llama-3.3-70b-versatile',
    models: [
      'llama-3.3-70b-versatile',
      'llama-3.1-8b-instant',
      'mixtral-8x7b-32768',
      'gemma2-9b-it',
    ],
  },
  {
    id: 'openai',
    name: 'OpenAI',
    baseUrl: 'https://api.openai.com/v1/chat/completions',
    model: 'gpt-4o-mini',
    models: [
      'gpt-4o-mini',
      'gpt-4o',
      'gpt-4-turbo',
      'gpt-3.5-turbo',
    ],
  },
  {
    id: 'anthropic',
    name: 'Anthropic',
    baseUrl: 'https://api.anthropic.com/v1/messages',
    model: 'claude-3-5-sonnet-20241022',
    models: [
      'claude-3-5-sonnet-20241022',
      'claude-3-5-haiku-20241022',
      'claude-3-opus-20240229',
    ],
  },
  {
    id: 'deepseek',
    name: 'DeepSeek',
    baseUrl: 'https://api.deepseek.com/chat/completions',
    model: 'deepseek-chat',
    models: [
      'deepseek-chat',
      'deepseek-reasoner',
    ],
  },
  {
    id: 'custom',
    name: 'Custom',
    baseUrl: 'https://api.example.com/v1/chat/completions',
    model: 'default',
    models: ['default'],
  },
];

// ─── Supabase-backed Storage Operations ─────────────────────────────────────

async function getApiKeys(userId: string): Promise<StoredProvider[]> {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('api_keys')
    .eq('id', userId)
    .single();

  if (error || !data?.api_keys) return [];
  return (data.api_keys as StoredProvider[]) || [];
}

async function setApiKeys(userId: string, providers: StoredProvider[]): Promise<void> {
  const { error } = await supabase
    .from('user_profiles')
    .update({ api_keys: providers, updated_at: new Date().toISOString() })
    .eq('id', userId);

  if (error) console.error('setApiKeys error:', error);
}

// ─── Public API ──────────────────────────────────────────────────────────────

export async function loadStoredProviders(userId: string): Promise<StoredProvider[]> {
  if (!userId) return [];
  return getApiKeys(userId);
}

export async function saveStoredProviders(userId: string, providers: StoredProvider[]): Promise<void> {
  if (!userId) return;
  await setApiKeys(userId, providers);
}

export async function addProvider(userId: string, provider: StoredProvider): Promise<void> {
  if (!userId) return;
  const providers = await getApiKeys(userId);
  const existing = providers.findIndex(p => p.id === provider.id);
  if (existing >= 0) {
    providers[existing] = provider;
  } else {
    providers.push(provider);
  }
  await setApiKeys(userId, providers);
}

export async function removeProvider(userId: string, id: string): Promise<void> {
  if (!userId) return;
  const providers = (await getApiKeys(userId)).filter(p => p.id !== id);
  await setApiKeys(userId, providers);
}

export async function getProviderConfig(userId: string, id: string): Promise<StoredProvider | undefined> {
  if (!userId) return undefined;
  const providers = await getApiKeys(userId);
  return providers.find(p => p.id === id);
}

export async function hasProvider(userId: string, id: string): Promise<boolean> {
  const config = await getProviderConfig(userId, id);
  return !!config?.apiKey;
}

export async function listActiveProviders(userId: string): Promise<StoredProvider[]> {
  if (!userId) return [];
  const providers = await getApiKeys(userId);
  return providers.filter(p => !!p.apiKey && p.apiKey.length > 10);
}

// Mask a key for display: sk-abc...def
export function maskKey(key: string): string {
  if (!key || key.length <= 12) return '****';
  return `${key.slice(0, 6)}...${key.slice(-4)}`;
}

// Generate a unique provider ID from a name
export function generateProviderId(name: string): string {
  return name.toLowerCase().replace(/[^a-z0-9]/g, '_') + '_' + Math.random().toString(36).slice(2, 6);
}
