// Backend Proxy — Future-safe structure for server-side AI requests
//
// WARNING: VITE_ env vars are bundled into the frontend. They are NOT secure.
// For production, AI requests MUST go through a backend endpoint like this.
//
// Example: Create /api/ai/route.ts (Next.js) or an Express endpoint:
//
//   POST /api/ai/chat
//   Body: { prompt, schema, history }
//   Server reads GROQ_API_KEY from process.env (never exposed to client)
//   Server calls Groq API and returns structured JSON to client
//
// This file is a placeholder. The actual implementation depends on your backend.

export interface BackendChatRequest {
  prompt: string;
  schema: Record<string, unknown>;
  history: Array<{ role: string; content: string }>;
  provider?: 'groq' | 'openai';
  model?: string;
}

export interface BackendChatResponse {
  assistantMessage: string;
  schemaPatch?: Array<Record<string, unknown>>;
  fullUpdatedSchema?: Record<string, unknown>;
  warnings?: string[];
}

// Placeholder: replace with actual fetch to your backend
export async function chatViaBackend(_req: BackendChatRequest): Promise<BackendChatResponse> {
  throw new Error('Backend proxy not implemented. Use frontend providers with VITE_ keys for demo only.');
}
