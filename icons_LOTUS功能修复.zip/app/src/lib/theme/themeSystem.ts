// Theme System — Dual palette: Dark (current) + Light (cream/peach inspired by Figma reference)
// Inspired by warm cream, terracotta, sage green, and dark brown tones
// STORAGE: All persistence handled by useTheme hook via Supabase user_profiles table

export type ThemeMode = 'dark' | 'light';

export interface ThemePalette {
  // Backgrounds
  bgBase: string;
  bgSurface: string;
  bgElevated: string;
  bgSidebar: string;
  bgChat: string;
  bgCard: string;
  bgInput: string;
  // Text
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textPlaceholder: string;
  // Accents
  accentPrimary: string;
  accentPrimaryHover: string;
  accentPrimaryLight: string;
  accentSecondary: string; // sage green
  accentSecondaryLight: string;
  accentTertiary: string; // terracotta
  // Borders
  borderDefault: string;
  borderHover: string;
  borderAccent: string;
  // Status
  statusSuccess: string;
  statusError: string;
  statusWarning: string;
  // Special
  shadowColor: string;
  overlayColor: string;
  codeBg: string;
}

// ─── Dark Palette (current, matches logo gold on black) ─────────────────────

export const darkPalette: ThemePalette = {
  bgBase: '#0a0a0a',
  bgSurface: '#111111',
  bgElevated: '#1a1a1a',
  bgSidebar: '#0d0d0d',
  bgChat: '#050505',
  bgCard: '#141414',
  bgInput: 'rgba(255,255,255,0.05)',

  textPrimary: '#F5EDE3',
  textSecondary: 'rgba(245,237,227,0.7)',
  textMuted: 'rgba(245,237,227,0.4)',
  textPlaceholder: 'rgba(245,237,227,0.2)',

  accentPrimary: '#E3B26D',
  accentPrimaryHover: '#EFCA86',
  accentPrimaryLight: 'rgba(227,178,109,0.1)',
  accentSecondary: '#8CB88F',
  accentSecondaryLight: 'rgba(140,184,143,0.15)',
  accentTertiary: '#D4846A',

  borderDefault: 'rgba(255,255,255,0.05)',
  borderHover: 'rgba(227,178,109,0.2)',
  borderAccent: 'rgba(227,178,109,0.15)',

  statusSuccess: '#8CB88F',
  statusError: '#D4846A',
  statusWarning: '#E3B26D',

  shadowColor: 'rgba(0,0,0,0.5)',
  overlayColor: 'rgba(0,0,0,0.6)',
  codeBg: '#141414',
};

// ─── Light Palette (cream/peach/sage inspired by Figma) ──────────────────────

export const lightPalette: ThemePalette = {
  bgBase: '#FDF6ED',
  bgSurface: '#F5EDE3',
  bgElevated: '#FFFFFF',
  bgSidebar: '#F8F0E6',
  bgChat: '#FAF3EA',
  bgCard: '#FFFFFF',
  bgInput: 'rgba(44,40,36,0.04)',

  textPrimary: '#2C2824',
  textSecondary: 'rgba(44,40,36,0.65)',
  textMuted: 'rgba(44,40,36,0.4)',
  textPlaceholder: 'rgba(44,40,36,0.25)',

  accentPrimary: '#C4795A',
  accentPrimaryHover: '#D4846A',
  accentPrimaryLight: 'rgba(196,121,90,0.1)',
  accentSecondary: '#6B9E6E',
  accentSecondaryLight: 'rgba(107,158,110,0.12)',
  accentTertiary: '#C4795A',

  borderDefault: 'rgba(44,40,36,0.08)',
  borderHover: 'rgba(196,121,90,0.25)',
  borderAccent: 'rgba(196,121,90,0.2)',

  statusSuccess: '#6B9E6E',
  statusError: '#C4795A',
  statusWarning: '#C9A050',

  shadowColor: 'rgba(44,40,36,0.06)',
  overlayColor: 'rgba(44,40,36,0.3)',
  codeBg: '#F5EDE3',
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function getThemePalette(mode: ThemeMode): ThemePalette {
  return mode === 'light' ? lightPalette : darkPalette;
}

export function toggleThemeMode(current: ThemeMode): ThemeMode {
  return current === 'dark' ? 'light' : 'dark';
}

// ─── CSS Variable Generator ───────────────────────────────────────────────────

export function generateThemeCSS(mode: ThemeMode): string {
  const p = getThemePalette(mode);
  return `
    :root {
      --lotus-bg-base: ${p.bgBase};
      --lotus-bg-surface: ${p.bgSurface};
      --lotus-bg-elevated: ${p.bgElevated};
      --lotus-bg-sidebar: ${p.bgSidebar};
      --lotus-bg-chat: ${p.bgChat};
      --lotus-bg-card: ${p.bgCard};
      --lotus-bg-input: ${p.bgInput};
      --lotus-text-primary: ${p.textPrimary};
      --lotus-text-secondary: ${p.textSecondary};
      --lotus-text-muted: ${p.textMuted};
      --lotus-text-placeholder: ${p.textPlaceholder};
      --lotus-accent-primary: ${p.accentPrimary};
      --lotus-accent-primary-hover: ${p.accentPrimaryHover};
      --lotus-accent-primary-light: ${p.accentPrimaryLight};
      --lotus-accent-secondary: ${p.accentSecondary};
      --lotus-accent-secondary-light: ${p.accentSecondaryLight};
      --lotus-accent-tertiary: ${p.accentTertiary};
      --lotus-border-default: ${p.borderDefault};
      --lotus-border-hover: ${p.borderHover};
      --lotus-border-accent: ${p.borderAccent};
      --lotus-status-success: ${p.statusSuccess};
      --lotus-status-error: ${p.statusError};
      --lotus-status-warning: ${p.statusWarning};
      --lotus-shadow-color: ${p.shadowColor};
      --lotus-overlay-color: ${p.overlayColor};
      --lotus-code-bg: ${p.codeBg};
    }
  `;
}
