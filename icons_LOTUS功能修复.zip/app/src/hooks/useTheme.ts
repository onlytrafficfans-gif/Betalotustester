// useTheme hook — Supabase-backed dark/light mode with realtime sync
// No localStorage. All user preferences stored in user_profiles table.

import { useState, useEffect, useCallback, useRef } from 'react';
import {
  setThemeMode,
  subscribeToProfile,
  getProfile,
  createProfile,
} from '@/lib/supabase/profileStorage';
import {
  generateThemeCSS,
  getThemePalette,
} from '@/lib/theme/themeSystem';
import type { ThemeMode, ThemePalette } from '@/lib/theme/themeSystem';
import type { UserProfile } from '@/lib/supabase/profileStorage';
import { supabase } from '@/lib/supabase/client';

export function useTheme(userId?: string) {
  const [mode, setMode] = useState<ThemeMode>('dark');
  const [mounted, setMounted] = useState(false);
  const channelRef = useRef<ReturnType<typeof subscribeToProfile> | null>(null);

  // Load theme from Supabase on mount
  useEffect(() => {
    let cancelled = false;

    async function load() {
      if (!userId) {
        setMounted(true);
        return;
      }

      // Get or create profile
      let profile = await getProfile(userId);
      if (!profile) {
        const { data: { user } } = await supabase.auth.getUser();
        if (user) {
          profile = await createProfile(userId, user.email!, user.user_metadata?.full_name, user.user_metadata?.avatar_url);
        }
      }

      if (!cancelled && profile) {
        setMode(profile.theme_mode as ThemeMode);
      }
      setMounted(true);
    }

    load();
    return () => { cancelled = true; };
  }, [userId]);

  // Subscribe to realtime changes (sync across devices/tabs)
  useEffect(() => {
    if (!userId || !mounted) return;

    channelRef.current = subscribeToProfile(userId, (profile: UserProfile) => {
      if (profile.theme_mode && (profile.theme_mode === 'dark' || profile.theme_mode === 'light')) {
        setMode(profile.theme_mode);
      }
    });

    return () => {
      channelRef.current?.unsubscribe();
    };
  }, [userId, mounted]);

  // Apply CSS variables when mode changes
  useEffect(() => {
    if (!mounted) return;

    const css = generateThemeCSS(mode);
    let styleEl = document.getElementById('lotus-theme-vars');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'lotus-theme-vars';
      document.head.appendChild(styleEl);
    }
    styleEl.textContent = css;

    document.documentElement.setAttribute('data-theme', mode);
    if (mode === 'light') {
      document.documentElement.classList.remove('dark');
    } else {
      document.documentElement.classList.add('dark');
    }
  }, [mode, mounted]);

  const toggle = useCallback(() => {
    setMode(prev => {
      const next = prev === 'dark' ? 'light' : 'dark';
      // Sync to Supabase
      if (userId) {
        setThemeMode(userId, next);
      }
      return next;
    });
  }, [userId]);

  const set = useCallback((newMode: ThemeMode) => {
    setMode(newMode);
    if (userId) {
      setThemeMode(userId, newMode);
    }
  }, [userId]);

  const palette: ThemePalette = getThemePalette(mode);

  return { mode, toggle, set, palette, mounted };
}
