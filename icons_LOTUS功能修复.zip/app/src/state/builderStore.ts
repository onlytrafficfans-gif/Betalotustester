// Builder Store — Zustand store for the entire app builder
// Phase 10: Dynamic providers, true-size preview, no placeholders

import { create } from 'zustand';
import type { AppSchema, ChatMessage, Project } from '@/lib/builder/appSchema';
import { generateId, applySchemaPatches, validateAppTheme } from '@/lib/builder/appSchema';
import { getDefaultProviderId, listProviders, getProvider, registerProvider, unregisterProvider } from '@/lib/ai/provider';
import { createGenericProvider } from '@/lib/ai/genericProvider';
import {
  getAllProjects, getProject, createProject, saveProject,
  deleteProject, renameProject, setCurrentProject, getCurrentProjectId,
  resetProject, generateProjectName, migrateLocalStorageToSupabase,
} from '@/lib/supabase/projectStorage';
import { addProvider, loadStoredProviders } from '@/lib/ai/apiKeyStorage';
import type { StoredProvider } from '@/lib/ai/apiKeyStorage';

const HISTORY_LIMIT = 50;

export type PreviewDevice = 'phone' | 'tablet' | 'desktop';
export type MobileTab = 'chat' | 'preview' | 'skills' | 'projects' | 'settings';
export type SidebarView = 'projects' | 'settings' | null;
export type GenerationStatus = 'idle' | 'loading' | 'success' | 'error';

export interface AppliedChange {
  text: string;
  timestamp: number;
}

interface BuilderState {
  project: Project | null;
  projects: Project[];
  messages: ChatMessage[];
  isLoading: boolean;
  error: string | null;
  schema: AppSchema | null;
  previewDevice: PreviewDevice;
  mobileTab: MobileTab;
  sidebarView: SidebarView;
  isSidebarOpen: boolean;
  showSkillsPanel: boolean;
  providerId: string;
  appliedChanges: AppliedChange[];
  generationStatus: GenerationStatus;
  lastFailedPrompt: string | null;
  schemaHistory: AppSchema[];
  historyIndex: number;
  isProjectsLoading: boolean;

  // Current user (set from App.tsx auth gate)
  _currentUser: { id: string; email: string; name?: string; avatar?: string } | null;

  // Actions
  loadProjects: () => Promise<void>;
  createNewProject: () => Promise<void>;
  openProject: (id: string) => Promise<void>;
  deleteProjectById: (id: string) => Promise<void>;
  renameProjectById: (id: string, name: string) => Promise<void>;
  resetCurrentProject: () => Promise<void>;
  migrateFromLocalStorage: () => Promise<number>;

  sendMessage: (content: string) => Promise<void>;
  retryLastMessage: () => Promise<void>;
  clearError: () => void;

  setActiveScreen: (screenId: string) => void;
  setPreviewDevice: (device: PreviewDevice) => void;
  toggleSkillsPanel: () => void;
  setSkillsPanel: (open: boolean) => void;

  setMobileTab: (tab: MobileTab) => void;
  toggleSidebar: (view: SidebarView) => void;
  setSidebarOpen: (open: boolean) => void;

  switchProvider: (providerId: string) => void;
  getAvailableProviders: () => { id: string; name: string; model: string }[];
  addApiProvider: (userId: string, config: StoredProvider) => Promise<void>;
  removeApiProvider: (id: string) => void;
  refreshProviders: (userId: string) => Promise<void>;

  dismissChanges: () => void;

  uploadImage: (file: File) => Promise<string>;
  deleteImage: (id: string) => void;

  undo: () => void;
  redo: () => void;
}

function deepCloneSchema(schema: AppSchema): AppSchema {
  return JSON.parse(JSON.stringify(schema));
}

export const useBuilderStore = create<BuilderState>((set, get) => ({
  project: null,
  projects: [],
  messages: [],
  isLoading: false,
  error: null,
  schema: null,
  previewDevice: 'phone',
  mobileTab: 'chat',
  sidebarView: null,
  isSidebarOpen: false,
  showSkillsPanel: true,
  providerId: '',
  appliedChanges: [],
  generationStatus: 'idle',
  lastFailedPrompt: null,
  schemaHistory: [],
  historyIndex: -1,
  isProjectsLoading: false,
  _currentUser: null,

  loadProjects: async () => {
    set({ isProjectsLoading: true });
    const projects = await getAllProjects();
    const currentId = getCurrentProjectId();
    let project: Project | null = null;

    if (currentId) project = await getProject(currentId);
    if (!project && projects.length > 0) {
      project = projects[0];
      setCurrentProject(project.id);
    }
    if (!project) project = await createProject('My First Project');

    // Refresh providers from stored keys
    const user = get()._currentUser;
    if (user) await get().refreshProviders(user.id);

    const schemaSnapshot = deepCloneSchema(project.schema);
    const defaultProvider = getDefaultProviderId();

    set({
      projects, project, messages: project.messages, schema: project.schema,
      schemaHistory: [schemaSnapshot], historyIndex: 0,
      generationStatus: 'idle', lastFailedPrompt: null, error: null,
      isProjectsLoading: false, providerId: defaultProvider, showSkillsPanel: true,
    });
  },

  createNewProject: async () => {
    const current = get().project;
    if (current) await saveProject(current);

    const newProject = await createProject('New Project');
    const projects = await getAllProjects();
    const schemaClone = deepCloneSchema(newProject.schema);

    set({
      project: newProject, projects, messages: [], schema: newProject.schema,
      isLoading: false, error: null, appliedChanges: [],
      generationStatus: 'idle', lastFailedPrompt: null,
      schemaHistory: [schemaClone], historyIndex: 0, mobileTab: 'chat',
    });
  },

  openProject: async (id: string) => {
    const current = get().project;
    if (current) await saveProject(current);

    const project = await getProject(id);
    if (project) {
      setCurrentProject(id);
      const schemaClone = deepCloneSchema(project.schema);
      set({
        project, messages: project.messages, schema: project.schema,
        isLoading: false, error: null, appliedChanges: [],
        generationStatus: 'idle', lastFailedPrompt: null,
        schemaHistory: [schemaClone], historyIndex: 0, mobileTab: 'chat',
      });
    }
  },

  deleteProjectById: async (id: string) => {
    await deleteProject(id);
    const projects = await getAllProjects();
    const current = get().project;

    if (current?.id === id) {
      if (projects.length > 0) {
        const next = projects[0];
        setCurrentProject(next.id);
        set({ project: next, projects, messages: next.messages, schema: next.schema,
          schemaHistory: [deepCloneSchema(next.schema)], historyIndex: 0 });
      } else {
        const newProject = await createProject('My First Project');
        set({ project: newProject, projects: [newProject], messages: [], schema: newProject.schema,
          schemaHistory: [deepCloneSchema(newProject.schema)], historyIndex: 0 });
      }
    } else {
      set({ projects });
    }
  },

  renameProjectById: async (id: string, name: string) => {
    await renameProject(id, name);
    const projects = await getAllProjects();
    const project = get().project;
    if (project?.id === id) {
      set({ project: { ...project, name }, projects });
    } else {
      set({ projects });
    }
  },

  resetCurrentProject: async () => {
    const project = get().project;
    if (project) {
      if (!window.confirm('Reset this project? All chat history and app changes will be lost.')) return;
      const updated = await resetProject(project.id);
      const projects = await getAllProjects();
      set({ project: updated, projects, messages: updated.messages, schema: updated.schema,
        appliedChanges: [], schemaHistory: [deepCloneSchema(updated.schema)], historyIndex: 0 });
    }
  },

  migrateFromLocalStorage: async () => {
    const count = await migrateLocalStorageToSupabase();
    if (count > 0) await get().loadProjects();
    return count;
  },

  sendMessage: async (content: string) => {
    const state = get();
    if (state.isLoading) return;

    const userMessage: ChatMessage = {
      id: generateId(), role: 'user', content, timestamp: Date.now(),
    };

    const updatedMessages = [...state.messages, userMessage];
    let projectName = state.project?.name;
    if (state.messages.length === 0 && state.project) {
      projectName = generateProjectName(updatedMessages);
    }

    set({
      messages: updatedMessages, isLoading: true, error: null,
      appliedChanges: [], generationStatus: 'loading', lastFailedPrompt: null,
    });

    try {
      const provider = getProvider(state.providerId);
      if (!provider) throw new Error(`No AI provider configured. Add an API key in Settings.`);

      const aiResponse = await provider.sendMessage(
        content,
        state.schema || state.project?.schema!,
        updatedMessages.map(m => ({ role: m.role, content: m.content }))
      );

      const assistantMessage: ChatMessage = {
        id: generateId(), role: 'assistant',
        content: aiResponse.assistantMessage || 'Done.', timestamp: Date.now(),
      };

      const finalMessages = [...updatedMessages, assistantMessage];

      let updatedSchema = state.schema;
      const appliedChanges: AppliedChange[] = [];

      if (aiResponse.schemaPatch && aiResponse.schemaPatch.length > 0 && updatedSchema) {
        const result = applySchemaPatches(updatedSchema, aiResponse.schemaPatch);
        updatedSchema = result.schema;
        result.changes.forEach(c => appliedChanges.push({ text: c, timestamp: Date.now() }));
      } else if (aiResponse.fullUpdatedSchema) {
        updatedSchema = aiResponse.fullUpdatedSchema;
        appliedChanges.push({ text: 'Applied full schema update', timestamp: Date.now() });
      }

      if (updatedSchema) {
        updatedSchema = { ...updatedSchema, name: projectName || updatedSchema.name };
        const colorValidation = validateAppTheme(updatedSchema.theme);
        if (!colorValidation.valid) {
          colorValidation.errors.forEach(e => appliedChanges.push({ text: `⚠️ ${e}`, timestamp: Date.now() }));
        }
      }

      const updatedProject: Project = {
        ...state.project!,
        id: state.project!.id,
        name: projectName || state.project!.name,
        messages: finalMessages,
        schema: updatedSchema || state.project!.schema,
        updatedAt: Date.now(),
      };

      await saveProject(updatedProject);

      const newHistory = state.schemaHistory.slice(0, state.historyIndex + 1);
      const schemaSnapshot = deepCloneSchema(updatedSchema || state.schema!);
      newHistory.push(schemaSnapshot);
      if (newHistory.length > HISTORY_LIMIT) newHistory.shift();

      set({
        project: updatedProject, messages: finalMessages, schema: updatedSchema,
        isLoading: false, generationStatus: 'success',
        appliedChanges,
        schemaHistory: newHistory, historyIndex: newHistory.length - 1,
      });
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Something went wrong. Please try again.';

      if (import.meta.env.DEV) {
        // eslint-disable-next-line no-console
        console.error('[LOTUS] Generation failed:', { error: err, message, prompt: content, provider: state.providerId, timestamp: new Date().toISOString() });
      }

      set({ isLoading: false, generationStatus: 'error', error: message, lastFailedPrompt: content });
    }
  },

  retryLastMessage: async () => {
    const prompt = get().lastFailedPrompt;
    if (!prompt) return;
    set({ error: null, generationStatus: 'idle', lastFailedPrompt: null });
    await get().sendMessage(prompt);
  },

  clearError: () => set({ error: null, generationStatus: 'idle', lastFailedPrompt: null }),

  undo: () => {
    const state = get();
    if (state.historyIndex <= 0) return;
    const newIndex = state.historyIndex - 1;
    const restoredSchema = deepCloneSchema(state.schemaHistory[newIndex]);
    const updatedProject = state.project ? { ...state.project, schema: restoredSchema, updatedAt: Date.now() } : null;
    if (updatedProject) saveProject(updatedProject);
    set({ schema: restoredSchema, project: updatedProject, historyIndex: newIndex, appliedChanges: [] });
  },

  redo: () => {
    const state = get();
    if (state.historyIndex >= state.schemaHistory.length - 1) return;
    const newIndex = state.historyIndex + 1;
    const restoredSchema = deepCloneSchema(state.schemaHistory[newIndex]);
    const updatedProject = state.project ? { ...state.project, schema: restoredSchema, updatedAt: Date.now() } : null;
    if (updatedProject) saveProject(updatedProject);
    set({ schema: restoredSchema, project: updatedProject, historyIndex: newIndex, appliedChanges: [] });
  },

  setActiveScreen: (screenId: string) => {
    const state = get();
    if (!state.schema) return;
    if (!state.schema.screens.some(s => s.id === screenId)) return;
    const updatedSchema = { ...state.schema, activeScreenId: screenId };
    const updatedProject = state.project ? { ...state.project, schema: updatedSchema } : null;
    if (updatedProject) saveProject(updatedProject);
    set({ schema: updatedSchema, project: updatedProject });
  },

  setPreviewDevice: (device) => set({ previewDevice: device }),
  toggleSkillsPanel: () => set(s => ({ showSkillsPanel: !s.showSkillsPanel })),
  setSkillsPanel: (open: boolean) => set({ showSkillsPanel: open }),

  setMobileTab: (tab) => set({ mobileTab: tab }),
  toggleSidebar: (view) => {
    const state = get();
    if (state.sidebarView === view) {
      set({ sidebarView: null, isSidebarOpen: false });
    } else {
      set({ sidebarView: view, isSidebarOpen: true });
    }
  },
  setSidebarOpen: (open) => set({ isSidebarOpen: open }),

  switchProvider: (providerId: string) => {
    const provider = getProvider(providerId);
    if (!provider) {
      set({ error: `Provider "${providerId}" not available. Add the API key in Settings.` });
      return;
    }
    set({ providerId, error: null, generationStatus: 'idle' });
  },

  getAvailableProviders: () => listProviders(),

  addApiProvider: async (userId: string, config: StoredProvider) => {
    await addProvider(userId, config);
    registerProvider(config.id, createGenericProvider(config.id, config.name, config.apiKey, config.baseUrl, config.model));
    set({ providerId: config.id, error: null });
  },

  removeApiProvider: (id: string) => {
    unregisterProvider(id);
    const providers = listProviders();
    const state = get();
    if (state.providerId === id) {
      const nextProvider = providers[0];
      set({ providerId: nextProvider?.id || '' });
    }
  },

  refreshProviders: async (userId: string) => {
    const stored = await loadStoredProviders(userId);
    for (const config of stored) {
      if (config.apiKey && config.apiKey.length > 10) {
        registerProvider(config.id, createGenericProvider(config.id, config.name, config.apiKey, config.baseUrl, config.model));
      }
    }
  },

  dismissChanges: () => set({ appliedChanges: [] }),

  uploadImage: async (file: File) => {
    return new Promise<string>((resolve, reject) => {
      if (!file.type.startsWith('image/')) { reject(new Error('Only image files (JPG, PNG, WebP)')); return; }
      if (file.size > 5 * 1024 * 1024) { reject(new Error('Image must be under 5MB')); return; }

      const reader = new FileReader();
      reader.onload = () => {
        const base64 = reader.result as string;
        const id = generateId();
        const state = get();
        if (!state.schema) { reject(new Error('No schema')); return; }

        const updatedSchema: AppSchema = { ...state.schema, imageAssets: { ...state.schema.imageAssets, [id]: base64 } };
        const updatedProject = state.project ? { ...state.project, schema: updatedSchema, updatedAt: Date.now() } : null;
        if (updatedProject) saveProject(updatedProject);
        set({ schema: updatedSchema, project: updatedProject });
        resolve(id);
      };
      reader.onerror = () => reject(new Error('Failed to read image'));
      reader.readAsDataURL(file);
    });
  },

  deleteImage: (id: string) => {
    const state = get();
    if (!state.schema) return;
    const assets = { ...state.schema.imageAssets };
    delete assets[id];
    const updatedSchema = { ...state.schema, imageAssets: assets };
    const updatedProject = state.project ? { ...state.project, schema: updatedSchema, updatedAt: Date.now() } : null;
    if (updatedProject) saveProject(updatedProject);
    set({ schema: updatedSchema, project: updatedProject });
  },
}));
