import { describe, it, expect } from 'vitest';
import { generateExport } from '@/lib/builder/exportGenerator';
import { createDefaultSchema, validateAppTheme } from '@/lib/builder/appSchema';
import type { AppSchema } from '@/lib/builder/appSchema';
import JSZip from 'jszip';

describe('generateExport', () => {
  it('generates a zip blob for a valid schema', async () => {
    const schema = createDefaultSchema();
    const blob = await generateExport(schema);
    expect(blob).toBeInstanceOf(Blob);
    expect(blob.type).toBe('application/zip');
    expect(blob.size).toBeGreaterThan(0);
  });

  it('contains all required files', async () => {
    const schema = createDefaultSchema();
    const blob = await generateExport(schema);
    const arrayBuffer = await blob.arrayBuffer();
    const zip = await JSZip.loadAsync(arrayBuffer);

    const requiredFiles = [
      'package.json',
      'index.html',
      'vite.config.ts',
      'tsconfig.json',
      'tsconfig.node.json',
      'tailwind.config.cjs',
      'postcss.config.cjs',
      'src/theme.ts',
      'src/assets.ts',
      'src/main.tsx',
      'src/App.tsx',
      'src/index.css',
    ];

    for (const file of requiredFiles) {
      expect(zip.file(file)).not.toBeNull();
    }
  });

  it('contains screen files for each screen', async () => {
    const schema = createDefaultSchema();
    schema.screens[0].name = 'Dashboard';
    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    expect(zip.file('src/screens/Dashboard.tsx')).not.toBeNull();
  });

  it('rejects export with invalid theme colors', async () => {
    const schema = createDefaultSchema();
    schema.theme.primary = '#GGG';

    await expect(generateExport(schema)).rejects.toThrow('Cannot export');
  });

  it('embeds image assets in assets.ts', async () => {
    const schema = createDefaultSchema();
    schema.imageAssets = {
      'img-1': 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
    };
    schema.screens[0].components.push({
      id: 'test-img',
      type: 'image',
      props: { assetId: 'img-1', alt: 'Test' },
    });

    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    const assetsFile = zip.file('src/assets.ts');
    expect(assetsFile).not.toBeNull();

    const assetsContent = await assetsFile!.async('string');
    expect(assetsContent).toContain("'img-1':");
    expect(assetsContent).toContain('data:image/png;base64');
  });

  it('screen file references IMAGE_ASSETS for image components', async () => {
    const schema = createDefaultSchema();
    schema.screens[0].components.push({
      id: 'test-img',
      type: 'image',
      props: { assetId: 'img-1', alt: 'Test' },
    });

    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    const screenFile = zip.file('src/screens/Home.tsx');
    expect(screenFile).not.toBeNull();

    const content = await screenFile!.async('string');
    expect(content).toContain("import { IMAGE_ASSETS } from '../assets'");
    expect(content).toContain("IMAGE_ASSETS['img-1']");
  });

  it('screen file references external URL for url-based images', async () => {
    const schema = createDefaultSchema();
    schema.screens[0].components.push({
      id: 'test-img',
      type: 'image',
      props: { url: 'https://example.com/img.png', alt: 'External' },
    });

    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    const screenFile = zip.file('src/screens/Home.tsx');
    const content = await screenFile!.async('string');
    expect(content).toContain('https://example.com/img.png');
    expect(content).toContain('<img');
  });

  it('has .cjs config files for ESM compatibility', async () => {
    const schema = createDefaultSchema();
    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    expect(zip.file('tailwind.config.cjs')).not.toBeNull();
    expect(zip.file('postcss.config.cjs')).not.toBeNull();
    // Must NOT have .js versions that would conflict with "type": "module"
    expect(zip.file('tailwind.config.js')).toBeNull();
    expect(zip.file('postcss.config.js')).toBeNull();
  });

  it('has noUnusedLocals disabled in tsconfig', async () => {
    const schema = createDefaultSchema();
    const blob = await generateExport(schema);
    const zip = await JSZip.loadAsync(await blob.arrayBuffer());

    const tsconfig = await zip.file('tsconfig.json')!.async('string');
    const config = JSON.parse(tsconfig);
    expect(config.compilerOptions.noUnusedLocals).toBe(false);
    expect(config.compilerOptions.noUnusedParameters).toBe(false);
  });
});
