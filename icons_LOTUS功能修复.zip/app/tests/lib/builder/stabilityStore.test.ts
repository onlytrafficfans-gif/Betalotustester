import { describe, it, expect, beforeEach } from 'vitest';
import { useBuilderStore } from '@/state/builderStore';
import { createDefaultSchema } from '@/lib/builder/appSchema';
import type { AppSchema } from '@/lib/builder/appSchema';

// Reset store state before each test — must await async actions
beforeEach(async () => {
  // Create fresh state by loading projects (will create default)
  await useBuilderStore.getState().loadProjects();
  // Clear any lingering state
  useBuilderStore.setState({
    error: null,
    generationStatus: 'idle',
    lastFailedPrompt: null,
    generationCount: 0,
    // Don't reset history — loadProjects sets it up
  });
});

describe('Error Recovery', () => {
  it('has initial idle generation status', () => {
    const state = useBuilderStore.getState();
    expect(state.generationStatus).toBe('idle');
    expect(state.lastFailedPrompt).toBeNull();
    expect(state.error).toBeNull();
  });

  it('preserves schema on failed generation', async () => {
    const store = useBuilderStore.getState();
    // Ensure schema is loaded
    if (!store.schema) {
      await store.loadProjects();
    }
    const schemaBefore = useBuilderStore.getState().schema;
    expect(schemaBefore).not.toBeNull();

    // This will fail because mock provider returns undefined
    await store.sendMessage('test message that should fail');

    const state = useBuilderStore.getState();
    // Schema should be preserved (not replaced with broken output)
    expect(state.schema).not.toBeNull();
    expect(state.schemaHistory[state.historyIndex]).toBeDefined();
  });

  it('sets lastFailedPrompt on error', async () => {
    const store = useBuilderStore.getState();

    // Set a provider that doesn't exist to force error
    useBuilderStore.setState({ providerId: 'nonexistent-provider' });

    await store.sendMessage('test prompt for failure');

    const state = useBuilderStore.getState();
    expect(state.lastFailedPrompt).toBe('test prompt for failure');
    expect(state.generationStatus).toBe('error');
    expect(state.error).not.toBeNull();
  });

  it('clearError resets error state', () => {
    useBuilderStore.setState({
      error: 'Some error',
      generationStatus: 'error',
      lastFailedPrompt: 'test',
    });

    useBuilderStore.getState().clearError();

    const state = useBuilderStore.getState();
    expect(state.error).toBeNull();
    expect(state.generationStatus).toBe('idle');
    expect(state.lastFailedPrompt).toBeNull();
  });
});

describe('Undo/Redo', () => {
  it('initializes history with default schema', async () => {
    await useBuilderStore.getState().loadProjects();
    const state = useBuilderStore.getState();
    expect(state.schemaHistory.length).toBeGreaterThanOrEqual(1);
    expect(state.historyIndex).toBe(0);
  });

  it('cannot undo at initial state', async () => {
    await useBuilderStore.getState().loadProjects();
    const state = useBuilderStore.getState();
    expect(state.historyIndex).toBe(0);
  });

  it('cannot redo at initial state', async () => {
    await useBuilderStore.getState().loadProjects();
    const state = useBuilderStore.getState();
    expect(state.historyIndex).toBe(state.schemaHistory.length - 1);
  });

  it('undo restores previous schema', async () => {
    await useBuilderStore.getState().loadProjects();
    const store = useBuilderStore.getState();
    const originalSchema = store.schema!;

    // Manually push a new history entry with different schema
    const modifiedSchema: AppSchema = {
      ...originalSchema,
      name: 'Modified App',
      screens: [
        ...originalSchema.screens,
        {
          id: 'new-screen',
          name: 'New Screen',
          type: 'custom' as const,
          components: [],
        },
      ],
    };

    useBuilderStore.setState({
      schema: modifiedSchema,
      schemaHistory: [originalSchema, modifiedSchema],
      historyIndex: 1,
    });

    // Verify modified state
    let state = useBuilderStore.getState();
    expect(state.schema!.name).toBe('Modified App');
    expect(state.schema!.screens.length).toBe(originalSchema.screens.length + 1);

    // Undo
    store.undo();

    state = useBuilderStore.getState();
    expect(state.schema!.name).toBe(originalSchema.name);
    expect(state.schema!.screens.length).toBe(originalSchema.screens.length);
    expect(state.historyIndex).toBe(0);
  });

  it('redo restores next schema', async () => {
    await useBuilderStore.getState().loadProjects();
    const store = useBuilderStore.getState();
    const schema1 = store.schema!;
    const schema2 = { ...schema1, name: 'Version 2' };
    const schema3 = { ...schema1, name: 'Version 3' };

    useBuilderStore.setState({
      schemaHistory: [schema1, schema2, schema3],
      historyIndex: 0,
    });

    // Redo to schema2
    store.redo();
    let state = useBuilderStore.getState();
    expect(state.schema!.name).toBe('Version 2');
    expect(state.historyIndex).toBe(1);

    // Redo to schema3
    store.redo();
    state = useBuilderStore.getState();
    expect(state.schema!.name).toBe('Version 3');
    expect(state.historyIndex).toBe(2);
  });

  it('undo does nothing at index 0', async () => {
    await useBuilderStore.getState().loadProjects();
    const store = useBuilderStore.getState();
    const originalSchema = store.schema;

    store.undo();

    const state = useBuilderStore.getState();
    expect(state.schema).toEqual(originalSchema);
    expect(state.historyIndex).toBe(0);
  });

  it('redo does nothing at last index', async () => {
    await useBuilderStore.getState().loadProjects();
    const store = useBuilderStore.getState();
    const originalSchema = store.schema;
    const idx = store.schemaHistory.length - 1;

    useBuilderStore.setState({ historyIndex: idx });
    store.redo();

    const state = useBuilderStore.getState();
    expect(state.schema).toEqual(originalSchema);
    expect(state.historyIndex).toBe(idx);
  });

  it('resets history on createNewProject', async () => {
    await useBuilderStore.getState().loadProjects();

    // Push some history first
    const store = useBuilderStore.getState();
    const schema = store.schema!;
    const modified = { ...schema, name: 'Changed' };

    useBuilderStore.setState({
      schemaHistory: [schema, modified, { ...modified, name: 'Changed Again' }],
      historyIndex: 2,
    });

    await store.createNewProject();

    const state = useBuilderStore.getState();
    expect(state.historyIndex).toBe(0);
    expect(state.schemaHistory.length).toBe(1);
  });
});

describe('Provider System', () => {
  it('has no providers initially', () => {
    const state = useBuilderStore.getState();
    expect(state.providerId).toBe('');
  });

  it('shows no providers when none configured', () => {
    const state = useBuilderStore.getState();
    expect(state.getAvailableProviders().length).toBe(0);
  });

  it('requires provider configuration', async () => {
    const store = useBuilderStore.getState();
    await store.loadProjects();
    await store.sendMessage('test');
    const state = useBuilderStore.getState();
    expect(state.error).toContain('No AI provider configured');
    expect(state.generationStatus).toBe('error');
  });

  it('preserves schema when no provider available', async () => {
    const store = useBuilderStore.getState();
    await store.loadProjects();
    const schemaBefore = useBuilderStore.getState().schema;
    await store.sendMessage('test');
    const state = useBuilderStore.getState();
    expect(state.schema).not.toBeNull();
    expect(state.schema).toEqual(schemaBefore);
  });
});

describe('History deep clone', () => {
  it('undo restores independent schema copy', async () => {
    await useBuilderStore.getState().loadProjects();
    const store = useBuilderStore.getState();
    const schema1 = store.schema!;
    const schema2 = { ...schema1, name: 'Mutated' };

    useBuilderStore.setState({
      schemaHistory: [schema1, schema2],
      historyIndex: 1,
      schema: schema2,
    });

    // Mutate the current schema directly
    const current = useBuilderStore.getState().schema!;
    (current as AppSchema).name = 'Directly Mutated';

    // Undo should restore the original name from history
    store.undo();

    const state = useBuilderStore.getState();
    expect(state.schema!.name).toBe(schema1.name);
  });
});
