import { describe, it, expect } from 'vitest';
import {
  createDefaultSchema,
  generateId,
  isValidHexColor,
  validateAppTheme,
  applySchemaPatches,
  applySchemaPatch,
  defaultTheme,
} from '@/lib/builder/appSchema';
import type { AppSchema, AppTheme, SchemaPatch } from '@/lib/builder/appSchema';

// ─── isValidHexColor ──────────────────────────────────────────────────────────

describe('isValidHexColor', () => {
  it('accepts 3-char uppercase', () => {
    expect(isValidHexColor('#FFF')).toBe(true);
  });
  it('accepts 3-char lowercase', () => {
    expect(isValidHexColor('#abc')).toBe(true);
  });
  it('accepts 6-char uppercase', () => {
    expect(isValidHexColor('#FFFFFF')).toBe(true);
  });
  it('accepts 6-char lowercase', () => {
    expect(isValidHexColor('#1a1a1a')).toBe(true);
  });
  it('accepts numeric-only', () => {
    expect(isValidHexColor('#123456')).toBe(true);
  });
  it('rejects missing hash', () => {
    expect(isValidHexColor('FFFFFF')).toBe(false);
  });
  it('rejects invalid char G', () => {
    expect(isValidHexColor('#GGG')).toBe(false);
  });
  it('rejects named color', () => {
    expect(isValidHexColor('red')).toBe(false);
  });
  it('rejects rgb format', () => {
    expect(isValidHexColor('rgb(0,0,0)')).toBe(false);
  });
  it('rejects 4-char', () => {
    expect(isValidHexColor('#ABCD')).toBe(false);
  });
  it('rejects 7-char', () => {
    expect(isValidHexColor('#ABCDEFG')).toBe(false);
  });
  it('rejects empty string', () => {
    expect(isValidHexColor('')).toBe(false);
  });
  it('rejects special chars', () => {
    expect(isValidHexColor('#!@#$%')).toBe(false);
  });
});

// ─── validateAppTheme ─────────────────────────────────────────────────────────

describe('validateAppTheme', () => {
  it('passes with valid theme', () => {
    const result = validateAppTheme(defaultTheme);
    expect(result.valid).toBe(true);
    expect(result.errors).toHaveLength(0);
  });

  it('fails with one invalid color', () => {
    const theme: AppTheme = { ...defaultTheme, primary: '#GGG' };
    const result = validateAppTheme(theme);
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBeGreaterThan(0);
    expect(result.errors[0]).toContain('primary');
  });

  it('fails with multiple invalid colors', () => {
    const theme: AppTheme = {
      background: '#invalid',
      primary: '#GGG',
      accent: 'not-a-color',
      text: '#FFF',
      surface: '#0a0a0a',
      border: '#262626',
    };
    const result = validateAppTheme(theme);
    expect(result.valid).toBe(false);
    expect(result.errors.length).toBe(3);
  });

  it('reports all 6 fields', () => {
    const theme: AppTheme = {
      background: 'bad',
      primary: 'bad',
      accent: 'bad',
      text: 'bad',
      surface: 'bad',
      border: 'bad',
    };
    const result = validateAppTheme(theme);
    expect(result.errors.length).toBe(6);
  });
});

// ─── generateId ───────────────────────────────────────────────────────────────

describe('generateId', () => {
  it('returns non-empty string', () => {
    const id = generateId();
    expect(typeof id).toBe('string');
    expect(id.length).toBeGreaterThan(0);
  });
  it('returns unique ids', () => {
    const ids = new Set(Array.from({ length: 100 }, generateId));
    expect(ids.size).toBe(100);
  });
});

// ─── createDefaultSchema ──────────────────────────────────────────────────────

describe('createDefaultSchema', () => {
  it('returns schema with required fields', () => {
    const schema = createDefaultSchema();
    expect(schema.id).toBeDefined();
    expect(schema.name).toBe('My App');
    expect(schema.screens).toHaveLength(1);
    expect(schema.screens[0].components.length).toBeGreaterThan(0);
    expect(schema.navigation.type).toBe('none');
    expect(schema.activeScreenId).toBeDefined();
  });

  it('has valid theme colors', () => {
    const schema = createDefaultSchema();
    const result = validateAppTheme(schema.theme);
    expect(result.valid).toBe(true);
  });

  it('each screen has components', () => {
    const schema = createDefaultSchema();
    schema.screens.forEach(screen => {
      expect(screen.components.length).toBeGreaterThan(0);
      screen.components.forEach(comp => {
        expect(comp.id).toBeDefined();
        expect(comp.type).toBeDefined();
        expect(comp.props).toBeDefined();
      });
    });
  });
});

// ─── applySchemaPatch ─────────────────────────────────────────────────────────

describe('applySchemaPatch', () => {
  let baseSchema: AppSchema;

  beforeEach(() => {
    baseSchema = createDefaultSchema();
  });

  it('addScreen adds a new screen', () => {
    const patch: SchemaPatch = {
      op: 'addScreen',
      value: { id: 'test-screen', name: 'Test', type: 'custom', components: [] },
    };
    const result = applySchemaPatch(baseSchema, patch);
    expect(result.schema.screens.length).toBe(2);
    expect(result.change).toContain('Added screen');
  });

  it('updateTheme changes colors', () => {
    const patch: SchemaPatch = {
      op: 'updateTheme',
      value: { primary: '#ff0000' },
    };
    const result = applySchemaPatch(baseSchema, patch);
    expect(result.schema.theme.primary).toBe('#ff0000');
  });

  it('setActiveScreen changes active screen', () => {
    baseSchema = {
      ...baseSchema,
      screens: [
        ...baseSchema.screens,
        { id: 'screen-2', name: 'Second', type: 'custom', components: [] },
      ],
    };
    const patch: SchemaPatch = { op: 'setActiveScreen', screenId: 'screen-2' };
    const result = applySchemaPatch(baseSchema, patch);
    expect(result.schema.activeScreenId).toBe('screen-2');
  });

  it('addComponent adds to a screen', () => {
    const screenId = baseSchema.screens[0].id;
    const patch: SchemaPatch = {
      op: 'addComponent',
      screenId,
      value: { id: 'new-comp', type: 'text', props: { content: 'hello' } },
    };
    const result = applySchemaPatch(baseSchema, patch);
    const screen = result.schema.screens.find(s => s.id === screenId)!;
    expect(screen.components.length).toBe(baseSchema.screens[0].components.length + 1);
  });

  it('removeScreen removes a screen', () => {
    baseSchema = {
      ...baseSchema,
      screens: [
        ...baseSchema.screens,
        { id: 'to-remove', name: 'Temp', type: 'custom', components: [] },
      ],
    };
    const patch: SchemaPatch = { op: 'removeScreen', screenId: 'to-remove' };
    const result = applySchemaPatch(baseSchema, patch);
    expect(result.schema.screens.length).toBe(baseSchema.screens.length - 1);
    expect(result.schema.screens.find(s => s.id === 'to-remove')).toBeUndefined();
  });

  it('setNavigation updates navigation', () => {
    const patch: SchemaPatch = {
      op: 'setNavigation',
      value: { type: 'bottom-tabs', items: [{ id: 'n1', label: 'Home', icon: 'home', screenId: 'home' }] },
    };
    const result = applySchemaPatch(baseSchema, patch);
    expect(result.schema.navigation.type).toBe('bottom-tabs');
  });
});

// ─── applySchemaPatches (multiple) ────────────────────────────────────────────

describe('applySchemaPatches', () => {
  it('applies multiple patches in order', () => {
    const schema = createDefaultSchema();
    const patches: SchemaPatch[] = [
      { op: 'updateTheme', value: { primary: '#ff0000' } },
      { op: 'addScreen', value: { id: 's2', name: 'New', type: 'custom', components: [] } },
    ];
    const result = applySchemaPatches(schema, patches);
    expect(result.schema.theme.primary).toBe('#ff0000');
    expect(result.schema.screens.length).toBe(2);
    expect(result.changes).toHaveLength(2);
  });
});
