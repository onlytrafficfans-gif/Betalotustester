import { describe, it, expect } from 'vitest';
import { generateExport } from '@/lib/builder/exportGenerator';
import { createDefaultSchema } from '@/lib/builder/appSchema';
import fs from 'fs';
import path from 'path';
import JSZip from 'jszip';
import { execSync } from 'child_process';

const tmpDir = '/tmp/lotus-export-test';

describe('export integration', () => {
  it('generates a zip that can be extracted and has valid file structure', async () => {
    const schema = createDefaultSchema();
    schema.name = 'TestApp';
    schema.imageAssets = {
      'img-1': 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==',
    };
    schema.screens[0].components.push({
      id: 'test-img',
      type: 'image',
      props: { assetId: 'img-1', alt: 'Test' },
    });

    const blob = await generateExport(schema);
    expect(blob.size).toBeGreaterThan(0);

    // Extract
    if (fs.existsSync(tmpDir)) fs.rmSync(tmpDir, { recursive: true });
    fs.mkdirSync(tmpDir, { recursive: true });

    const zip = await JSZip.loadAsync(Buffer.from(await blob.arrayBuffer()));
    for (const [name, file] of Object.entries(zip.files)) {
      if (!file.dir) {
        const fp = path.join(tmpDir, name);
        fs.mkdirSync(path.dirname(fp), { recursive: true });
        fs.writeFileSync(fp, await file.async('uint8array'));
      }
    }

    // Verify files
    const required = [
      'package.json', 'index.html', 'vite.config.ts', 'tsconfig.json',
      'tailwind.config.cjs', 'postcss.config.cjs', 'src/theme.ts',
      'src/assets.ts', 'src/main.tsx', 'src/App.tsx', 'src/index.css',
      'src/screens/Home.tsx',
    ];
    for (const f of required) {
      expect(fs.existsSync(path.join(tmpDir, f)), `Missing: ${f}`).toBe(true);
    }

    // Verify assets.ts has the image
    const assets = fs.readFileSync(path.join(tmpDir, 'src/assets.ts'), 'utf-8');
    expect(assets).toContain("'img-1':");
    expect(assets).toContain('data:image/png;base64');

    // Verify screen uses IMAGE_ASSETS
    const screen = fs.readFileSync(path.join(tmpDir, 'src/screens/Home.tsx'), 'utf-8');
    expect(screen).toContain("import { IMAGE_ASSETS } from '../assets'");
    expect(screen).toContain("IMAGE_ASSETS['img-1']");

    // Verify no template literal leaking
    expect(screen).not.toContain('${i}');
    expect(screen).not.toContain('${d}');

    // Verify tsconfig has noUnusedLocals: false
    const tsconfig = JSON.parse(fs.readFileSync(path.join(tmpDir, 'tsconfig.json'), 'utf-8'));
    expect(tsconfig.compilerOptions.noUnusedLocals).toBe(false);
    expect(tsconfig.compilerOptions.noUnusedParameters).toBe(false);
  });

  it('installed and builds the exported project', () => {
    // Install deps in the extracted project
    const pkgDir = tmpDir;
    
    // Write .npmrc to suppress funding messages
    fs.writeFileSync(path.join(pkgDir, '.npmrc'), 'fund=false\nauto-install-peers=true\n');
    
    // Install
    execSync('npm install --no-fund --no-audit 2>&1', { 
      cwd: pkgDir, 
      stdio: 'pipe',
      timeout: 120000,
    });

    // Build
    execSync('npm run build 2>&1', { 
      cwd: pkgDir, 
      stdio: 'pipe',
      timeout: 60000,
    });

    // Verify dist exists
    expect(fs.existsSync(path.join(pkgDir, 'dist/index.html'))).toBe(true);
  }, 180000);
});
