import { describe, it, expect } from 'vitest';
import { isValidHexColor, validateAppTheme } from '@/lib/builder/appSchema';
import type { AppTheme } from '@/lib/builder/appSchema';

// ─── Color validation edge cases ──────────────────────────────────────────────

describe('color validation edge cases', () => {
  it('accepts #000000', () => {
    expect(isValidHexColor('#000000')).toBe(true);
  });
  it('accepts #000', () => {
    expect(isValidHexColor('#000')).toBe(true);
  });
  it('accepts mixed case #AbC123', () => {
    expect(isValidHexColor('#AbC123')).toBe(true);
  });
  it('rejects with spaces', () => {
    expect(isValidHexColor('#FFF ')).toBe(false);
  });
  it('rejects hsl format', () => {
    expect(isValidHexColor('hsl(0,0%,0%)')).toBe(false);
  });
  it('rejects rgba format', () => {
    expect(isValidHexColor('rgba(0,0,0,1)')).toBe(false);
  });
  it('rejects undefined', () => {
    expect(isValidHexColor(undefined as unknown as string)).toBe(false);
  });
  it('rejects null', () => {
    expect(isValidHexColor(null as unknown as string)).toBe(false);
  });
});

describe('validateAppTheme edge cases', () => {
  it('passes with all #000000', () => {
    const theme: AppTheme = {
      background: '#000000',
      primary: '#000000',
      accent: '#000000',
      text: '#000000',
      surface: '#000000',
      border: '#000000',
    };
    expect(validateAppTheme(theme).valid).toBe(true);
  });

  it('passes with all #FFF shorthand', () => {
    const theme: AppTheme = {
      background: '#FFF',
      primary: '#FFF',
      accent: '#FFF',
      text: '#FFF',
      surface: '#FFF',
      border: '#FFF',
    };
    expect(validateAppTheme(theme).valid).toBe(true);
  });

  it('fails with empty string', () => {
    const theme: AppTheme = {
      background: '',
      primary: '#FFF',
      accent: '#FFF',
      text: '#FFF',
      surface: '#FFF',
      border: '#FFF',
    };
    const result = validateAppTheme(theme);
    expect(result.valid).toBe(false);
    expect(result.errors[0]).toContain('background');
  });

  it('error messages are descriptive', () => {
    const theme: AppTheme = {
      background: '#FFF',
      primary: '#GGG',
      accent: '#FFF',
      text: '#FFF',
      surface: '#FFF',
      border: '#FFF',
    };
    const result = validateAppTheme(theme);
    expect(result.errors[0]).toContain('primary');
    expect(result.errors[0]).toContain('#GGG');
    expect(result.errors[0]).toContain('not a valid hex');
  });
});
